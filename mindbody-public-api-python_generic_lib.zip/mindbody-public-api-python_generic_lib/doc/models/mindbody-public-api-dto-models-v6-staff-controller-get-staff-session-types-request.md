
# Mindbody Public Api Dto Models V6 Staff Controller Get Staff Session Types Request

## Structure

`MindbodyPublicApiDtoModelsV6StaffControllerGetStaffSessionTypesRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `staff_id` | `long\|int` | Required | Filters returned session types to only those the staff member performs.  Staff should be active. |
| `program_ids` | `List of int` | Optional | Filters results to session types that belong in program IDs. |
| `online_only` | `bool` | Optional | Only session types that can be booked online. |
| `limit` | `int` | Optional | Number of results to include, defaults to 100 |
| `offset` | `int` | Optional | Page offset, defaults to 0. |

## Example (as JSON)

```json
{
  "StaffId": 156,
  "ProgramIds": null,
  "OnlineOnly": null,
  "Limit": null,
  "Offset": null
}
```

