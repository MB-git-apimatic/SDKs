# Pricing Option

```php
$pricingOptionController = $client->getPricingOptionController();
```

## Class Name

`PricingOptionController`


# Pricing Option Update Pricing Option

Update Pricing Option data such as name, details, price, discontinued using PricingOptionId(product id)

```php
function pricingOptionUpdatePricingOption(
    MindbodyPublicApiDtoModelsV6PricingOptionControllerUpdatePricingOptionRequest $request,
    string $siteId,
    string $version,
    ?string $authorization = null
): array
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `request` | [`MindbodyPublicApiDtoModelsV6PricingOptionControllerUpdatePricingOptionRequest`](../../doc/models/mindbody-public-api-dto-models-v6-pricing-option-controller-update-pricing-option-request.md) | Body, Required | - |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `version` | `string` | Template, Required | - |
| `authorization` | `?string` | Header, Optional | A staff user authorization token. |

## Response Type

`array`

## Example Usage

```php
$request_productId = 16.72;
$request = new Models\MindbodyPublicApiDtoModelsV6PricingOptionControllerUpdatePricingOptionRequest(
    $request_productId
);
$siteId = '-99';
$version = 'version4';

$result = $pricingOptionController->pricingOptionUpdatePricingOption($request, $siteId, $version);
```

