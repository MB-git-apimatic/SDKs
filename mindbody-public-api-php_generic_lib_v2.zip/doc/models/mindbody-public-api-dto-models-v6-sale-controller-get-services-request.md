
# Mindbody Public Api Dto Models V6 Sale Controller Get Services Request

## Structure

`MindbodyPublicApiDtoModelsV6SaleControllerGetServicesRequest`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `programIds` | `?(int[])` | Optional | Filters to pricing options with the specified program IDs. | getProgramIds(): ?array | setProgramIds(?array programIds): void |
| `sessionTypeIds` | `?(int[])` | Optional | Filters to the pricing options with the specified session types IDs. | getSessionTypeIds(): ?array | setSessionTypeIds(?array sessionTypeIds): void |
| `serviceIds` | `?(string[])` | Optional | Filters to the pricing options with the specified IDs. In this context, service and pricing option are used interchangeably. These are the `PurchasedItems[].Id` returned from GET Sales. | getServiceIds(): ?array | setServiceIds(?array serviceIds): void |
| `classId` | `?int` | Optional | Filters to the pricing options for the specified class ID. | getClassId(): ?int | setClassId(?int classId): void |
| `classScheduleId` | `?int` | Optional | Filters to the pricing options for the specified class schedule ID. | getClassScheduleId(): ?int | setClassScheduleId(?int classScheduleId): void |
| `sellOnline` | `?bool` | Optional | When `true`, filters to the pricing options that can be sold online.<br /><br>Default: **false** | getSellOnline(): ?bool | setSellOnline(?bool sellOnline): void |
| `locationId` | `?int` | Optional | When specified, for each returned pricing option, `TaxRate` and `TaxIncluded` are calculated according to the specified location. Note that this does not filter results to only services provided at the given location, and for locations where Value-Added Tax (VAT) rules apply, the `TaxRate` is set to zero. | getLocationId(): ?int | setLocationId(?int locationId): void |
| `hideRelatedPrograms` | `?bool` | Optional | When `true`, indicates that pricing options of related programs are omitted from the response.<br /><br>Default: **false** | getHideRelatedPrograms(): ?bool | setHideRelatedPrograms(?bool hideRelatedPrograms): void |
| `staffId` | `?int` | Optional | Sets `Price` and `OnlinePrice` to the particular pricing of a specific staff member, if allowed by the business. | getStaffId(): ?int | setStaffId(?int staffId): void |
| `includeDiscontinued` | `?bool` | Optional | When `true`, indicates that the filtered pricing option list includes discontinued pricing options.<br /><br>Default: **false** | getIncludeDiscontinued(): ?bool | setIncludeDiscontinued(?bool includeDiscontinued): void |
| `includeSaleInContractOnly` | `?bool` | Optional | When `true`, indicates that the filtered pricing option list includes sale in contract only pricing options.<br /><br>Default: **false** | getIncludeSaleInContractOnly(): ?bool | setIncludeSaleInContractOnly(?bool includeSaleInContractOnly): void |
| `limit` | `?int` | Optional | Number of results to include, defaults to 100 | getLimit(): ?int | setLimit(?int limit): void |
| `offset` | `?int` | Optional | Page offset, defaults to 0. | getOffset(): ?int | setOffset(?int offset): void |

## Example (as JSON)

```json
{
  "ProgramIds": null,
  "SessionTypeIds": null,
  "ServiceIds": null,
  "ClassId": null,
  "ClassScheduleId": null,
  "SellOnline": null,
  "LocationId": null,
  "HideRelatedPrograms": null,
  "StaffId": null,
  "IncludeDiscontinued": null,
  "IncludeSaleInContractOnly": null,
  "Limit": null,
  "Offset": null
}
```

