
# Mindbody Public Api Dto Models V6 Sale Controller Get Contracts Request

## Structure

`MindbodyPublicApiDtoModelsV6SaleControllerGetContractsRequest`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `contractIds` | `?(int[])` | Optional | When included, the response only contains details about the specified contract IDs. | getContractIds(): ?array | setContractIds(?array contractIds): void |
| `soldOnline` | `?bool` | Optional | When `true`, the response only contains details about contracts and AutoPay options that can be sold online.<br>When `false`, all contracts are returned.<br>Default: **false** | getSoldOnline(): ?bool | setSoldOnline(?bool soldOnline): void |
| `locationId` | `int` | Required | The ID of the location that has the requested contracts and AutoPay options. | getLocationId(): int | setLocationId(int locationId): void |
| `consumerId` | `?int` | Optional | The ID of the client. | getConsumerId(): ?int | setConsumerId(?int consumerId): void |
| `promoCode` | `?string` | Optional | PromoCode to apply | getPromoCode(): ?string | setPromoCode(?string promoCode): void |
| `limit` | `?int` | Optional | Number of results to include, defaults to 100 | getLimit(): ?int | setLimit(?int limit): void |
| `offset` | `?int` | Optional | Page offset, defaults to 0. | getOffset(): ?int | setOffset(?int offset): void |

## Example (as JSON)

```json
{
  "ContractIds": null,
  "SoldOnline": null,
  "LocationId": 50,
  "ConsumerId": null,
  "PromoCode": null,
  "Limit": null,
  "Offset": null
}
```

