
# Mindbody Public Api Dto Models V6 Contact Log Type

A contact log type.

## Structure

`MindbodyPublicApiDtoModelsV6ContactLogType`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `int` | Optional | The contact log type’s ID. |
| `name` | `string` | Optional | The type's Name |
| `sub_types` | [`List of MindbodyPublicApiDtoModelsV6ContactLogSubType`](../../doc/models/mindbody-public-api-dto-models-v6-contact-log-sub-type.md) | Optional | A list of the subtypes being used to tag this contact log type. |

## Example (as JSON)

```json
{
  "Id": null,
  "Name": null,
  "SubTypes": null
}
```

