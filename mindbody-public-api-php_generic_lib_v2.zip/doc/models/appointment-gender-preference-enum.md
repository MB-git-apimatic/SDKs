
# Appointment Gender Preference Enum

The gender of staff member with whom the client prefers to book appointments.

## Enumeration

`AppointmentGenderPreferenceEnum`

## Fields

| Name |
|  --- |
| `NONE` |
| `FEMALE` |
| `MALE` |

