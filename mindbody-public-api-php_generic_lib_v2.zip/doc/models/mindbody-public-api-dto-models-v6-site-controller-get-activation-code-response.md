
# Mindbody Public Api Dto Models V6 Site Controller Get Activation Code Response

## Structure

`MindbodyPublicApiDtoModelsV6SiteControllerGetActivationCodeResponse`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `activationCode` | `?string` | Optional | An activation code used to provide access to a site’s business data through MINDBODY. | getActivationCode(): ?string | setActivationCode(?string activationCode): void |
| `activationLink` | `?string` | Optional | A link to the Manage Credentials screen. | getActivationLink(): ?string | setActivationLink(?string activationLink): void |

## Example (as JSON)

```json
{
  "ActivationCode": null,
  "ActivationLink": null
}
```

