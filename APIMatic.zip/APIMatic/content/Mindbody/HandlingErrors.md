﻿## Handling Errors
<script type="text/javascript">
monitor('handling-errors');
</script> 

To help with troubleshooting your integration, the Public API returns error codes in response to invalid requests. When an invalid API request is made, you can use the errors to help to identify and resolve issues such as invalid parameters or conflicting site settings.

Mindbody has introduced error code 429, Too Many Requests, to the Public API. If you receive this error, the rate limit has been reached. Reduce the number of Requests Per Minute (RPM) to resolve this error. We recommend that you keep your requests to 2000 RPM or lower for optimal performance. If you feel this limit should be revised for your integration, contact [Contact API Support](https://support.mindbodyonline.com/s/contactapisupport) with your request. Note that Mindbody does not currently charge you for calls that result in a 429 error code response. 

Errors have the following properties.

**Name** | **Type** | **Description**
--- | --- | ---
**Message** | string | The text of the message. Each message is specific to the error that caused it. For example, if the the error type is `InvalidFileFormat`, the message could say "The photo you attempted to upload is not a supported file type."
**Code** | string | The type of error that occurred, for example, `ClientNotFound` or `InvalidClassId`.

If you get an internal server error, you should first try the request again. If the problem persists, send request to [Contact API Support](https://support.mindbodyonline.com/s/contactapisupport).

In addition to HTTP codes, the API returns a JSON error response object, as shown in the following example:

<code>{<br>
&nbsp;&nbsp;&nbsp;&nbsp;"Error": {<br>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;"Message": "Client 11123123874 does not exist.",<br>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;"Code": "ClientNotFound"<br>
&nbsp;&nbsp;&nbsp;&nbsp;}<br>
}</code>

A general description of each type of error is provided below. The actual description that returns for an error is even more specific to the problem in the request.

**Error Code** | **Description**
--- | ---
ClassRequiresPayment | A client must pay at the time of sign up, and no payment was passed in the request.
ClassScheduleNotFound | No schedule with that ID exists.
ClassSignUpsFull | The class is full. No more clients can be added to the class roster.
ClientCustomFieldNotFound | The custom field used in the request does not exist.
ClientIndexNotFound | The client index used in the request does not exist.
ClientIndexValueNotFound | The client index value used in the request does not exist.
ClientIsAlreadyBooked | The client in the request is already booked for a class, appointment, service, or event.
ClientIsAlreadyOnWaitlist | The client in the request is already on the requested waiting list.
ClientIsSuspended | The client in the request is suspended from scheduling, so the action cannot be carried out.
ClientNotFound | The client in the request does not exist.
CrossRegionalNotSupported | The cross regional feature in the request is not supported.
DeniedAccess | Access is denied.
EnrollmentSignUpsFull | The enrollment is full. No more clients can be added to the enrollment.
EnrollmentWaitlistFull | The waiting list for the requested enrollment is full. No more clients can be added to the waiting list.
FormulaNoteNotFound | The requested formula note does not exist.
InvalidBookingTime | The time requested is not a valid booking time.  For example, the time may be after the close of business, or on a holiday when the business is closed. 
InvalidClassId | The class ID used in the request is not valid.
InvalidClientCreation | Client creation cannot result in duplicate client records.
InvalidClientUpdate | Client update cannot result in duplicate client records or client has linked Mindbody account and sensitive fields cannot be edited.
InvalidCountry | The country used in the request is not valid.
InvalidFileFormat | The file format used in the request is not valid.
InvalidItem | There is a problem with an item used in the request. 
InvalidLocation | A location used in the request is not valid.
InvalidLoginCredentials | The login credentials used in the request are not valid.
InvalidParameter | A parameter used in the request is not valid.
InvalidPaymentInfo | The payment information used in the request is not valid.
InvalidPermissionConfiguration | The staff permissions used in the request are not a valid configuration.
InvalidPrerequisite | The client in the request does not meet the prerequisite requirement for the class in the request.
InvalidPromotionCode | A promotion code used in the request is not valid.
InvalidResource | A resource used in the request is not valid.
InvalidSaleReturn | The return of an item or service that is used in the request is not valid.
InvalidSalesRepId | A sales representative ID used in the request is not valid.
InvalidSettingConfiguration | A setting in the business is configured in such a way as to make the request invalid.
InvalidSiteId | The site ID used in the request is not valid.
InvalidSourceCredentials | The source credentials used in the request are not valid.
InvalidStaffAndProviderId | The staff and provider IDs used in the request are not valid.
InvalidStaffCredentials | The staff credentials used in the request are not valid.
InvalidUserAccessLevel | The user access level used in the request is not valid.
InvalidUserCredentials | The user credentials used in the request are not valid.
ItemNotFound | An item used in the request does not exist.
LeaderFollowerFull | The role that the client is booking, either leader or follower, is not available. That role is full.
MissingRequiredFields | One or more fields that are required in this request are missing.
PaymentRequired | The payment needed to complete this request is missing.
RelatedClientNotFound | The requested related client does not exist.
ResourceDoesNotExist | The requested resource does not exist.
SaleIdNotFound | The sale ID used in this request does not exist.
SchedulingRestrictionsViolated | This request violates one or more of the  scheduling restrictions.
SchedulingWindowViolated | This request violates a scheduling window.
ServiceDoesNotPayForAppointment | The pricing option used in this request cannot be used to pay for the appointment in the request.
ServiceDoesNotPayForVisit | The pricing option used in this request cannot be used to pay for the visit in the request.
SessionTypeNotFound | The session type used in the request does not exist.
StaffCannotTakeTips | The tip included in the request cannot be applied.
StaffIsInactive | The staff member used in the request is not an active staff member.
StaffIsNotATrainer | The staff member used in the request does not teach classes or enrollments.
StaffMemberNotFound | The staff member used in the request does not exist.
TooManyRequests | The rate limit has been reached. Reduce the Requests Per Minute to resolve this error.
Unknown | The cause of this error is not known.
ValidationFailed | The validation of the request itself failed.
VisitMustBeAClass | The visit used in the request must be a class.
SQLDBMaintenance | Please try again as db backup is in progress.
ClassVisitNotFound | The client visit in the request does not exist.
