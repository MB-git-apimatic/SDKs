
# Mindbody Public Api Dto Models V6 Site Controller Get Relationships Request

Get Relationships Request Model

## Structure

`MindbodyPublicApiDtoModelsV6SiteControllerGetRelationshipsRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `active` | `bool` | Optional | The requested Active type Relationships. true indicates for Active Relationships and false indicates for Deactivated Relationships. |
| `limit` | `int` | Optional | Number of results to include, defaults to 100 |
| `offset` | `int` | Optional | Page offset, defaults to 0. |

## Example (as JSON)

```json
{
  "Active": null,
  "Limit": null,
  "Offset": null
}
```

