
# Mindbody Public Api Dto Models V6 Sale Controller Get Transactions Request

Transactions Request

## Structure

`MindbodyPublicApiDtoModelsV6SaleControllerGetTransactionsRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `sale_id` | `long\|int` | Optional | Filters results to the requested sale ID. |
| `transaction_id` | `int` | Optional | Filters results to the requested transaction ID. |
| `client_id` | `long\|int` | Optional | Filters results to the requested client ID. |
| `location_id` | `int` | Optional | Filters results to the requested location ID. |
| `status` | `string` | Optional | Filters results to the requested status. |
| `transaction_start_date_time` | `datetime` | Optional | Filters results to transactions that happened after this date and time. |
| `transaction_end_date_time` | `datetime` | Optional | Filters results to transactions that happened before this date and time. |
| `limit` | `int` | Optional | Number of results to include, defaults to 100 |
| `offset` | `int` | Optional | Page offset, defaults to 0. |

## Example (as JSON)

```json
{
  "SaleId": null,
  "TransactionId": null,
  "ClientId": null,
  "LocationId": null,
  "Status": null,
  "TransactionStartDateTime": null,
  "TransactionEndDateTime": null,
  "Limit": null,
  "Offset": null
}
```

