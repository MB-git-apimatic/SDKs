﻿
The sandbox has a permanent subscriber owner account that you can log into if you need to change the settings of the sample business to match the settings used by the business for which you are developing your application.<br>Optionally, you can also create a mock client account in the sandbox, and log into that account to emulate the behavior of the business owner's clients. You can use this account to act as a client who makes and cancels appointments, buys products from the sample online store in the sandbox, and so on.

**To log in to the sandbox as a subscriber owner**

1. Go to [Mindbody developer's portal](https://developers.mindbodyonline.com).
2. On the upper right corner, click **Log In**.
3. Enter your username and password, and click **Log In**.
4. Once logged in, refer the details on screen to use the Mindbody Sandbox site.

**To create a client account to test application behavior**

1. Go to [Mindbody developer's portal](https://developers.mindbodyonline.com).
2. On the upper right corner, click **Log In**.
3. Use your username and password to log into your developer account.
4. Once logged in, refer the details on screen to use the Mindbody Sandbox site.
6. In the Create an Account box, enter an email address and then click **Next**.<br> Note that entering an email address is optional, but if you plan to test email behavior, you need to add a real email address here.
7. Fill in the Contact Information fields and the Account Information fields.
8. Check the checkbox to agree with the terms and then click **Create Account**.

**Private Sandbox Sites**

You may purchase a private sandbox site if the free public sandbox site is not meeting your testing needs. For more information, please reach out to [Contact API Support](https://support.mindbodyonline.com/s/contactapisupport).