
# Mindbody Public Api Dto Models V6 Add on Small

## Structure

`MindbodyPublicApiDtoModelsV6AddOnSmall`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `long\|int` | Optional | The unique ID of the appointment add on. |
| `name` | `string` | Optional | The Name of the appointment add on. |
| `staff_id` | `long\|int` | Optional | The unique ID of the staff for the add on. |

## Example (as JSON)

```json
{
  "Id": null,
  "Name": null,
  "StaffId": null
}
```

