
# Mindbody Public Api Dto Models V6 Client Index Value

A client index value.

## Structure

`MindbodyPublicApiDtoModelsV6ClientIndexValue`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `active` | `?bool` | Optional | When `true`, indicates that the index value can be assigned to its parent index.<br /><br>When `false`, indicates that the index value has been deactivated and cannot be assigned to its parent index. | getActive(): ?bool | setActive(?bool active): void |
| `id` | `?int` | Optional | The index value’s ID. | getId(): ?int | setId(?int id): void |
| `name` | `?string` | Optional | The name of the client index value. | getName(): ?string | setName(?string name): void |

## Example (as JSON)

```json
{
  "Active": null,
  "Id": null,
  "Name": null
}
```

