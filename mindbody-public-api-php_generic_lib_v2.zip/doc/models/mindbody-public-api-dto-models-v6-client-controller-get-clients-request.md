
# Mindbody Public Api Dto Models V6 Client Controller Get Clients Request

## Structure

`MindbodyPublicApiDtoModelsV6ClientControllerGetClientsRequest`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `clientIDs` | `?(string[])` | Optional | The requested client IDs.<br>Default: **all IDs** that the authenticated user’s access level allows.<br /><br>Note: You can fetch information for maximum 20 clients at once. | getClientIDs(): ?array | setClientIDs(?array clientIDs): void |
| `searchText` | `?string` | Optional | Text to use in the search. Can include FirstName, LastName, and Email. Note that user credentials must be provided. | getSearchText(): ?string | setSearchText(?string searchText): void |
| `isProspect` | `?bool` | Optional | When `true`, filters the results to include only those clients marked as prospects for the business.<br /><br>When `false`, indicates that only those clients who are not marked prospects should be returned. | getIsProspect(): ?bool | setIsProspect(?bool isProspect): void |
| `lastModifiedDate` | `?\DateTime` | Optional | Filters the results to include only the clients that have been modified on or after this date. | getLastModifiedDate(): ?\DateTime | setLastModifiedDate(?\DateTime lastModifiedDate): void |
| `uniqueIds` | `?(int[])` | Optional | Filters results to clients with these `UniqueIDs`. This parameter cannot be used with `ClientIDs` or `SearchText`.<br>Default: **all UniqueIDs** that the authenticated user’s access level allows. | getUniqueIds(): ?array | setUniqueIds(?array uniqueIds): void |
| `includeInactive` | `?bool` | Optional | When `true`, indicates the results to include active and inactive clients.<br /><br>When `false`, indicates that only those clients who are marked as active should be returned.<br>Default: **false** | getIncludeInactive(): ?bool | setIncludeInactive(?bool includeInactive): void |
| `limit` | `?int` | Optional | Number of results to include, defaults to 100 | getLimit(): ?int | setLimit(?int limit): void |
| `offset` | `?int` | Optional | Page offset, defaults to 0. | getOffset(): ?int | setOffset(?int offset): void |

## Example (as JSON)

```json
{
  "ClientIDs": null,
  "SearchText": null,
  "IsProspect": null,
  "LastModifiedDate": null,
  "UniqueIds": null,
  "IncludeInactive": null,
  "Limit": null,
  "Offset": null
}
```

