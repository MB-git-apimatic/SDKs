
# Mindbody Public Api Dto Models V6 Class Controller Get Courses Request

This is the request class for the get courses API

## Structure

`MindbodyPublicApiDtoModelsV6ClassControllerGetCoursesRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `location_i_ds` | `List of int` | Optional | Return only courses that are available for the specified LocationIds. |
| `course_i_ds` | `List of long\|int` | Optional | Return only courses that are available for the specified CourseIds. |
| `staff_i_ds` | `List of long\|int` | Optional | Return only courses that are available for the specified StaffIds. |
| `program_i_ds` | `List of int` | Optional | Return only courses that are available for the specified ProgramIds. |
| `start_date` | `datetime` | Optional | The start date range. Any active courses that are on or after this day.<br><br />(optional) Defaults to today. |
| `end_date` | `datetime` | Optional | The end date range. Any active courses that are on or before this day.<br><br />(optional) Defaults to StartDate. |
| `semester_i_ds` | `List of int` | Optional | Return only courses that are available for the specified SemesterIds. |
| `limit` | `int` | Optional | Number of results to include, defaults to 100 |
| `offset` | `int` | Optional | Page offset, defaults to 0. |

## Example (as JSON)

```json
{
  "LocationIDs": null,
  "CourseIDs": null,
  "StaffIDs": null,
  "ProgramIDs": null,
  "StartDate": null,
  "EndDate": null,
  "SemesterIDs": null,
  "Limit": null,
  "Offset": null
}
```

