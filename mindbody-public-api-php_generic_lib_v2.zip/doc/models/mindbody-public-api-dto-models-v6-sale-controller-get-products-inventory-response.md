
# Mindbody Public Api Dto Models V6 Sale Controller Get Products Inventory Response

## Structure

`MindbodyPublicApiDtoModelsV6SaleControllerGetProductsInventoryResponse`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `paginationResponse` | [`?MindbodyPublicApiDtoModelsV6PaginationResponse`](../../doc/models/mindbody-public-api-dto-models-v6-pagination-response.md) | Optional | - | getPaginationResponse(): ?MindbodyPublicApiDtoModelsV6PaginationResponse | setPaginationResponse(?MindbodyPublicApiDtoModelsV6PaginationResponse paginationResponse): void |
| `productsInventory` | [`?(MindbodyPublicApiDtoModelsV6ProductsInventory[])`](../../doc/models/mindbody-public-api-dto-models-v6-products-inventory.md) | Optional | Contains information about the products inventory. | getProductsInventory(): ?array | setProductsInventory(?array productsInventory): void |

## Example (as JSON)

```json
{
  "PaginationResponse": null,
  "ProductsInventory": null
}
```

