# Live Stream

```python
live_stream_controller = client.live_stream
```

## Class Name

`LiveStreamController`


# Live Stream Generate Signed Live Stream Url

Create an encrypted link to VWP live stream for third party integration customer.

```python
def live_stream_generate_signed_live_stream_url(self,
                                               request,
                                               site_id,
                                               version,
                                               authorization=None)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `request` | [`MindbodyPublicApiDtoModelsV6LiveStreamControllerGenerateSignedLiveStreamUrlRequest`](../../doc/models/mindbody-public-api-dto-models-v6-live-stream-controller-generate-signed-live-stream-url-request.md) | Body, Required | - |
| `site_id` | `string` | Header, Required | ID of the site from which to pull data. |
| `version` | `string` | Template, Required | - |
| `authorization` | `string` | Header, Optional | A staff user authorization token. |

## Response Type

[`MindbodyPublicApiDtoModelsV6LiveStreamControllerGenerateSignedLiveStreamUrlResponse`](../../doc/models/mindbody-public-api-dto-models-v6-live-stream-controller-generate-signed-live-stream-url-response.md)

## Example Usage

```python
request = MindbodyPublicApiDtoModelsV6LiveStreamControllerGenerateSignedLiveStreamUrlRequest()
site_id = 'siteId8'
version = 'version4'

result = live_stream_controller.live_stream_generate_signed_live_stream_url(request, site_id, version)
```

