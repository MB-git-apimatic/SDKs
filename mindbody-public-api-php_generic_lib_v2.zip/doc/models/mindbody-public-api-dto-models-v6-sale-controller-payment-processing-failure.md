
# Mindbody Public Api Dto Models V6 Sale Controller Payment Processing Failure

Contains information about any payment processing failure.  Specifically for when an SCA challenge is

## Structure

`MindbodyPublicApiDtoModelsV6SaleControllerPaymentProcessingFailure`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `type` | `?string` | Optional | The type of the failure | getType(): ?string | setType(?string type): void |
| `message` | `?string` | Optional | Descriptive message for the failure | getMessage(): ?string | setMessage(?string message): void |
| `authenticationRedirectUrl` | `?string` | Optional | For SCA aware flows, this is the url provided by the bank where the consumer can authorize the transaction | getAuthenticationRedirectUrl(): ?string | setAuthenticationRedirectUrl(?string authenticationRedirectUrl): void |

## Example (as JSON)

```json
{
  "Type": null,
  "Message": null,
  "AuthenticationRedirectUrl": null
}
```

