
# Mindbody Public Api Dto Models V6 Class Controller Remove From Waitlist Request

## Structure

`MindbodyPublicApiDtoModelsV6ClassControllerRemoveFromWaitlistRequest`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `waitlistEntryIds` | `int[]` | Required | A list of `WaitlistEntryIds` to remove from the waiting list. | getWaitlistEntryIds(): array | setWaitlistEntryIds(array waitlistEntryIds): void |

## Example (as JSON)

```json
{
  "WaitlistEntryIds": [
    193
  ]
}
```

