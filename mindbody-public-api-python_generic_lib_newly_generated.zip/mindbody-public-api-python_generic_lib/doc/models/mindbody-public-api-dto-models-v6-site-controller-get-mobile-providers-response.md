
# Mindbody Public Api Dto Models V6 Site Controller Get Mobile Providers Response

Get Mobile Providers Response Object

## Structure

`MindbodyPublicApiDtoModelsV6SiteControllerGetMobileProvidersResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `mobile_providers` | [`List of MindbodyPublicApiCommonModelsMobileProvider`](../../doc/models/mindbody-public-api-common-models-mobile-provider.md) | Optional | A list of mobile providers. |

## Example (as JSON)

```json
{
  "MobileProviders": null
}
```

