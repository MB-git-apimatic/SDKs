
# Visit Response

Visits response properties

## Structure

`VisitResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `visits` | [`Array<Visit>`](../../doc/models/visit.md) | Optional | Visits collection |

## Example (as JSON)

```json
{
  "visits": null
}
```

