
# Mindbody Public Api Dto Models V6 Site Controller Get Session Types Request

## Structure

`MindbodyPublicApiDtoModelsV6SiteControllerGetSessionTypesRequest`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `programIDs` | `?(int[])` | Optional | Filters results to session types that belong to one of the given program IDs. If omitted, all program IDs return. | getProgramIDs(): ?array | setProgramIDs(?array programIDs): void |
| `onlineOnly` | `?bool` | Optional | When `true`, indicates that only the session types that can be booked online should be returned.<br /><br>Default: **false** | getOnlineOnly(): ?bool | setOnlineOnly(?bool onlineOnly): void |
| `limit` | `?int` | Optional | Number of results to include, defaults to 100 | getLimit(): ?int | setLimit(?int limit): void |
| `offset` | `?int` | Optional | Page offset, defaults to 0. | getOffset(): ?int | setOffset(?int offset): void |

## Example (as JSON)

```json
{
  "ProgramIDs": null,
  "OnlineOnly": null,
  "Limit": null,
  "Offset": null
}
```

