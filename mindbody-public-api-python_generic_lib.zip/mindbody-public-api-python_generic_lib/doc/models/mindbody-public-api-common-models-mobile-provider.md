
# Mindbody Public Api Common Models Mobile Provider

## Structure

`MindbodyPublicApiCommonModelsMobileProvider`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `int` | Optional | - |
| `active` | `bool` | Optional | - |
| `provider_name` | `string` | Optional | - |
| `provider_address` | `string` | Optional | - |

## Example (as JSON)

```json
{
  "Id": null,
  "Active": null,
  "ProviderName": null,
  "ProviderAddress": null
}
```

