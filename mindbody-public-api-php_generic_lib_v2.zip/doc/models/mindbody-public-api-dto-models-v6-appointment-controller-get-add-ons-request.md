
# Mindbody Public Api Dto Models V6 Appointment Controller Get Add Ons Request

## Structure

`MindbodyPublicApiDtoModelsV6AppointmentControllerGetAddOnsRequest`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `staffId` | `?int` | Optional | Filter to add-ons only performed by this staff member. | getStaffId(): ?int | setStaffId(?int staffId): void |
| `limit` | `?int` | Optional | Number of results to include, defaults to 100 | getLimit(): ?int | setLimit(?int limit): void |
| `offset` | `?int` | Optional | Page offset, defaults to 0. | getOffset(): ?int | setOffset(?int offset): void |

## Example (as JSON)

```json
{
  "StaffId": null,
  "Limit": null,
  "Offset": null
}
```

