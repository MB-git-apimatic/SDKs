
# Mindbody Public Api Dto Models V6 Site Controller Get Sites Response

## Structure

`MindbodyPublicApiDtoModelsV6SiteControllerGetSitesResponse`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `paginationResponse` | [`?MindbodyPublicApiDtoModelsV6PaginationResponse`](../../doc/models/mindbody-public-api-dto-models-v6-pagination-response.md) | Optional | - | getPaginationResponse(): ?MindbodyPublicApiDtoModelsV6PaginationResponse | setPaginationResponse(?MindbodyPublicApiDtoModelsV6PaginationResponse paginationResponse): void |
| `sites` | [`?(MindbodyPublicApiDtoModelsV6Site[])`](../../doc/models/mindbody-public-api-dto-models-v6-site.md) | Optional | Contains information about the sites. | getSites(): ?array | setSites(?array sites): void |

## Example (as JSON)

```json
{
  "PaginationResponse": null,
  "Sites": null
}
```

