
# Mindbody Public Api Dto Models V6 Client Controller Get Client Complete Info Response

## Structure

`MindbodyPublicApiDtoModelsV6ClientControllerGetClientCompleteInfoResponse`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `client` | [`?MindbodyPublicApiDtoModelsV6ClientWithSuspensionInfo`](../../doc/models/mindbody-public-api-dto-models-v6-client-with-suspension-info.md) | Optional | A Client DTO with Suspension Informatoin | getClient(): ?MindbodyPublicApiDtoModelsV6ClientWithSuspensionInfo | setClient(?MindbodyPublicApiDtoModelsV6ClientWithSuspensionInfo client): void |
| `clientServices` | [`?(MindbodyPublicApiDtoModelsV6ClientService[])`](../../doc/models/mindbody-public-api-dto-models-v6-client-service.md) | Optional | Contains information about client pricing options. | getClientServices(): ?array | setClientServices(?array clientServices): void |
| `clientContracts` | [`?(MindbodyPublicApiDtoModelsV6ClientContract[])`](../../doc/models/mindbody-public-api-dto-models-v6-client-contract.md) | Optional | Contains the details of the client’s contract. | getClientContracts(): ?array | setClientContracts(?array clientContracts): void |
| `clientMemberships` | [`?(MindbodyPublicApiDtoModelsV6ClientMembership[])`](../../doc/models/mindbody-public-api-dto-models-v6-client-membership.md) | Optional | Details about the requested memberships. | getClientMemberships(): ?array | setClientMemberships(?array clientMemberships): void |
| `clientArrivals` | [`?(MindbodyPublicApiDtoModelsV6ClientArrival[])`](../../doc/models/mindbody-public-api-dto-models-v6-client-arrival.md) | Optional | Details about the active client arrival programs. | getClientArrivals(): ?array | setClientArrivals(?array clientArrivals): void |

## Example (as JSON)

```json
{
  "Client": null,
  "ClientServices": null,
  "ClientContracts": null,
  "ClientMemberships": null,
  "ClientArrivals": null
}
```

