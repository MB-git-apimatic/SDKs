
# Gender Preference Enum

The preferred gender of the appointment provider.

## Enumeration

`GenderPreferenceEnum`

## Fields

| Name |
|  --- |
| `NONE` |
| `FEMALE` |
| `MALE` |

