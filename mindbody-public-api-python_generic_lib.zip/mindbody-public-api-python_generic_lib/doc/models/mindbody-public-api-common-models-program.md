
# Mindbody Public Api Common Models Program

## Structure

`MindbodyPublicApiCommonModelsProgram`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `cancel_offset` | `int` | Optional | - |
| `id` | `int` | Optional | - |
| `name` | `string` | Optional | - |
| `schedule_type` | [`ScheduleType2Enum`](../../doc/models/schedule-type-2-enum.md) | Optional | - |
| `content_format` | [`ContentFormatEnum`](../../doc/models/content-format-enum.md) | Optional | - |
| `online_booking_disabled` | `bool` | Optional | - |

## Example (as JSON)

```json
{
  "CancelOffset": null,
  "Id": null,
  "Name": null,
  "ScheduleType": null,
  "ContentFormat": null,
  "OnlineBookingDisabled": null
}
```

