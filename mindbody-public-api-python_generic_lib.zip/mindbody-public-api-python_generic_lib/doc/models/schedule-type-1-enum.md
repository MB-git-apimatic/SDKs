
# Schedule Type 1 Enum

Filters on the provided the schedule type. Either `SessionTypeIds` or `ScheduleType` must be provided.

## Enumeration

`ScheduleType1Enum`

## Fields

| Name |
|  --- |
| `ALL` |
| `CLASS` |
| `ENROLLMENT` |
| `APPOINTMENT` |
| `RESOURCE` |
| `MEDIA` |
| `ARRIVAL` |

