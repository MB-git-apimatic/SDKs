﻿<script type="text/javascript">
monitor('book-a-client-into-a-class');
</script>

> Step 3: Get today's classes:

:::visible {language=http}
```
curl -X GET \
  https://api.mindbodyonline.com/public/v6/class/classes \
  -H 'Api-Key: {yourApiKey}' \
  -H 'Authorization: {staffAuthToken}' \
  -H 'SiteId: {yourSiteId}' \
  -A '{yourAppName}'
```
:::

:::visible {language=csharp}
```
var client = new RestClient("https://api.mindbodyonline.com/public/v6/class/classes");
var request = new RestRequest(Method.GET);
request.AddHeader("Authorization", "{staffAuthToken}");
request.AddHeader("SiteId", "{yourSiteId}");
request.AddHeader("Api-Key", "{yourApiKey}");
IRestResponse response = client.Execute(request);
```
:::

:::visible {language=php}
```
<?php

$request = new HttpRequest();
$request->setUrl('https://api.mindbodyonline.com/public/v6/class/classes');
$request->setMethod(HTTP_METH_GET);

$request->setHeaders(array(
  'Authorization' => '{staffAuthToken}',
  'SiteId' => '{yourSiteId}',
  'Api-Key' => '{yourApiKey}'
));

try {
  $response = $request->send();

  echo $response->getBody();
} catch (HttpException $ex) {
  echo $ex;
}
```
:::

:::visible {language=python}
```
import http.client

conn = http.client.HTTPSConnection("api.mindbodyonline.com")

headers = {
	'Api-Key': "{yourApiKey}",
    'SiteId': "{yourSiteId}",
    'Authorization': "{staffAuthToken}"
    }

conn.request("GET", "/public/v6/class/classes", headers=headers)

res = conn.getresponse()
data = res.read()

print(data.decode("utf-8"))
```
:::

:::visible {language=ruby}
```
require 'uri'
require 'net/http'

url = URI("https://api.mindbodyonline.com/public/v6/class/classes")

http = Net::HTTP.new(url.host, url.port)
http.use_ssl = true
http.verify_mode = OpenSSL::SSL::VERIFY_NONE

request = Net::HTTP::Get.new(url)
request["Api-Key"] = '{yourApiKey}'
request["SiteId"] = '{yourSiteId}'
request["Authorization"] = '{staffAuthToken}'

response = http.request(request)
puts response.read_body
```
:::

> See the [GetClasses](#get-classes) endpoint documentation for an example response.

> Step 4: Add client to a class

:::visible {language=http}
```
curl -X POST \
  https://api.mindbodyonline.com/public/v6/class/addclienttoclass \
  -H 'Content-Type: application/json' \
  -H 'Api-Key: {yourApiKey}' \
  -H 'Authorization: {staffAuthToken}' \
  -H 'SiteId: {yourSiteId}' \
  -A '{yourAppName}' \
  -d '{
    "ClientId": "{clientId}",
    "ClassId": {classId}
}'
```
:::

:::visible {language=csharp}
```
var client = new RestClient("https://api.mindbodyonline.com/public/v6/class/addclienttoclass");
var request = new RestRequest(Method.POST);
request.AddHeader("Authorization", "{staffAuthToken}");
request.AddHeader("SiteId", "{yourSiteId}");
request.AddHeader("Api-Key", "{yourApiKey}");
request.AddParameter("application/json", "{\n\t\"ClientId\": \"{clientId}\",\n\t\"ClassId\": {classId}\n}", ParameterType.RequestBody);
IRestResponse response = client.Execute(request);
```
:::

:::visible {language=php}
```
<?php

$request = new HttpRequest();
$request->setUrl('https://api.mindbodyonline.com/public/v6/class/addclienttoclass');
$request->setMethod(HTTP_METH_POST);

$request->setHeaders(array(
  'Authorization' => '{staffAuthToken}',
  'Content-Type' => 'application/json',
  'SiteId' => '{yourSiteId}',
  'Api-Key' => '{yourApiKey}'
));

$request->setBody('{
    "ClientId": "{clientId}",
    "ClassId": {classId}
}');

try {
  $response = $request->send();

  echo $response->getBody();
} catch (HttpException $ex) {
  echo $ex;
}
```
:::

:::visible {language=python}
```
import http.client

conn = http.client.HTTPSConnection("api.mindbodyonline.com")

payload = "{\n\t\"ClientId\": \"{clientId}\",\n\t\"ClassId\": {classId}\n}"

headers = {endpoint documentation for an example response
    'Content-Type': "application/json",
	'Api-Key': "{yourApiKey}",
    'SiteId': "{yourSiteId}",
    'Authorization': "{staffAuthToken}"
    }

conn.request("POST", "/public/v6/class/addclienttoclass", payload, headers)

res = conn.getresponse()
data = res.read()

print(data.decode("utf-8"))
```
:::

:::visible {language=ruby}
```
require 'uri'
require 'net/http'

url = URI("https://api.mindbodyonline.com/public/v6/class/addclienttoclass")

http = Net::HTTP.new(url.host, url.port)
http.use_ssl = true
http.verify_mode = OpenSSL::SSL::VERIFY_NONE

request = Net::HTTP::Post.new(url)
request["Content-Type"] = 'application/json'
request["Api-Key"] = '{yourApiKey}'
request["SiteId"] = '{yourSiteId}'
request["Authorization"] = '{staffAuthToken}'
request.body = "{\n\t\"ClientId\": \"{clientId}\",\n\t\"ClassId\": {classId}\n}"

response = http.request(request)
puts response.read_body
```
:::

> See the [AddClientToClass](#update-add-client-to-class) endpoint documentation for an example response.

<h3 class="toc-ignore">Summary</h3>
This tutorial demonstrates how a staff member can book a client into a class. 

<h3 class="toc-ignore">Workflow</h3>
<ol class="step-list">
    <li>Get a user authentication token for the staff member by passing their login credentials to the authentication endpoint. For a description of the user authentication process, see <a href="#/http/mindbody-public-api-v6-0/authentication/user-tokens">User Tokens</a>. For all following steps, put the token you receive into the <code>Authorization</code> header formatted as <code>Bearer {authToken}</code>.</li>
    <li><p>If the client exists and you have their ID, continue to the next step.</p><p>If the client does not exist, <a href="#add-a-new-client">add the client</a>, then store and use the returned <code>Id</code> property in <strong>Step 4</strong>.</p></li>
    <li>If you know which class the client wants to book, continue to the next step.</p><p>If the client has not yet chosen a class, call the <a href="#get-classes">GetClasses</a> endpoint and store the <code>Id</code> property of the class the client wants to book.</p></li>
    <li>Call the <a href="#add-client-to-class">AddClientToClass</a> endpoint and pass the stored client and class IDs. Note that all payment and booking restrictions are overridden because the booking is made by a staff member. Setting <code>Test</code> to <code>true</code> allows you to test the request without affecting the database.</li>
</ol>
**Note:** Virtual billings are tracked via the "ContentFormats" property, found in the <a href="#program" id="virtual_program">program shared resource</a>. Any class that is booked that contains values "Livestream:Mindbody" or "Livestream:Other", will count as a virtual booking. Any bookings class that is booked under "InPerson" will count as an in-person booking. Please note that booking fees are incurred based on these settings. To help businesses correctly mark their classes as virtual or in-person, please reference the support article titled <a href="https://support.mindbodyonline.com/s/article/Live-stream?language=en_US" id="virtual_live_stream">"Live stream: Setup, scheduling, and <br>pricing, "</a> under the second section-"Setting up live stream classes."
