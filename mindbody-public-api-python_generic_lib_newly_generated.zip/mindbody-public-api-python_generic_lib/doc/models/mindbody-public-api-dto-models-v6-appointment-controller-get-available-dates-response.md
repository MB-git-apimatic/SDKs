
# Mindbody Public Api Dto Models V6 Appointment Controller Get Available Dates Response

## Structure

`MindbodyPublicApiDtoModelsV6AppointmentControllerGetAvailableDatesResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `available_dates` | `List of datetime` | Optional | A list of dates where scheduled appointment availability was found after applying request filters. |

## Example (as JSON)

```json
{
  "AvailableDates": null
}
```

