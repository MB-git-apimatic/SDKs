
# Mindbody Public Api Dto Models V6 Staff Session Type

## Structure

`MindbodyPublicApiDtoModelsV6StaffSessionType`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `staffId` | `?int` | Optional | The staff member Id | getStaffId(): ?int | setStaffId(?int staffId): void |
| `type` | [`?string (TypeEnum)`](../../doc/models/type-enum.md) | Optional | Contains the class description session type. | getType(): ?string | setType(?string type): void |
| `id` | `?int` | Optional | This session type’s unique Id. | getId(): ?int | setId(?int id): void |
| `name` | `?string` | Optional | The name of this session type. | getName(): ?string | setName(?string name): void |
| `numDeducted` | `?int` | Optional | The number of sessions that this session type deducts from the pricing option used to pay for this type of session. | getNumDeducted(): ?int | setNumDeducted(?int numDeducted): void |
| `programId` | `?int` | Optional | This session type’s service category Id. | getProgramId(): ?int | setProgramId(?int programId): void |
| `category` | `?string` | Optional | This session type’s category. | getCategory(): ?string | setCategory(?string category): void |
| `categoryId` | `?int` | Optional | This session type’s category Id. | getCategoryId(): ?int | setCategoryId(?int categoryId): void |
| `subcategory` | `?string` | Optional | This session type’s subcategory. | getSubcategory(): ?string | setSubcategory(?string subcategory): void |
| `subcategoryId` | `?int` | Optional | This session type’s subcategory Id. | getSubcategoryId(): ?int | setSubcategoryId(?int subcategoryId): void |
| `timeLength` | `?int` | Optional | - | getTimeLength(): ?int | setTimeLength(?int timeLength): void |
| `prepTime` | `?int` | Optional | Prep time in minutes | getPrepTime(): ?int | setPrepTime(?int prepTime): void |
| `finishTime` | `?int` | Optional | Finish time in minutes | getFinishTime(): ?int | setFinishTime(?int finishTime): void |
| `payRateType` | `?string` | Optional | The pay rate type | getPayRateType(): ?string | setPayRateType(?string payRateType): void |
| `payRateAmount` | `?float` | Optional | The pay rate amount | getPayRateAmount(): ?float | setPayRateAmount(?float payRateAmount): void |

## Example (as JSON)

```json
{
  "StaffId": null,
  "Type": null,
  "Id": null,
  "Name": null,
  "NumDeducted": null,
  "ProgramId": null,
  "Category": null,
  "CategoryId": null,
  "Subcategory": null,
  "SubcategoryId": null,
  "TimeLength": null,
  "PrepTime": null,
  "FinishTime": null,
  "PayRateType": null,
  "PayRateAmount": null
}
```

