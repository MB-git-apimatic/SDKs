
# Mindbody Public Api Dto Models V6 Program Membership

## Structure

`MindbodyPublicApiDtoModelsV6ProgramMembership`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `int` | Optional | The service category’s ID. |
| `name` | `string` | Optional | The name of this service category. |

## Example (as JSON)

```json
{
  "Id": null,
  "Name": null
}
```

