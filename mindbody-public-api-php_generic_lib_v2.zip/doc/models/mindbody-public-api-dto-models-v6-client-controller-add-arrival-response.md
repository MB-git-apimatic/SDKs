
# Mindbody Public Api Dto Models V6 Client Controller Add Arrival Response

## Structure

`MindbodyPublicApiDtoModelsV6ClientControllerAddArrivalResponse`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `arrivalAdded` | `?bool` | Optional | When `true`, indicates that the arrival was added to the database. | getArrivalAdded(): ?bool | setArrivalAdded(?bool arrivalAdded): void |
| `clientService` | [`?MindbodyPublicApiDtoModelsV6ClientService`](../../doc/models/mindbody-public-api-dto-models-v6-client-service.md) | Optional | A service that is on a client's account. | getClientService(): ?MindbodyPublicApiDtoModelsV6ClientService | setClientService(?MindbodyPublicApiDtoModelsV6ClientService clientService): void |

## Example (as JSON)

```json
{
  "ArrivalAdded": null,
  "ClientService": null
}
```

