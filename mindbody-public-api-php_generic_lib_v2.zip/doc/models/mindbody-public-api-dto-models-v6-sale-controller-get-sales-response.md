
# Mindbody Public Api Dto Models V6 Sale Controller Get Sales Response

## Structure

`MindbodyPublicApiDtoModelsV6SaleControllerGetSalesResponse`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `paginationResponse` | [`?MindbodyPublicApiDtoModelsV6PaginationResponse`](../../doc/models/mindbody-public-api-dto-models-v6-pagination-response.md) | Optional | - | getPaginationResponse(): ?MindbodyPublicApiDtoModelsV6PaginationResponse | setPaginationResponse(?MindbodyPublicApiDtoModelsV6PaginationResponse paginationResponse): void |
| `sales` | [`?(MindbodyPublicApiDtoModelsV6Sale[])`](../../doc/models/mindbody-public-api-dto-models-v6-sale.md) | Optional | Contains the Sale objects, each of which describes the sale and payment for a purchase event. | getSales(): ?array | setSales(?array sales): void |

## Example (as JSON)

```json
{
  "PaginationResponse": null,
  "Sales": null
}
```

