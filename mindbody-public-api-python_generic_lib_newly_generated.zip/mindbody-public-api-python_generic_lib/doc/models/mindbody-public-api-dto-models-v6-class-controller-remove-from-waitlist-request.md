
# Mindbody Public Api Dto Models V6 Class Controller Remove From Waitlist Request

## Structure

`MindbodyPublicApiDtoModelsV6ClassControllerRemoveFromWaitlistRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `waitlist_entry_ids` | `List of int` | Required | A list of `WaitlistEntryIds` to remove from the waiting list. |

## Example (as JSON)

```json
{
  "WaitlistEntryIds": [
    193
  ]
}
```

