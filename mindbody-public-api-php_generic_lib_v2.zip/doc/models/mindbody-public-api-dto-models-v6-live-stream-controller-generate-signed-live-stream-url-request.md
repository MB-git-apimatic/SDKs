
# Mindbody Public Api Dto Models V6 Live Stream Controller Generate Signed Live Stream Url Request

Request to create an encrypted live stream url

## Structure

`MindbodyPublicApiDtoModelsV6LiveStreamControllerGenerateSignedLiveStreamUrlRequest`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `clientId` | `?int` | Optional | Id of client at the studio | getClientId(): ?int | setClientId(?int clientId): void |
| `subscriberId` | `?int` | Optional | Id of studio aka studioId/siteId | getSubscriberId(): ?int | setSubscriberId(?int subscriberId): void |
| `userDisplayName` | `?string` | Optional | User name displayed in VWP live stream | getUserDisplayName(): ?string | setUserDisplayName(?string userDisplayName): void |
| `serviceId` | `?int` | Optional | Id of class instance at studio on given date/time right now since it only supports classes (different from class id) | getServiceId(): ?int | setServiceId(?int serviceId): void |
| `apiUser` | `?string` | Optional | Identification of 3rd party integrator | getApiUser(): ?string | setApiUser(?string apiUser): void |
| `serviceType` | `?string` | Optional | Possible values are: "class", "appointment" | getServiceType(): ?string | setServiceType(?string serviceType): void |

## Example (as JSON)

```json
{
  "ClientId": null,
  "SubscriberId": null,
  "UserDisplayName": null,
  "ServiceId": null,
  "ApiUser": null,
  "ServiceType": null
}
```

