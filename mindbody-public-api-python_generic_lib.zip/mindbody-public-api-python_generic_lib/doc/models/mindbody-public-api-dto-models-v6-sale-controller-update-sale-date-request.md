
# Mindbody Public Api Dto Models V6 Sale Controller Update Sale Date Request

Update Sales Date Request Model

## Structure

`MindbodyPublicApiDtoModelsV6SaleControllerUpdateSaleDateRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `sale_id` | `long\|int` | Optional | - |
| `sale_date` | `datetime` | Optional | - |

## Example (as JSON)

```json
{
  "SaleID": null,
  "SaleDate": null
}
```

