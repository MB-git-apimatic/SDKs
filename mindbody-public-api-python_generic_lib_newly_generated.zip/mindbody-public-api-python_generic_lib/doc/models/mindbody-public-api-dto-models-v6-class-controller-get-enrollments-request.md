
# Mindbody Public Api Dto Models V6 Class Controller Get Enrollments Request

## Structure

`MindbodyPublicApiDtoModelsV6ClassControllerGetEnrollmentsRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `class_schedule_ids` | `List of int` | Optional | A list of the requested class schedule IDs. If omitted, all class schedule IDs return. |
| `end_date` | `datetime` | Optional | The end of the date range. The response returns any active enrollments that occur on or before this day.<br /><br>Default: **StartDate** |
| `location_ids` | `List of int` | Optional | List of the IDs for the requested locations. If omitted, all location IDs return. |
| `program_ids` | `List of int` | Optional | List of the IDs for the requested programs. If omitted, all program IDs return. |
| `session_type_ids` | `List of int` | Optional | List of the IDs for the requested session types. If omitted, all session types IDs return. |
| `staff_ids` | `List of long\|int` | Optional | List of the IDs for the requested staff IDs. If omitted, all staff IDs return. |
| `start_date` | `datetime` | Optional | The start of the date range. The response returns any active enrollments that occur on or after this day.<br /><br>Default: **today’s date** |
| `limit` | `int` | Optional | Number of results to include, defaults to 100 |
| `offset` | `int` | Optional | Page offset, defaults to 0. |

## Example (as JSON)

```json
{
  "ClassScheduleIds": null,
  "EndDate": null,
  "LocationIds": null,
  "ProgramIds": null,
  "SessionTypeIds": null,
  "StaffIds": null,
  "StartDate": null,
  "Limit": null,
  "Offset": null
}
```

