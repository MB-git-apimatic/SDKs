# Pick a Spotv

```php
$pickASpotvController = $client->getPickASpotvController();
```

## Class Name

`PickASpotvController`

## Methods

* [Pick a Spotv Class List](../../doc/controllers/pick-a-spotv.md#pick-a-spotv-class-list)
* [Pick a Spotv Class](../../doc/controllers/pick-a-spotv.md#pick-a-spotv-class)
* [Pick a Spotv Reservation Get](../../doc/controllers/pick-a-spotv.md#pick-a-spotv-reservation-get)
* [Pick a Spotv Reservation Put](../../doc/controllers/pick-a-spotv.md#pick-a-spotv-reservation-put)
* [Pick a Spotv Reservation Post](../../doc/controllers/pick-a-spotv.md#pick-a-spotv-reservation-post)
* [Pick a Spotv Reservation Delete](../../doc/controllers/pick-a-spotv.md#pick-a-spotv-reservation-delete)


# Pick a Spotv Class List

```php
function pickASpotvClassList(string $siteId, string $version, ?string $authorization = null): array
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `version` | `string` | Template, Required | - |
| `authorization` | `?string` | Header, Optional | A staff user authorization token. |

## Response Type

`array`

## Example Usage

```php
$siteId = '-99';
$version = 'version4';

$result = $pickASpotvController->pickASpotvClassList($siteId, $version);
```


# Pick a Spotv Class

```php
function pickASpotvClass(string $classId, string $siteId, string $version, ?string $authorization = null): array
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `classId` | `string` | Template, Required | - |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `version` | `string` | Template, Required | - |
| `authorization` | `?string` | Header, Optional | A staff user authorization token. |

## Response Type

`array`

## Example Usage

```php
$classId = 'classId0';
$siteId = '-99';
$version = 'version4';

$result = $pickASpotvController->pickASpotvClass($classId, $siteId, $version);
```


# Pick a Spotv Reservation Get

```php
function pickASpotvReservationGet(
    string $pathInfo,
    string $siteId,
    string $version,
    ?string $authorization = null
): array
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `pathInfo` | `string` | Template, Required | - |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `version` | `string` | Template, Required | - |
| `authorization` | `?string` | Header, Optional | A staff user authorization token. |

## Response Type

`array`

## Example Usage

```php
$pathInfo = 'pathInfo8';
$siteId = '-99';
$version = 'version4';

$result = $pickASpotvController->pickASpotvReservationGet($pathInfo, $siteId, $version);
```


# Pick a Spotv Reservation Put

```php
function pickASpotvReservationPut(
    string $pathInfo,
    string $siteId,
    string $version,
    ?string $authorization = null
): array
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `pathInfo` | `string` | Template, Required | - |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `version` | `string` | Template, Required | - |
| `authorization` | `?string` | Header, Optional | A staff user authorization token. |

## Response Type

`array`

## Example Usage

```php
$pathInfo = 'pathInfo8';
$siteId = '-99';
$version = 'version4';

$result = $pickASpotvController->pickASpotvReservationPut($pathInfo, $siteId, $version);
```


# Pick a Spotv Reservation Post

```php
function pickASpotvReservationPost(
    string $pathInfo,
    string $siteId,
    string $version,
    ?string $authorization = null
): array
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `pathInfo` | `string` | Template, Required | - |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `version` | `string` | Template, Required | - |
| `authorization` | `?string` | Header, Optional | A staff user authorization token. |

## Response Type

`array`

## Example Usage

```php
$pathInfo = 'pathInfo8';
$siteId = '-99';
$version = 'version4';

$result = $pickASpotvController->pickASpotvReservationPost($pathInfo, $siteId, $version);
```


# Pick a Spotv Reservation Delete

```php
function pickASpotvReservationDelete(
    string $pathInfo,
    string $siteId,
    string $version,
    ?string $authorization = null
): array
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `pathInfo` | `string` | Template, Required | - |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `version` | `string` | Template, Required | - |
| `authorization` | `?string` | Header, Optional | A staff user authorization token. |

## Response Type

`array`

## Example Usage

```php
$pathInfo = 'pathInfo8';
$siteId = '-99';
$version = 'version4';

$result = $pickASpotvController->pickASpotvReservationDelete($pathInfo, $siteId, $version);
```

