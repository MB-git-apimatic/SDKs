
# Mindbody Public Api Dto Models V6 Client Controller Get Client Contracts Request

## Structure

`MindbodyPublicApiDtoModelsV6ClientControllerGetClientContractsRequest`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `clientId` | `string` | Required | The ID of the client. | getClientId(): string | setClientId(string clientId): void |
| `crossRegionalLookup` | `?bool` | Optional | When `true`, indicates that the requesting client’s cross regional contracts are returned, if any.<br /><br>When `false`, indicates that cross regional contracts are not returned. | getCrossRegionalLookup(): ?bool | setCrossRegionalLookup(?bool crossRegionalLookup): void |
| `clientAssociatedSitesOffset` | `?int` | Optional | Determines how many sites are skipped over when retrieving a client’s cross regional contracts. Used when a client ID is linked to more than ten sites in an organization. Only a maximum of ten site databases are queried when this call is made and `CrossRegionalLookup` is set to `true`. To change which sites are queried, change this offset value.<br>Default: **0** | getClientAssociatedSitesOffset(): ?int | setClientAssociatedSitesOffset(?int clientAssociatedSitesOffset): void |
| `limit` | `?int` | Optional | Number of results to include, defaults to 100 | getLimit(): ?int | setLimit(?int limit): void |
| `offset` | `?int` | Optional | Page offset, defaults to 0. | getOffset(): ?int | setOffset(?int offset): void |

## Example (as JSON)

```json
{
  "ClientId": "ClientId6",
  "CrossRegionalLookup": null,
  "ClientAssociatedSitesOffset": null,
  "Limit": null,
  "Offset": null
}
```

