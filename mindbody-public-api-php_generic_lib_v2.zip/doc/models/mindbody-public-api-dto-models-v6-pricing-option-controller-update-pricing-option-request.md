
# Mindbody Public Api Dto Models V6 Pricing Option Controller Update Pricing Option Request

To Update pricing option data

## Structure

`MindbodyPublicApiDtoModelsV6PricingOptionControllerUpdatePricingOptionRequest`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `productId` | `float` | Required | The id of the pricing option (legacy Id in mongo db) | getProductId(): float | setProductId(float productId): void |
| `name` | `?string` | Optional | Pricing option name.<br>**Constraints**: *Minimum Length*: `0`, *Maximum Length*: `100` | getName(): ?string | setName(?string name): void |
| `price` | `?float` | Optional | Price of this Pricing option. | getPrice(): ?float | setPrice(?float price): void |
| `onlinePrice` | `?float` | Optional | Online price of this Pricing option. | getOnlinePrice(): ?float | setOnlinePrice(?float onlinePrice): void |
| `count` | `?int` | Optional | Number of sessions for this pricing option<br>**Constraints**: `>= 1`, `<= 2147483647` | getCount(): ?int | setCount(?int count): void |
| `sellOnline` | `?bool` | Optional | Whether this pricing option sell online or not | getSellOnline(): ?bool | setSellOnline(?bool sellOnline): void |
| `revenueCategory` | `?string` | Optional | Revenue Category of this pricing option<br>**Constraints**: *Minimum Length*: `0`, *Maximum Length*: `35` | getRevenueCategory(): ?string | setRevenueCategory(?string revenueCategory): void |
| `discontinued` | `?bool` | Optional | Whether this pricing option active or inactive | getDiscontinued(): ?bool | setDiscontinued(?bool discontinued): void |
| `membershipId` | `?int` | Optional | The ID of the membership required to purchase the pricing option<br>Default is -1 and will not update Membership if it is not passed in body | getMembershipId(): ?int | setMembershipId(?int membershipId): void |
| `isThirdPartyDiscountPricing` | `?bool` | Optional | Is this pricing option sold at discounted rates by third-parties<br>Once set to true it cannot be changed | getIsThirdPartyDiscountPricing(): ?bool | setIsThirdPartyDiscountPricing(?bool isThirdPartyDiscountPricing): void |
| `priority` | `?string` | Optional | The priority of the pricing option<br>Priority can be set to Low(-1), Medium (0), High(1) | getPriority(): ?string | setPriority(?string priority): void |
| `sellAtLocationIds` | `?(int[])` | Optional | The location IDs where this pricing option is sold<br>(default is null and will not update SellAtLocation if it is not passed in body) | getSellAtLocationIds(): ?array | setSellAtLocationIds(?array sellAtLocationIds): void |
| `useAtLocationIds` | `?(int[])` | Optional | The location IDs where this pricing option is used<br>(default is null and will not update UseAtLocation if it is not passed in body) | getUseAtLocationIds(): ?array | setUseAtLocationIds(?array useAtLocationIds): void |
| `expirationUnit` | `?string` | Optional | The Expiration unit, either Days or Months | getExpirationUnit(): ?string | setExpirationUnit(?string expirationUnit): void |
| `expirationLength` | `?int` | Optional | The number of days or months that the pricing option is active for.<br>**Constraints**: `>= 1`, `<= 32767` | getExpirationLength(): ?int | setExpirationLength(?int expirationLength): void |
| `expirationType` | `?string` | Optional | The date the pricing option begins its activation,<br>either the SaleDate or DateOfClientFirstVisit | getExpirationType(): ?string | setExpirationType(?string expirationType): void |
| `restrictedMembershipIds` | `?(int[])` | Optional | This pricing option can be used under these memberships only<br>If null/empty then not restricted to any membership | getRestrictedMembershipIds(): ?array | setRestrictedMembershipIds(?array restrictedMembershipIds): void |

## Example (as JSON)

```json
{
  "ProductId": 82.96,
  "Name": null,
  "Price": null,
  "OnlinePrice": null,
  "Count": null,
  "SellOnline": null,
  "RevenueCategory": null,
  "Discontinued": null,
  "MembershipId": null,
  "IsThirdPartyDiscountPricing": null,
  "Priority": null,
  "SellAtLocationIds": null,
  "UseAtLocationIds": null,
  "ExpirationUnit": null,
  "ExpirationLength": null,
  "ExpirationType": null,
  "RestrictedMembershipIds": null
}
```

