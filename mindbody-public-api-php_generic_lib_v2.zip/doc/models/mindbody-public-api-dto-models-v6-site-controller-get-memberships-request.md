
# Mindbody Public Api Dto Models V6 Site Controller Get Memberships Request

## Structure

`MindbodyPublicApiDtoModelsV6SiteControllerGetMembershipsRequest`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `membershipIds` | `?(int[])` | Optional | The requested membership IDs.<br /><br>Default: **all** IDs that the authenticated user’s access level allows. | getMembershipIds(): ?array | setMembershipIds(?array membershipIds): void |

## Example (as JSON)

```json
{
  "MembershipIds": null
}
```

