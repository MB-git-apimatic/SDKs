
# Mindbody Public Api Dto Models V6 Client Reward Transaction

Client reward transaction

## Structure

`MindbodyPublicApiDtoModelsV6ClientRewardTransaction`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `action_date_time` | `datetime` | Optional | Timestamp of the transaction |
| `action` | [`Action9Enum`](../../doc/models/action-9-enum.md) | Optional | Action that was performed |
| `source` | `string` | Optional | Source of transaction |
| `source_id` | `long\|int` | Optional | Unique ID of transaction type |
| `expiration_date_time` | `datetime` | Optional | Expiration of earned points |
| `points` | `long\|int` | Optional | Value of the transaction |

## Example (as JSON)

```json
{
  "ActionDateTime": null,
  "Action": null,
  "Source": null,
  "SourceID": null,
  "ExpirationDateTime": null,
  "Points": null
}
```

