
# Mindbody Public Api Dto Models V6 Client Controller Add Formula Note Request

## Structure

`MindbodyPublicApiDtoModelsV6ClientControllerAddFormulaNoteRequest`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `clientId` | `string` | Required | Required. The ID of the client who needs to have a formula note added. | getClientId(): string | setClientId(string clientId): void |
| `appointmentId` | `?int` | Optional | The appointment ID that the formula note is related to. | getAppointmentId(): ?int | setAppointmentId(?int appointmentId): void |
| `note` | `string` | Required | The new formula note text. | getNote(): string | setNote(string note): void |

## Example (as JSON)

```json
{
  "ClientId": "ClientId6",
  "AppointmentId": null,
  "Note": "Note0"
}
```

