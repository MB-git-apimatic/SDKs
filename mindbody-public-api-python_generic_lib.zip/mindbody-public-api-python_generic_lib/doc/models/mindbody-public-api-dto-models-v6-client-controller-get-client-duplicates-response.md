
# Mindbody Public Api Dto Models V6 Client Controller Get Client Duplicates Response

## Structure

`MindbodyPublicApiDtoModelsV6ClientControllerGetClientDuplicatesResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `pagination_response` | [`MindbodyPublicApiDtoModelsV6PaginationResponse`](../../doc/models/mindbody-public-api-dto-models-v6-pagination-response.md) | Optional | - |
| `client_duplicates` | [`List of MindbodyPublicApiDtoModelsV6ClientDuplicate`](../../doc/models/mindbody-public-api-dto-models-v6-client-duplicate.md) | Optional | The requested clients. |

## Example (as JSON)

```json
{
  "PaginationResponse": null,
  "ClientDuplicates": null
}
```

