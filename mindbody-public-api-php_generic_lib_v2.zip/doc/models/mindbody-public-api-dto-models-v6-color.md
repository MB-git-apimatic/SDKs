
# Mindbody Public Api Dto Models V6 Color

A color used by products.

## Structure

`MindbodyPublicApiDtoModelsV6Color`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `id` | `?int` | Optional | The ID of the product color. | getId(): ?int | setId(?int id): void |
| `name` | `?string` | Optional | The name of the product color. | getName(): ?string | setName(?string name): void |

## Example (as JSON)

```json
{
  "Id": null,
  "Name": null
}
```

