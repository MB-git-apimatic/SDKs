﻿<script type="text/javascript">
monitor('user-tokens');
</script>

> Example request to the Issue endpoint for user tokens:

:::visible {language=http}
```
curl -X POST \
  https://api.mindbodyonline.com/public/v6/usertoken/issue \
  -H 'Content-Type: application/json' \
  -H 'Api-Key: {yourApiKey}' \
  -H 'SiteId: {yourSiteId}' \
  -A '{yourAppName}' \
  -d '{
	"Username": "{staffUserName}",
	"Password": "{staffPassword}"
}'
```
:::

:::visible {language=csharp}
```csharp
var client = new RestClient("https://api.mindbodyonline.com/public/v6/usertoken/issue");
var request = new RestRequest(Method.POST);
request.AddHeader("SiteId", "{yourSiteId}");
request.AddHeader("Api-Key", "{yourApiKey}");
request.AddParameter("application/json", "{\r\n\t\"Username\": \"{staffUserName}\",\r\n\t\"Password\": \"{staffPassword}\"\r\n}", ParameterType.RequestBody);
IRestResponse response = client.Execute(request);
```
:::

:::visible {language=php}
```
<?php

$request = new HttpRequest();
$request->setUrl('https://api.mindbodyonline.com/public/v6/usertoken/issue');
$request->setMethod(HTTP_METH_POST);

$request->setHeaders(array(
  'Content-Type' => 'application/json',
  'SiteId' => '{yourSiteId}',
  'Api-Key' => '{yourApiKey}'
));

$request->setBody('{
	"Username": "{staffUserName}",
	"Password": "{staffPassword}"
}');

try {
  $response = $request->send();

  echo $response->getBody();
} catch (HttpException $ex) {
  echo $ex;
}
```
:::

:::visible {language=python}
```
import http.client

conn = http.client.HTTPSConnection("api.mindbodyonline.com")

payload = "{\r\n\t\"Username\": \"{staffUserName}\",\r\n\t\"Password\": \"{staffPassword}\"\r\n}"

headers = {
    'Content-Type': "application/json",
	'Api-Key': "{yourApiKey}",
    'SiteId': "{yourSiteId}"
    }

conn.request("POST", "/public/v6/usertoken/issue", payload, headers)

res = conn.getresponse()
data = res.read()

print(data.decode("utf-8"))
```
:::

:::visible {language=ruby}
```
require 'uri'
require 'net/http'

url = URI("https://api.mindbodyonline.com/public/v6/usertoken/issue")

http = Net::HTTP.new(url.host, url.port)
http.use_ssl = true
http.verify_mode = OpenSSL::SSL::VERIFY_NONE

request = Net::HTTP::Post.new(url)
request["Content-Type"] = 'application/json'
request["Api-Key"] = '{yourApiKey}'
request["SiteId"] = '{yourSiteId}'
request.body = "{\r\n\t\"Username\": \"{staffUserName}\",\r\n\t\"Password\": \"{staffPassword}\"\r\n}"

response = http.request(request)
puts response.read_body
```
:::

> Example response body:

```
{
    "TokenType": "Bearer",
    "AccessToken": "e10ce5f8701041ad97efeddhjfbn3288246831e84c52c429f8bd56e6f4bd89a1d",
    "User": {
        "Id": 3,
        "FirstName": "John",
        "LastName": "Smith",
        "Type": "Staff"
    }
}
```

<a href="https://api.mindbodyonline.com/public/v6/usertoken/issue">https://api.mindbodyonline.com/public/v6/usertoken/issue</a>

When users interact with your Public API integration as staff members, they need to get a staff user token for authentication. You can use the `issue` endpoint to get a staff user token, then pass the token in the headers for all of your requests. Note the following:
<ul><li>An unused token expires after seven days.</li><li>A token can only be used with the API key that created it.</li><li>For all endpoints, staff permissions may alter the returned data based on the passed token.</li></ul>

The user token is the equivalent of credentials for a staff member with basic staff permissions. To retrieve a valid user token, you can either pass actual staff credentials or your user credentials in the user token request (see below).

**Please note:** User credentials are automatically created for you whenever you integrate with a `SiteID`. They are the same as your source credentials, with the exception that you will use an underscore (`_`) in front of your source name when using it as the user name. The source password remains the same. This simulates a staff member performing the action in place of a consumer, since a consumer would not be able to perform the action online.

To get the authorization token for a live site, you can run the user token request and pass your user credentials as follows.

<code>curl -X POST \\<br>
&nbsp;&nbsp;https://api.mindbodyonline.com/public/v6/usertoken/issue \\<br>
&nbsp;&nbsp;-H 'Content-Type: application/json' \\<br>
&nbsp;&nbsp;-H 'Api-Key: {yourApiKey}' \\<br>
&nbsp;&nbsp;-H 'SiteId: {yourSiteId}' \\<br>
&nbsp;&nbsp;-A '{yourAppName}' \\<br>
&nbsp;&nbsp;-d '{<br>
&nbsp;&nbsp;&nbsp;&nbsp;"Username": "_SourceName",<br>
&nbsp;&nbsp;&nbsp;&nbsp;"Password": "SourcePassword"<br>
}'</code>

**For the sandbox site**<br>
To get the Authorization token, you can use the `issue` endpoint to pass the User Credentials of the sandbox test site as follows.

<code>curl -X POST \\<br>
&nbsp;&nbsp;https://api.mindbodyonline.com/public/v6/usertoken/issue \\<br>
&nbsp;&nbsp;-H 'Content-Type: application/json' \\<br>
&nbsp;&nbsp;-H 'Api-Key: {yourApiKey}' \\<br>
&nbsp;&nbsp;-H 'SiteId: -99' \\<br>
&nbsp;&nbsp;-d '{<br>
&nbsp;&nbsp;&nbsp;&nbsp;"Username": "Siteowner",<br>
&nbsp;&nbsp;&nbsp;&nbsp;"Password": "apitest1234"<br>
}'</code>

#### Request Body
**Name** | **Type** | **Description**
--- | --- | ---
**Username** | string | The staff member's username.
**Password** | string | The staff member's password.

#### Response
**Name** | **Type** | **Description**
--- | --- | ---
**AccessToken** | string | The authentication token value.
**TokenType** | string | Bearer.
**User** | object | Contains information about the user represented by the access token.
**User.Id** | number | The user's ID at the business. This is always 0 for Admin and Owner type users.
**User.FirstName** | string | The user's first name.
**User.LastName** | string | The user's last name.
**User.Type** | string | The user's type. Possible values are:<ul><li>Staff</li><li>Owner</li><li>Admin</li></ul>
