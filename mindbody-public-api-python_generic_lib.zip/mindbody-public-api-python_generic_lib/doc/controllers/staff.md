# Staff

```python
staff_controller = client.staff
```

## Class Name

`StaffController`

## Methods

* [Staff Get Staff](../../doc/controllers/staff.md#staff-get-staff)
* [Staff Get Staff Permissions](../../doc/controllers/staff.md#staff-get-staff-permissions)
* [Staff Get Staff Image URL](../../doc/controllers/staff.md#staff-get-staff-image-url)
* [Staff Update Staff Permissions](../../doc/controllers/staff.md#staff-update-staff-permissions)
* [Staff Add Staff](../../doc/controllers/staff.md#staff-add-staff)
* [Staff Update Staff](../../doc/controllers/staff.md#staff-update-staff)
* [Staff Add Staff Availability](../../doc/controllers/staff.md#staff-add-staff-availability)
* [Staff Get Staff Session Types](../../doc/controllers/staff.md#staff-get-staff-session-types)
* [Staff Assign Staff Session Type](../../doc/controllers/staff.md#staff-assign-staff-session-type)
* [Staff Get Sales Reps](../../doc/controllers/staff.md#staff-get-sales-reps)


# Staff Get Staff

Get staff members at a site.

```python
def staff_get_staff(self,
                   site_id,
                   version,
                   authorization=None,
                   request_filters=None,
                   request_limit=None,
                   request_location_id=None,
                   request_offset=None,
                   request_session_type_id=None,
                   request_staff_ids=None,
                   request_start_date_time=None)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `site_id` | `string` | Header, Required | ID of the site from which to pull data. |
| `version` | `string` | Template, Required | - |
| `authorization` | `string` | Header, Optional | A staff user authorization token. |
| `request_filters` | `List of string` | Query, Optional | Filters to apply to the search. Possible values are:<br><br>* StaffViewable<br>* AppointmentInstructor<br>* ClassInstructor<br>* Male<br>* Female |
| `request_limit` | `int` | Query, Optional | Number of results to include, defaults to 100 |
| `request_location_id` | `int` | Query, Optional | Return only staff members that are available at the specified location. You must supply a valid `SessionTypeID` and `StartDateTime` to use this parameter. |
| `request_offset` | `int` | Query, Optional | Page offset, defaults to 0. |
| `request_session_type_id` | `int` | Query, Optional | Return only staff members that are available for the specified session type. You must supply a valid `StartDateTime` and `LocationID` to use this parameter. |
| `request_staff_ids` | `List of long\|int` | Query, Optional | A list of the requested staff IDs. |
| `request_start_date_time` | `datetime` | Query, Optional | Return only staff members that are available at the specified date and time. You must supply a valid `SessionTypeID` and `LocationID` to use this parameter. |

## Response Type

[`MindbodyPublicApiDtoModelsV6StaffControllerGetStaffResponse`](../../doc/models/mindbody-public-api-dto-models-v6-staff-controller-get-staff-response.md)

## Example Usage

```python
site_id = 'siteId8'
version = 'version4'

result = staff_controller.staff_get_staff(site_id, version)
```


# Staff Get Staff Permissions

Get configured staff permissions for a staff member.

```python
def staff_get_staff_permissions(self,
                               request_staff_id,
                               site_id,
                               version,
                               authorization=None)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `request_staff_id` | `long\|int` | Query, Required | The ID of the staff member whose permissions you want to return. |
| `site_id` | `string` | Header, Required | ID of the site from which to pull data. |
| `version` | `string` | Template, Required | - |
| `authorization` | `string` | Header, Optional | A staff user authorization token. |

## Response Type

[`MindbodyPublicApiDtoModelsV6StaffControllerGetStaffPermissionsResponse`](../../doc/models/mindbody-public-api-dto-models-v6-staff-controller-get-staff-permissions-response.md)

## Example Usage

```python
request_staff_id = 180
site_id = 'siteId8'
version = 'version4'

result = staff_controller.staff_get_staff_permissions(request_staff_id, site_id, version)
```


# Staff Get Staff Image URL

Get image URLs for the given staff ID in the request.

```python
def staff_get_staff_image_url(self,
                             site_id,
                             version,
                             authorization=None,
                             request_staff_id=None)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `site_id` | `string` | Header, Required | ID of the site from which to pull data. |
| `version` | `string` | Template, Required | - |
| `authorization` | `string` | Header, Optional | A staff user authorization token. |
| `request_staff_id` | `long\|int` | Query, Optional | A requested staff ID. |

## Response Type

[`MindbodyPublicApiDtoModelsV6StaffControllerGetStaffImageURLResponse`](../../doc/models/mindbody-public-api-dto-models-v6-staff-controller-get-staff-image-url-response.md)

## Example Usage

```python
site_id = 'siteId8'
version = 'version4'

result = staff_controller.staff_get_staff_image_url(site_id, version)
```


# Staff Update Staff Permissions

```python
def staff_update_staff_permissions(self,
                                  request,
                                  site_id,
                                  version,
                                  authorization=None)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `request` | [`MindbodyPublicApiDtoModelsV6StaffControllerUpdateStaffPermissionsRequest`](../../doc/models/mindbody-public-api-dto-models-v6-staff-controller-update-staff-permissions-request.md) | Body, Required | - |
| `site_id` | `string` | Header, Required | ID of the site from which to pull data. |
| `version` | `string` | Template, Required | - |
| `authorization` | `string` | Header, Optional | A staff user authorization token. |

## Response Type

[`MindbodyPublicApiDtoModelsV6StaffControllerUpdateStaffPermissionsResponse`](../../doc/models/mindbody-public-api-dto-models-v6-staff-controller-update-staff-permissions-response.md)

## Example Usage

```python
request = MindbodyPublicApiDtoModelsV6StaffControllerUpdateStaffPermissionsRequest()
request.staff_id = 188
request.permission_group_name = 'PermissionGroupName8'
site_id = 'siteId8'
version = 'version4'

result = staff_controller.staff_update_staff_permissions(request, site_id, version)
```


# Staff Add Staff

```python
def staff_add_staff(self,
                   request,
                   site_id,
                   version,
                   authorization=None)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `request` | [`MindbodyPublicApiDtoModelsV6StaffControllerAddStaffRequest`](../../doc/models/mindbody-public-api-dto-models-v6-staff-controller-add-staff-request.md) | Body, Required | - |
| `site_id` | `string` | Header, Required | ID of the site from which to pull data. |
| `version` | `string` | Template, Required | - |
| `authorization` | `string` | Header, Optional | A staff user authorization token. |

## Response Type

[`MindbodyPublicApiDtoModelsV6StaffControllerAddStaffResponse`](../../doc/models/mindbody-public-api-dto-models-v6-staff-controller-add-staff-response.md)

## Example Usage

```python
request = MindbodyPublicApiDtoModelsV6StaffControllerAddStaffRequest()
request.first_name = 'FirstName8'
request.last_name = 'LastName8'
site_id = 'siteId8'
version = 'version4'

result = staff_controller.staff_add_staff(request, site_id, version)
```


# Staff Update Staff

```python
def staff_update_staff(self,
                      request,
                      site_id,
                      version,
                      authorization=None)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `request` | [`MindbodyPublicApiDtoModelsV6StaffControllerUpdateStaffRequest`](../../doc/models/mindbody-public-api-dto-models-v6-staff-controller-update-staff-request.md) | Body, Required | - |
| `site_id` | `string` | Header, Required | ID of the site from which to pull data. |
| `version` | `string` | Template, Required | - |
| `authorization` | `string` | Header, Optional | A staff user authorization token. |

## Response Type

[`MindbodyPublicApiDtoModelsV6StaffControllerUpdateStaffResponse`](../../doc/models/mindbody-public-api-dto-models-v6-staff-controller-update-staff-response.md)

## Example Usage

```python
request = MindbodyPublicApiDtoModelsV6StaffControllerUpdateStaffRequest()
request.id = 142
site_id = 'siteId8'
version = 'version4'

result = staff_controller.staff_update_staff(request, site_id, version)
```


# Staff Add Staff Availability

```python
def staff_add_staff_availability(self,
                                request,
                                site_id,
                                version,
                                authorization=None)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `request` | [`MindbodyPublicApiDtoModelsV6StaffControllerAddStaffAvailabilityRequest`](../../doc/models/mindbody-public-api-dto-models-v6-staff-controller-add-staff-availability-request.md) | Body, Required | - |
| `site_id` | `string` | Header, Required | ID of the site from which to pull data. |
| `version` | `string` | Template, Required | - |
| `authorization` | `string` | Header, Optional | A staff user authorization token. |

## Response Type

`void`

## Example Usage

```python
request = MindbodyPublicApiDtoModelsV6StaffControllerAddStaffAvailabilityRequest()
request.staff_id = 188
request.is_availability = False
request.days_of_week = ['DaysOfWeek7']
request.start_time = 'StartTime4'
request.end_time = 'EndTime0'
request.start_date = 'StartDate0'
request.end_date = 'EndDate6'
site_id = 'siteId8'
version = 'version4'

result = staff_controller.staff_add_staff_availability(request, site_id, version)
```


# Staff Get Staff Session Types

Get the session types used at a site for a staff member.

```python
def staff_get_staff_session_types(self,
                                 request_staff_id,
                                 site_id,
                                 version,
                                 authorization=None,
                                 request_limit=None,
                                 request_offset=None,
                                 request_online_only=None,
                                 request_program_ids=None)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `request_staff_id` | `long\|int` | Query, Required | Filters returned session types to only those the staff member performs.  Staff should be active. |
| `site_id` | `string` | Header, Required | ID of the site from which to pull data. |
| `version` | `string` | Template, Required | - |
| `authorization` | `string` | Header, Optional | A staff user authorization token. |
| `request_limit` | `int` | Query, Optional | Number of results to include, defaults to 100 |
| `request_offset` | `int` | Query, Optional | Page offset, defaults to 0. |
| `request_online_only` | `bool` | Query, Optional | Only session types that can be booked online. |
| `request_program_ids` | `List of int` | Query, Optional | Filters results to session types that belong in program IDs. |

## Response Type

[`MindbodyPublicApiDtoModelsV6StaffControllerGetStaffSessionTypesResponse`](../../doc/models/mindbody-public-api-dto-models-v6-staff-controller-get-staff-session-types-response.md)

## Example Usage

```python
request_staff_id = 180
site_id = 'siteId8'
version = 'version4'

result = staff_controller.staff_get_staff_session_types(request_staff_id, site_id, version)
```


# Staff Assign Staff Session Type

```python
def staff_assign_staff_session_type(self,
                                   request,
                                   site_id,
                                   version,
                                   authorization=None)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `request` | [`MindbodyPublicApiDtoModelsV6StaffControllerAssignStaffSessionTypeRequest`](../../doc/models/mindbody-public-api-dto-models-v6-staff-controller-assign-staff-session-type-request.md) | Body, Required | - |
| `site_id` | `string` | Header, Required | ID of the site from which to pull data. |
| `version` | `string` | Template, Required | - |
| `authorization` | `string` | Header, Optional | A staff user authorization token. |

## Response Type

[`MindbodyPublicApiDtoModelsV6StaffControllerAssignStaffSessionTypeResponse`](../../doc/models/mindbody-public-api-dto-models-v6-staff-controller-assign-staff-session-type-response.md)

## Example Usage

```python
request = MindbodyPublicApiDtoModelsV6StaffControllerAssignStaffSessionTypeRequest()
request.staff_id = 188
request.session_type_id = 82
request.active = False
site_id = 'siteId8'
version = 'version4'

result = staff_controller.staff_assign_staff_session_type(request, site_id, version)
```


# Staff Get Sales Reps

```python
def staff_get_sales_reps(self,
                        site_id,
                        version,
                        authorization=None,
                        request_active_only=None,
                        request_limit=None,
                        request_offset=None,
                        request_sales_rep_numbers=None)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `site_id` | `string` | Header, Required | ID of the site from which to pull data. |
| `version` | `string` | Template, Required | - |
| `authorization` | `string` | Header, Optional | A staff user authorization token. |
| `request_active_only` | `bool` | Query, Optional | This is to filter out the active sales rep from the list |
| `request_limit` | `int` | Query, Optional | Number of results to include, defaults to 100 |
| `request_offset` | `int` | Query, Optional | Page offset, defaults to 0. |
| `request_sales_rep_numbers` | `List of int` | Query, Optional | This is the list of rep numbers to be fetched |

## Response Type

[`MindbodyPublicApiDtoModelsV6StaffControllerGetSalesRepsResponse`](../../doc/models/mindbody-public-api-dto-models-v6-staff-controller-get-sales-reps-response.md)

## Example Usage

```python
site_id = 'siteId8'
version = 'version4'

result = staff_controller.staff_get_sales_reps(site_id, version)
```

