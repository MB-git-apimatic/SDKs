
# Mindbody Public Api Dto Models V6 Waitlist Entry

## Structure

`MindbodyPublicApiDtoModelsV6WaitlistEntry`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `classDate` | `?\DateTime` | Optional | The date of the class or enrollment. | getClassDate(): ?\DateTime | setClassDate(?\DateTime classDate): void |
| `classId` | `?int` | Optional | The ID of the class or enrollment. | getClassId(): ?int | setClassId(?int classId): void |
| `classSchedule` | [`?MindbodyPublicApiDtoModelsV6ClassSchedule`](../../doc/models/mindbody-public-api-dto-models-v6-class-schedule.md) | Optional | Represents a single class instance. The class meets at the start time, goes until the end time. | getClassSchedule(): ?MindbodyPublicApiDtoModelsV6ClassSchedule | setClassSchedule(?MindbodyPublicApiDtoModelsV6ClassSchedule classSchedule): void |
| `client` | [`?MindbodyPublicApiDtoModelsV6Client`](../../doc/models/mindbody-public-api-dto-models-v6-client.md) | Optional | A Client | getClient(): ?MindbodyPublicApiDtoModelsV6Client | setClient(?MindbodyPublicApiDtoModelsV6Client client): void |
| `enrollmentDateForward` | `?\DateTime` | Optional | If the waiting list entry was created for an enrollment, this is the date on or after which the client can be added to the enrollment from the waitlist. | getEnrollmentDateForward(): ?\DateTime | setEnrollmentDateForward(?\DateTime enrollmentDateForward): void |
| `id` | `?int` | Optional | The ID of the waiting list entry. | getId(): ?int | setId(?int id): void |
| `requestDateTime` | `?\DateTime` | Optional | The date and time that the request to be on the waiting list was made. | getRequestDateTime(): ?\DateTime | setRequestDateTime(?\DateTime requestDateTime): void |
| `visitRefNo` | `?int` | Optional | The ID of the visit that is associated with the waiting list entry. | getVisitRefNo(): ?int | setVisitRefNo(?int visitRefNo): void |
| `web` | `?bool` | Optional | If `true`, the entry on the waiting list was requested online.<br /><br>If `false`, the entry on the waiting list was requested off-line, for example in person or by phone. | getWeb(): ?bool | setWeb(?bool web): void |

## Example (as JSON)

```json
{
  "ClassDate": null,
  "ClassId": null,
  "ClassSchedule": null,
  "Client": null,
  "EnrollmentDateForward": null,
  "Id": null,
  "RequestDateTime": null,
  "VisitRefNo": null,
  "Web": null
}
```

