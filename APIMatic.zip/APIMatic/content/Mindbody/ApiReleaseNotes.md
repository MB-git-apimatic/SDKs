﻿## API Release Notes
Check out the [API Release Notes](/Resources/ApiReleaseNotes) regularly for updates on all our APIs.