
# Mindbody Public Api Dto Models V6 Client Controller Add Contact Log Request

## Structure

`MindbodyPublicApiDtoModelsV6ClientControllerAddContactLogRequest`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `clientId` | `string` | Required | The ID of the client whose contact log is being added. | getClientId(): string | setClientId(string clientId): void |
| `assignedToStaffId` | `?int` | Optional | The ID of the staff member to whom the contact log is assigned. | getAssignedToStaffId(): ?int | setAssignedToStaffId(?int assignedToStaffId): void |
| `text` | `?string` | Optional | The body of the contact log. | getText(): ?string | setText(?string text): void |
| `followupByDate` | `?\DateTime` | Optional | The date by which the assigned staff member should complete this contact log. | getFollowupByDate(): ?\DateTime | setFollowupByDate(?\DateTime followupByDate): void |
| `contactMethod` | `string` | Required | How the client wants to be contacted. | getContactMethod(): string | setContactMethod(string contactMethod): void |
| `contactName` | `?string` | Optional | The name of the person to be contacted by the assigned staff member. | getContactName(): ?string | setContactName(?string contactName): void |
| `isComplete` | `?bool` | Optional | When `true`, indicates that the contact log is complete.<br>When `false`, indicates the contact log isn’t complete. | getIsComplete(): ?bool | setIsComplete(?bool isComplete): void |
| `comments` | `?(string[])` | Optional | Any comments on the contact log. | getComments(): ?array | setComments(?array comments): void |
| `types` | [`?(MindbodyPublicApiDtoModelsV6AddContactLogType[])`](../../doc/models/mindbody-public-api-dto-models-v6-add-contact-log-type.md) | Optional | The contact log types used to tag this contact log. | getTypes(): ?array | setTypes(?array types): void |
| `test` | `?bool` | Optional | When `true`, indicates that this is a test request and no data is inserted into the subscriber’s database.<br /><br>When `false`, the database is updated. | getTest(): ?bool | setTest(?bool test): void |

## Example (as JSON)

```json
{
  "ClientId": "ClientId6",
  "AssignedToStaffId": null,
  "Text": null,
  "FollowupByDate": null,
  "ContactMethod": "ContactMethod6",
  "ContactName": null,
  "IsComplete": null,
  "Comments": null,
  "Types": null,
  "Test": null
}
```

