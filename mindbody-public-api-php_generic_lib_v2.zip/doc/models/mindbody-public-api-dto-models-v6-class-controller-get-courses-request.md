
# Mindbody Public Api Dto Models V6 Class Controller Get Courses Request

This is the request class for the get courses API

## Structure

`MindbodyPublicApiDtoModelsV6ClassControllerGetCoursesRequest`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `locationIDs` | `?(int[])` | Optional | Return only courses that are available for the specified LocationIds. | getLocationIDs(): ?array | setLocationIDs(?array locationIDs): void |
| `courseIDs` | `?(int[])` | Optional | Return only courses that are available for the specified CourseIds. | getCourseIDs(): ?array | setCourseIDs(?array courseIDs): void |
| `staffIDs` | `?(int[])` | Optional | Return only courses that are available for the specified StaffIds. | getStaffIDs(): ?array | setStaffIDs(?array staffIDs): void |
| `programIDs` | `?(int[])` | Optional | Return only courses that are available for the specified ProgramIds. | getProgramIDs(): ?array | setProgramIDs(?array programIDs): void |
| `startDate` | `?\DateTime` | Optional | The start date range. Any active courses that are on or after this day.<br><br />(optional) Defaults to today. | getStartDate(): ?\DateTime | setStartDate(?\DateTime startDate): void |
| `endDate` | `?\DateTime` | Optional | The end date range. Any active courses that are on or before this day.<br><br />(optional) Defaults to StartDate. | getEndDate(): ?\DateTime | setEndDate(?\DateTime endDate): void |
| `semesterIDs` | `?(int[])` | Optional | Return only courses that are available for the specified SemesterIds. | getSemesterIDs(): ?array | setSemesterIDs(?array semesterIDs): void |
| `limit` | `?int` | Optional | Number of results to include, defaults to 100 | getLimit(): ?int | setLimit(?int limit): void |
| `offset` | `?int` | Optional | Page offset, defaults to 0. | getOffset(): ?int | setOffset(?int offset): void |

## Example (as JSON)

```json
{
  "LocationIDs": null,
  "CourseIDs": null,
  "StaffIDs": null,
  "ProgramIDs": null,
  "StartDate": null,
  "EndDate": null,
  "SemesterIDs": null,
  "Limit": null,
  "Offset": null
}
```

