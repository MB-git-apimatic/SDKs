
# Mindbody Public Api Dto Models V6 Client Controller Formula Note Response

An individual Client Formula Note.

## Structure

`MindbodyPublicApiDtoModelsV6ClientControllerFormulaNoteResponse`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `id` | `?int` | Optional | The unique Id of the Formula Note. | getId(): ?int | setId(?int id): void |
| `clientId` | `?string` | Optional | The unique Id of the Client for the formula note | getClientId(): ?string | setClientId(?string clientId): void |
| `appointmentId` | `?int` | Optional | The unique Id of the Appointment if the Formula Note was added to a specific appointment. | getAppointmentId(): ?int | setAppointmentId(?int appointmentId): void |
| `entryDate` | `?\DateTime` | Optional | The Date the Formula Note was created. | getEntryDate(): ?\DateTime | setEntryDate(?\DateTime entryDate): void |
| `note` | `?string` | Optional | The Note itself | getNote(): ?string | setNote(?string note): void |
| `siteId` | `?int` | Optional | The SiteId where the Formula Note originated. | getSiteId(): ?int | setSiteId(?int siteId): void |
| `siteName` | `?string` | Optional | The name of the Site where the Formula Note originated. | getSiteName(): ?string | setSiteName(?string siteName): void |
| `staffFirstName` | `?string` | Optional | The first name of the Staff for the associated appointment. | getStaffFirstName(): ?string | setStaffFirstName(?string staffFirstName): void |
| `staffLastName` | `?string` | Optional | The last name of the Staff for the associated appointment. | getStaffLastName(): ?string | setStaffLastName(?string staffLastName): void |
| `staffDisplayName` | `?string` | Optional | The display name of the Staff for the associated appointment. | getStaffDisplayName(): ?string | setStaffDisplayName(?string staffDisplayName): void |

## Example (as JSON)

```json
{
  "Id": null,
  "ClientId": null,
  "AppointmentId": null,
  "EntryDate": null,
  "Note": null,
  "SiteId": null,
  "SiteName": null,
  "StaffFirstName": null,
  "StaffLastName": null,
  "StaffDisplayName": null
}
```

