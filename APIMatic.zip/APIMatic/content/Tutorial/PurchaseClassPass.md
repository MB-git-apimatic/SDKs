﻿## Purchase a Class Pass
<script type="text/javascript">
monitor('purchase-a-class-pass');
</script>

> Step 2: Get today's classes

:::visible {language=http}
```
curl -X GET \
  'https://api.mindbodyonline.com/public/v6/class/classes' \
  -H 'Api-Key: {yourApiKey}' \
  -H 'Authorization: {staffAuthToken}' \
  -H 'SiteId: {yourSiteId}' \
  -A '{yourAppName}'
```
:::

:::visible {language=csharp}
```
var client = new RestClient("https://api.mindbodyonline.com/public/v6/class/classes");
var request = new RestRequest(Method.GET);
request.AddHeader("Api-Key", "{yourApiKey}");
request.AddHeader("SiteId", "{yourSiteId}");
request.AddHeader("Authorization", "{staffAuthToken}");
IRestResponse response = client.Execute(request);
```
:::

:::visible {language=php}
```
<?php

$request = new HttpRequest();
$request->setUrl('https://api.mindbodyonline.com/public/v6/class/classes');
$request->setMethod(HTTP_METH_GET);

$request->setHeaders(array(
  'Api-Key' => '{yourApiKey}',
  'SiteId' => '{yourSiteId}',
  'Authorization' => '{staffAuthToken}'
));

try {
  $response = $request->send();

  echo $response->getBody();
} catch (HttpException $ex) {
  echo $ex;
}
```
:::

:::visible {language=python}
```
import http.client

conn = http.client.HTTPSConnection("api.mindbodyonline.com")

headers = {
    'Authorization': "{staffAuthToken}",
	'SiteId': "{yourSiteId}",
    'Api-Key': "{yourApiKey}"
    }

conn.request("GET", "/public/v6/class/classes", headers=headers)

res = conn.getresponse()
data = res.read()

print(data.decode("utf-8"))
```
:::

:::visible {language=ruby}
```
require 'uri'
require 'net/http'

url = URI("https://api.mindbodyonline.com/public/v6/class/classes")

http = Net::HTTP.new(url.host, url.port)
http.use_ssl = true
http.verify_mode = OpenSSL::SSL::VERIFY_NONE

request = Net::HTTP::Get.new(url)
request["Authorization"] = '{staffAuthToken}'
request["SiteId"] = '{yourSiteId}'
request["Api-Key"] = '{yourApiKey}'

response = http.request(request)
puts response.read_body
```
:::

> Step 3: Find services that pay for the selected class

:::visible {language=http}
```
curl -X GET \
  'https://api.mindbodyonline.com/public/v6/sale/services?classId=929' \
  -H 'Api-Key: {yourApiKey}' \
  -H 'Authorization: {staffAuthToken}' \
  -H 'SiteId: {yourSiteId}'
  -A '{yourAppName}'
```
:::

:::visible {language=csharp}
```
var client = new RestClient("https://api.mindbodyonline.com/public/v6/sale/services?classId=929");
var request = new RestRequest(Method.GET);
request.AddHeader("Api-Key", "{yourApiKey}");
request.AddHeader("SiteId", "{yourSiteId}");
request.AddHeader("Authorization", "{staffAuthToken}");
IRestResponse response = client.Execute(request);
```
:::

:::visible {language=php}
```
<?php

$request = new HttpRequest();
$request->setUrl('https://api.mindbodyonline.com/public/v6/sale/services');
$request->setMethod(HTTP_METH_GET);

$request->setQueryData(array(
  'classId' => '929'
));

$request->setHeaders(array(
  'Api-Key' => '{yourApiKey}',
  'SiteId' => '{yourSiteId}',
  'Authorization' => '{staffAuthToken}'
));

try {
  $response = $request->send();

  echo $response->getBody();
} catch (HttpException $ex) {
  echo $ex;
}
```
:::

:::visible {language=python}
```
import http.client

conn = http.client.HTTPSConnection("api.mindbodyonline.com")

headers = {
    'Authorization': "{staffAuthToken}",
	'SiteId': "{yourSiteId}",
    'Api-Key': "{yourApiKey}"
    }

conn.request("GET", "/public/v6/sale/services?classId=929", headers=headers)

res = conn.getresponse()
data = res.read()

print(data.decode("utf-8"))
```
:::

:::visible {language=ruby}
```
require 'uri'
require 'net/http'

url = URI("https://api.mindbodyonline.com/public/v6/sale/services?classId=929")

http = Net::HTTP.new(url.host, url.port)
http.use_ssl = true
http.verify_mode = OpenSSL::SSL::VERIFY_NONE

request = Net::HTTP::Get.new(url)
request["Authorization"] = '{staffAuthToken}'
request["SiteId"] = '{yourSiteId}'
request["Api-Key"] = '{yourApiKey}'

response = http.request(request)
puts response.read_body
```
:::

> Step 4: Purchase the service

:::visible {language=http}
```
curl -X POST \
  'https://api.mindbodyonline.com/public/v6/sale/checkoutshoppingcart' \
  -H 'Content-Type: application/json' \
  -H 'Api-Key: {yourApiKey}' \
  -H 'Authorization: {staffAuthToken}' \
  -H 'SiteId: {yourSiteId}' \
  -A '{yourAppName}' \
  -d '{
	"ClientId" : "100000556",
	"Test" : false,
	"LocationId" : 1,
	"Items" : 
	[
		{
			"Item":{
				"Type": "Service",
				"Metadata":{
					"Id": 10114
				}
			},
			"DiscountAmount" : 0,
			"Quantity" : 1
		}
	],
	"Payments" : 
	[
		{
			"Type": "Comp",
			"Metadata":{
				"Amount" : 75
			}
		}
	]
}'
```
:::

:::visible {language=csharp}
```
var client = new RestClient("https://api.mindbodyonline.com/public/v6/sale/checkoutshoppingcart");
var request = new RestRequest(Method.POST);
request.AddHeader("Authorization", "{staffAuthToken}");
request.AddHeader("SiteId", "{yourSiteId}");
request.AddHeader("Api-Key", "{yourApiKey}");
request.AddParameter("application/json", "{\r\n\t\"ClientId\" : \"100000556\",\r\n\t\"Test\" : false,\r\n\t\"LocationId\" : 1,\r\n\t\"Items\" : \r\n\t[\r\n\t\t{\r\n\t\t\t\"Item\":{\r\n\t\t\t\t\"Type\": \"Service\",\r\n\t\t\t\t\"Metadata\":{\r\n\t\t\t\t\t\"Id\": 10114\r\n\t\t\t\t}\r\n\t\t\t},\r\n\t\t\t\"DiscountAmount\" : 0,\r\n\t\t\t\"Quantity\" : 1\r\n\t\t}\r\n\t],\r\n\t\"Payments\" : \r\n\t[\r\n\t\t{\r\n\t\t\t\"Type\": \"Comp\",\r\n\t\t\t\"Metadata\":{\r\n\t\t\t\t\"Amount\" : 75\r\n\t\t\t}\r\n\t\t}\r\n\t]\r\n}", ParameterType.RequestBody);
IRestResponse response = client.Execute(request);
```
:::

:::visible {language=php}
```
<?php

$request = new HttpRequest();
$request->setUrl('https://api.mindbodyonline.com/public/v6/sale/checkoutshoppingcart');
$request->setMethod(HTTP_METH_POST);

$request->setHeaders(array(
  'Authorization' => '{staffAuthToken}',
  'Content-Type' => 'application/json',
  'SiteId' => '{yourSiteId}',
  'Api-Key' => '{yourApiKey}'
));

$request->setBody('{
	"ClientId" : "100000556",
	"Test" : false,
	"LocationId" : 1,
	"Items" : 
	[
		{
			"Item":{
				"Type": "Service",
				"Metadata":{
					"Id": 10114
				}
			},
			"DiscountAmount" : 0,
			"Quantity" : 1
		}
	],
	"Payments" : 
	[
		{
			"Type": "Comp",
			"Metadata":{
				"Amount" : 75
			}
		}
	]
}');

try {
  $response = $request->send();

  echo $response->getBody();
} catch (HttpException $ex) {
  echo $ex;
}
```
:::

:::visible {language=python}
```
import http.client

conn = http.client.HTTPSConnection("api.mindbodyonline.com")

payload = "{\r\n\t\"ClientId\" : \"100000556\",\r\n\t\"Test\" : false,\r\n\t\"LocationId\" : 1,\r\n\t\"Items\" : \r\n\t[\r\n\t\t{\r\n\t\t\t\"Item\":{\r\n\t\t\t\t\"Type\": \"Service\",\r\n\t\t\t\t\"Metadata\":{\r\n\t\t\t\t\t\"Id\": 10114\r\n\t\t\t\t}\r\n\t\t\t},\r\n\t\t\t\"DiscountAmount\" : 0,\r\n\t\t\t\"Quantity\" : 1\r\n\t\t}\r\n\t],\r\n\t\"Payments\" : \r\n\t[\r\n\t\t{\r\n\t\t\t\"Type\": \"Comp\",\r\n\t\t\t\"Metadata\":{\r\n\t\t\t\t\"Amount\" : 75\r\n\t\t\t}\r\n\t\t}\r\n\t]\r\n}"

headers = {
    'Content-Type': "application/json",
	'Api-Key': "{yourApiKey}",
    'SiteId': "{yourSiteId}",
    'Authorization': "{staffAuthToken}"
    }

conn.request("POST", "/public/v6/sale/checkoutshoppingcart", payload, headers)

res = conn.getresponse()
data = res.read()

print(data.decode("utf-8"))
```
:::

:::visible {language=ruby}
```
require 'uri'
require 'net/http'

url = URI("https://api.mindbodyonline.com/public/v6/sale/checkoutshoppingcart")

http = Net::HTTP.new(url.host, url.port)
http.use_ssl = true
http.verify_mode = OpenSSL::SSL::VERIFY_NONE

request = Net::HTTP::Post.new(url)
request["Content-Type"] = 'application/json'
request["Api-Key"] = '{yourApiKey}'
request["SiteId"] = '{yourSiteId}'
request["Authorization"] = '{staffAuthToken}'
request.body = "{\r\n\t\"ClientId\" : \"100000556\",\r\n\t\"Test\" : false,\r\n\t\"LocationId\" : 1,\r\n\t\"Items\" : \r\n\t[\r\n\t\t{\r\n\t\t\t\"Item\":{\r\n\t\t\t\t\"Type\": \"Service\",\r\n\t\t\t\t\"Metadata\":{\r\n\t\t\t\t\t\"Id\": 10114\r\n\t\t\t\t}\r\n\t\t\t},\r\n\t\t\t\"DiscountAmount\" : 0,\r\n\t\t\t\"Quantity\" : 1\r\n\t\t}\r\n\t],\r\n\t\"Payments\" : \r\n\t[\r\n\t\t{\r\n\t\t\t\"Type\": \"Comp\",\r\n\t\t\t\"Metadata\":{\r\n\t\t\t\t\"Amount\" : 75\r\n\t\t\t}\r\n\t\t}\r\n\t]\r\n}"

response = http.request(request)
puts response.read_body
```
:::

<h3 class="toc-ignore">Summary</h3>
This tutorial demonstrates how a staff member can purchase a class pass for a client. Note that the client must be able to pay with a stored credit card, account balance, or gift card.

<h3 class="toc-ignore">Workflow</h3>

Note that you need to determine the client ID from your own application, as the Mindbody Public API does not validate client logins.

<ol class="step-list">
<li><p>Get a user authentication token for the staff member by passing the staff member's login credentials to the authentication endpoint. For all following steps, put the token you receive into the <code>Authorization</code> header formatted as <code>Bearer {authToken}</code>.</p><p>For a description of the user authentication process, see <a href="#user-tokens">User Tokens</a>.</p></li>
<li><p>Use the <a href="#get-classes">GetClasses</a> endpoint to retrieve today's classes. Each class object that returns contains a class ID.</li>
<li><p>Pass the chosen class ID to the <a href="#get-services">GetServices</a> endpoint to retrieve all services that can pay for that class. Each service object that returns contains a service ID.</p></li>
<li><p>Pass the client ID and service ID to the <a href="#checkout-shopping-cart">CheckoutShoppingCart</a> endpoint to purchase the service. Use the client ID from your own application and the service ID from <strong>step 3</strong>. You can set <code>Test</code> to <code>true</code> to test the request without affecting the database.</p></li>
</ol>
<h4>Note</h4>
Protect yourself from processor fees and credit card fraud.  Remember to always protect your web forms that leverage <a href="#checkout-shopping-cart">POST CheckoutShoppingCart</a>, <a href="#purchase-contract">POST PurchaseContract</a> or <a href="#purchase-gift-card">POST PurchaseGiftCard</a> with a CAPTCHA!

