
# Mindbody Public Api Dto Models V6 Client Controller Get Cross Regional Client Associations Request

## Structure

`MindbodyPublicApiDtoModelsV6ClientControllerGetCrossRegionalClientAssociationsRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `client_id` | `string` | Optional | Looks up the cross regional associations by the client’s ID. Either `ClientId` or `Email` must be provided. If both are provided, the `ClientId` is used by default. |
| `email` | `string` | Optional | Looks up the cross regional associations by the client’s email address. Either `ClientId` or `Email` must be provided. If both are provided, the `ClientId` is used by default. |
| `limit` | `int` | Optional | Number of results to include, defaults to 100 |
| `offset` | `int` | Optional | Page offset, defaults to 0. |

## Example (as JSON)

```json
{
  "ClientId": null,
  "Email": null,
  "Limit": null,
  "Offset": null
}
```

