
# Mindbody Public Api Dto Models V6 Client Controller Get Client Schedule Request

## Structure

`MindbodyPublicApiDtoModelsV6ClientControllerGetClientScheduleRequest`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `clientId` | `string` | Required | The ID of the requested client. | getClientId(): string | setClientId(string clientId): void |
| `clientAssociatedSitesOffset` | `?int` | Optional | The number of sites to skip when returning the site associated with a client. | getClientAssociatedSitesOffset(): ?int | setClientAssociatedSitesOffset(?int clientAssociatedSitesOffset): void |
| `crossRegionalLookup` | `?bool` | Optional | When `true`, indicates that past and scheduled client visits across all sites in the region are returned.<br>When `false`, indicates that only visits at the current site are returned. | getCrossRegionalLookup(): ?bool | setCrossRegionalLookup(?bool crossRegionalLookup): void |
| `endDate` | `?\DateTime` | Optional | The date past which class visits are not returned.<br>Default is today’s date | getEndDate(): ?\DateTime | setEndDate(?\DateTime endDate): void |
| `startDate` | `?\DateTime` | Optional | The date before which class visits are not returned.<br>Default is the end date | getStartDate(): ?\DateTime | setStartDate(?\DateTime startDate): void |
| `limit` | `?int` | Optional | Number of results to include, defaults to 100 | getLimit(): ?int | setLimit(?int limit): void |
| `offset` | `?int` | Optional | Page offset, defaults to 0. | getOffset(): ?int | setOffset(?int offset): void |

## Example (as JSON)

```json
{
  "ClientId": "ClientId6",
  "ClientAssociatedSitesOffset": null,
  "CrossRegionalLookup": null,
  "EndDate": null,
  "StartDate": null,
  "Limit": null,
  "Offset": null
}
```

