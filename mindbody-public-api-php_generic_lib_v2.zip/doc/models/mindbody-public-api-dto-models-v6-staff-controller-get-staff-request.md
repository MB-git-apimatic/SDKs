
# Mindbody Public Api Dto Models V6 Staff Controller Get Staff Request

## Structure

`MindbodyPublicApiDtoModelsV6StaffControllerGetStaffRequest`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `staffIds` | `?(int[])` | Optional | A list of the requested staff IDs. | getStaffIds(): ?array | setStaffIds(?array staffIds): void |
| `filters` | `?(string[])` | Optional | Filters to apply to the search. Possible values are:<br><br>* StaffViewable<br>* AppointmentInstructor<br>* ClassInstructor<br>* Male<br>* Female | getFilters(): ?array | setFilters(?array filters): void |
| `sessionTypeId` | `?int` | Optional | Return only staff members that are available for the specified session type. You must supply a valid `StartDateTime` and `LocationID` to use this parameter. | getSessionTypeId(): ?int | setSessionTypeId(?int sessionTypeId): void |
| `startDateTime` | `?\DateTime` | Optional | Return only staff members that are available at the specified date and time. You must supply a valid `SessionTypeID` and `LocationID` to use this parameter. | getStartDateTime(): ?\DateTime | setStartDateTime(?\DateTime startDateTime): void |
| `locationId` | `?int` | Optional | Return only staff members that are available at the specified location. You must supply a valid `SessionTypeID` and `StartDateTime` to use this parameter. | getLocationId(): ?int | setLocationId(?int locationId): void |
| `limit` | `?int` | Optional | Number of results to include, defaults to 100 | getLimit(): ?int | setLimit(?int limit): void |
| `offset` | `?int` | Optional | Page offset, defaults to 0. | getOffset(): ?int | setOffset(?int offset): void |

## Example (as JSON)

```json
{
  "StaffIds": null,
  "Filters": null,
  "SessionTypeId": null,
  "StartDateTime": null,
  "LocationId": null,
  "Limit": null,
  "Offset": null
}
```

