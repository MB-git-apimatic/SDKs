# Site

```php
$siteController = $client->getSiteController();
```

## Class Name

`SiteController`

## Methods

* [Site Get Sites](../../doc/controllers/site.md#site-get-sites)
* [Site Get Session Types](../../doc/controllers/site.md#site-get-session-types)
* [Site Get Locations](../../doc/controllers/site.md#site-get-locations)
* [Site Get Programs](../../doc/controllers/site.md#site-get-programs)
* [Site Get Resources](../../doc/controllers/site.md#site-get-resources)
* [Site Get Activation Code](../../doc/controllers/site.md#site-get-activation-code)
* [Site Get Memberships](../../doc/controllers/site.md#site-get-memberships)
* [Site Get Genders](../../doc/controllers/site.md#site-get-genders)
* [Site Add Promo Code](../../doc/controllers/site.md#site-add-promo-code)
* [Site Get Promo Codes](../../doc/controllers/site.md#site-get-promo-codes)
* [Site Get Categories](../../doc/controllers/site.md#site-get-categories)
* [Site Get Payment Types](../../doc/controllers/site.md#site-get-payment-types)
* [Site Get Relationships](../../doc/controllers/site.md#site-get-relationships)
* [Site Get Mobile Providers](../../doc/controllers/site.md#site-get-mobile-providers)
* [Site Get Prospect Stages](../../doc/controllers/site.md#site-get-prospect-stages)


# Site Get Sites

Gets a list of sites that the developer has permission to view.

* Passing in no `SiteIds` returns all sites that the developer has access to.
* Passing in one `SiteIds` returns more detailed information about the specified site.

```php
function siteGetSites(
    string $version,
    ?string $authorization = null,
    ?int $requestLimit = null,
    ?int $requestOffset = null,
    ?array $requestSiteIds = null
): MindbodyPublicApiDtoModelsV6SiteControllerGetSitesResponse
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | - |
| `authorization` | `?string` | Header, Optional | A staff user authorization token. |
| `requestLimit` | `?int` | Query, Optional | Number of results to include, defaults to 100 |
| `requestOffset` | `?int` | Query, Optional | Page offset, defaults to 0. |
| `requestSiteIds` | `?(int[])` | Query, Optional | List of the requested site IDs. When omitted, returns all sites that the source has access to. |

## Response Type

[`MindbodyPublicApiDtoModelsV6SiteControllerGetSitesResponse`](../../doc/models/mindbody-public-api-dto-models-v6-site-controller-get-sites-response.md)

## Example Usage

```php
$version = 'version4';

$result = $siteController->siteGetSites($version);
```


# Site Get Session Types

Get the session types used at a site.

```php
function siteGetSessionTypes(
    string $siteId,
    string $version,
    ?string $authorization = null,
    ?int $requestLimit = null,
    ?int $requestOffset = null,
    ?bool $requestOnlineOnly = null,
    ?array $requestProgramIDs = null
): MindbodyPublicApiDtoModelsV6SiteControllerGetSessionTypesResponse
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `version` | `string` | Template, Required | - |
| `authorization` | `?string` | Header, Optional | A staff user authorization token. |
| `requestLimit` | `?int` | Query, Optional | Number of results to include, defaults to 100 |
| `requestOffset` | `?int` | Query, Optional | Page offset, defaults to 0. |
| `requestOnlineOnly` | `?bool` | Query, Optional | When `true`, indicates that only the session types that can be booked online should be returned.<br /><br>Default: **false** |
| `requestProgramIDs` | `?(int[])` | Query, Optional | Filters results to session types that belong to one of the given program IDs. If omitted, all program IDs return. |

## Response Type

[`MindbodyPublicApiDtoModelsV6SiteControllerGetSessionTypesResponse`](../../doc/models/mindbody-public-api-dto-models-v6-site-controller-get-session-types-response.md)

## Example Usage

```php
$siteId = '-99';
$version = 'version4';

$result = $siteController->siteGetSessionTypes($siteId, $version);
```


# Site Get Locations

Get locations for a site.

```php
function siteGetLocations(
    string $siteId,
    string $version,
    ?string $authorization = null,
    ?int $requestLimit = null,
    ?int $requestOffset = null
): MindbodyPublicApiDtoModelsV6SiteControllerGetLocationsResponse
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `version` | `string` | Template, Required | - |
| `authorization` | `?string` | Header, Optional | A staff user authorization token. |
| `requestLimit` | `?int` | Query, Optional | Number of results to include, defaults to 100 |
| `requestOffset` | `?int` | Query, Optional | Page offset, defaults to 0. |

## Response Type

[`MindbodyPublicApiDtoModelsV6SiteControllerGetLocationsResponse`](../../doc/models/mindbody-public-api-dto-models-v6-site-controller-get-locations-response.md)

## Example Usage

```php
$siteId = '-99';
$version = 'version4';

$result = $siteController->siteGetLocations($siteId, $version);
```


# Site Get Programs

Get service categories offered at a site.

```php
function siteGetPrograms(
    string $siteId,
    string $version,
    ?string $authorization = null,
    ?int $requestLimit = null,
    ?int $requestOffset = null,
    ?bool $requestOnlineOnly = null,
    ?string $requestScheduleType = null
): MindbodyPublicApiDtoModelsV6SiteControllerGetProgramsResponse
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `version` | `string` | Template, Required | - |
| `authorization` | `?string` | Header, Optional | A staff user authorization token. |
| `requestLimit` | `?int` | Query, Optional | Number of results to include, defaults to 100 |
| `requestOffset` | `?int` | Query, Optional | Page offset, defaults to 0. |
| `requestOnlineOnly` | `?bool` | Query, Optional | If `true`, filters results to show only those programs that are shown online.<br /><br>If `false`, all programs are returned.<br /><br>Default: **false** |
| `requestScheduleType` | [`?string (RequestScheduleTypeEnum)`](../../doc/models/request-schedule-type-enum.md) | Query, Optional | A schedule type used to filter the returned results. Possible values are:<br><br>* All<br>* Class<br>* Enrollment<br>* Appointment<br>* Resource<br>* Media<br>* Arrival |

## Response Type

[`MindbodyPublicApiDtoModelsV6SiteControllerGetProgramsResponse`](../../doc/models/mindbody-public-api-dto-models-v6-site-controller-get-programs-response.md)

## Example Usage

```php
$siteId = '-99';
$version = 'version4';

$result = $siteController->siteGetPrograms($siteId, $version);
```


# Site Get Resources

Get resources used at a site.

```php
function siteGetResources(
    string $siteId,
    string $version,
    ?string $authorization = null,
    ?\DateTime $requestEndDateTime = null,
    ?int $requestLimit = null,
    ?int $requestLocationId = null,
    ?int $requestOffset = null,
    ?array $requestSessionTypeIds = null,
    ?\DateTime $requestStartDateTime = null
): MindbodyPublicApiDtoModelsV6SiteControllerGetResourcesResponse
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `version` | `string` | Template, Required | - |
| `authorization` | `?string` | Header, Optional | A staff user authorization token. |
| `requestEndDateTime` | `?\DateTime` | Query, Optional | The time the resource ends. This parameter is ignored if `EndDateTime` or `LocationID` is not set. |
| `requestLimit` | `?int` | Query, Optional | Number of results to include, defaults to 100 |
| `requestLocationId` | `?int` | Query, Optional | The location of the resource. This parameter is ignored if `EndDateTime` or `LocationID` is not set.<br /><br>Default: **all** |
| `requestOffset` | `?int` | Query, Optional | Page offset, defaults to 0. |
| `requestSessionTypeIds` | `?(int[])` | Query, Optional | List of session type IDs.<br /><br>Default: **all** |
| `requestStartDateTime` | `?\DateTime` | Query, Optional | The time the resource starts. This parameter is ignored if `EndDateTime` or `LocationID` is not set. |

## Response Type

[`MindbodyPublicApiDtoModelsV6SiteControllerGetResourcesResponse`](../../doc/models/mindbody-public-api-dto-models-v6-site-controller-get-resources-response.md)

## Example Usage

```php
$siteId = '-99';
$version = 'version4';

$result = $siteController->siteGetResources($siteId, $version);
```


# Site Get Activation Code

Before you can use this endpoint, MINDBODY must approve your developer account for live access. If you have finished testing in the sandbox and are ready to begin working with MINDBODY customers, log into your account and request to go live.

See [Accessing Business Data From MINDBODY](https://developers.mindbodyonline.com/PublicDocumentation/V6#accessing-business-data) for more information about the activation code and how to use it.

Once you are approved, this endpoint returns an activation code.This endpoint supports only one site per call.

```php
function siteGetActivationCode(
    string $version,
    ?string $authorization = null
): MindbodyPublicApiDtoModelsV6SiteControllerGetActivationCodeResponse
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | - |
| `authorization` | `?string` | Header, Optional | A staff user authorization token. |

## Response Type

[`MindbodyPublicApiDtoModelsV6SiteControllerGetActivationCodeResponse`](../../doc/models/mindbody-public-api-dto-models-v6-site-controller-get-activation-code-response.md)

## Example Usage

```php
$version = 'version4';

$result = $siteController->siteGetActivationCode($version);
```


# Site Get Memberships

Get the memberships at a site.

```php
function siteGetMemberships(
    string $siteId,
    string $version,
    ?string $authorization = null,
    ?array $requestMembershipIds = null
): MindbodyPublicApiDtoModelsV6ClientControllerGetMembershipsResponse
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `version` | `string` | Template, Required | - |
| `authorization` | `?string` | Header, Optional | A staff user authorization token. |
| `requestMembershipIds` | `?(int[])` | Query, Optional | The requested membership IDs.<br /><br>Default: **all** IDs that the authenticated user’s access level allows. |

## Response Type

[`MindbodyPublicApiDtoModelsV6ClientControllerGetMembershipsResponse`](../../doc/models/mindbody-public-api-dto-models-v6-client-controller-get-memberships-response.md)

## Example Usage

```php
$siteId = '-99';
$version = 'version4';

$result = $siteController->siteGetMemberships($siteId, $version);
```


# Site Get Genders

The endpoint returns a list of configured client gender options for a site. Custom gender options are assignable to client genders only. Currently, custom values returned from this endpoint cannot be used as input for other endpoints to specify the genders of staff or client preferences.

```php
function siteGetGenders(
    string $siteId,
    string $version,
    ?string $authorization = null
): MindbodyPublicApiDtoModelsV6SiteControllerGetGendersResponse
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `version` | `string` | Template, Required | - |
| `authorization` | `?string` | Header, Optional | A staff user authorization token. |

## Response Type

[`MindbodyPublicApiDtoModelsV6SiteControllerGetGendersResponse`](../../doc/models/mindbody-public-api-dto-models-v6-site-controller-get-genders-response.md)

## Example Usage

```php
$siteId = '-99';
$version = 'version4';

$result = $siteController->siteGetGenders($siteId, $version);
```


# Site Add Promo Code

Creates a new promocode record at the specified business.
This endpoint requires staff user credentials. This staff memeber should have enabled the **Set up promotions / Semester discounts** staff permission.

```php
function siteAddPromoCode(
    MindbodyPublicApiDtoModelsV6SiteControllerAddPromoCodeRequest $request,
    string $siteId,
    string $version,
    ?string $authorization = null
): MindbodyPublicApiDtoModelsV6SiteControllerAddPromoCodeResponse
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `request` | [`MindbodyPublicApiDtoModelsV6SiteControllerAddPromoCodeRequest`](../../doc/models/mindbody-public-api-dto-models-v6-site-controller-add-promo-code-request.md) | Body, Required | - |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `version` | `string` | Template, Required | - |
| `authorization` | `?string` | Header, Optional | A staff user authorization token. |

## Response Type

[`MindbodyPublicApiDtoModelsV6SiteControllerAddPromoCodeResponse`](../../doc/models/mindbody-public-api-dto-models-v6-site-controller-add-promo-code-response.md)

## Example Usage

```php
$request_code = 'Code6';
$request_name = 'Name6';
$request = new Models\MindbodyPublicApiDtoModelsV6SiteControllerAddPromoCodeRequest(
    $request_code,
    $request_name
);
$siteId = '-99';
$version = 'version4';

$result = $siteController->siteAddPromoCode($request, $siteId, $version);
```


# Site Get Promo Codes

Gets a list of promocodes at the specified business. This endpoint requires staff user credentials.
This staff member should have enabled the Set up promotions / **Semester discounts** staff permission.

```php
function siteGetPromoCodes(
    string $siteId,
    string $version,
    ?string $authorization = null,
    ?bool $requestActiveOnly = null,
    ?\DateTime $requestEndDate = null,
    ?int $requestLimit = null,
    ?int $requestOffset = null,
    ?bool $requestOnlineOnly = null,
    ?\DateTime $requestStartDate = null
): MindbodyPublicApiDtoModelsV6SiteControllerGetPromoCodesResponse
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `version` | `string` | Template, Required | - |
| `authorization` | `?string` | Header, Optional | A staff user authorization token. |
| `requestActiveOnly` | `?bool` | Query, Optional | If true, filters results to show only promocodes that are active. If **false**, all promocodes are returned.<br>Default: **true** |
| `requestEndDate` | `?\DateTime` | Query, Optional | Filters results to promocodes that were activated before this date. |
| `requestLimit` | `?int` | Query, Optional | Number of results to include, defaults to 100 |
| `requestOffset` | `?int` | Query, Optional | Page offset, defaults to 0. |
| `requestOnlineOnly` | `?bool` | Query, Optional | If `true`, filters results to show only promocodes that can be used for online sale.<br>If `false`, all promocodes are returned.<br>Default: **false** |
| `requestStartDate` | `?\DateTime` | Query, Optional | Filters results to promocodes that were activated after this date. |

## Response Type

[`MindbodyPublicApiDtoModelsV6SiteControllerGetPromoCodesResponse`](../../doc/models/mindbody-public-api-dto-models-v6-site-controller-get-promo-codes-response.md)

## Example Usage

```php
$siteId = '-99';
$version = 'version4';

$result = $siteController->siteGetPromoCodes($siteId, $version);
```


# Site Get Categories

Get categories for site.

```php
function siteGetCategories(
    string $siteId,
    string $version,
    ?string $authorization = null,
    ?bool $requestActive = null,
    ?array $requestCategoryIds = null,
    ?int $requestLimit = null,
    ?int $requestOffset = null,
    ?bool $requestService = null,
    ?array $requestSubCategoryIds = null
): MindbodyPublicApiDtoModelsV6SiteControllerGetCategoriesResponse
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `version` | `string` | Template, Required | - |
| `authorization` | `?string` | Header, Optional | A staff user authorization token. |
| `requestActive` | `?bool` | Query, Optional | When `true`, the response only contains categories which are activated.<br>When `false`, only deactivated categories are returned.<br>Default: **All Categories** |
| `requestCategoryIds` | `?(int[])` | Query, Optional | When included, the response only contains details about the specified category Ids. |
| `requestLimit` | `?int` | Query, Optional | Number of results to include, defaults to 100 |
| `requestOffset` | `?int` | Query, Optional | Page offset, defaults to 0. |
| `requestService` | `?bool` | Query, Optional | When `true`, the response only contains details about Revenue Categories.<br>When `false`, only Product Revenue Categories are returned.<br>Default: **All Categories** |
| `requestSubCategoryIds` | `?(int[])` | Query, Optional | When included, the response only contains details about the specified subcategory Ids. |

## Response Type

[`MindbodyPublicApiDtoModelsV6SiteControllerGetCategoriesResponse`](../../doc/models/mindbody-public-api-dto-models-v6-site-controller-get-categories-response.md)

## Example Usage

```php
$siteId = '-99';
$version = 'version4';

$result = $siteController->siteGetCategories($siteId, $version);
```


# Site Get Payment Types

Get payment types for a site.

```php
function siteGetPaymentTypes(
    string $siteId,
    string $version,
    ?string $authorization = null,
    ?bool $requestActive = null
): MindbodyPublicApiDtoModelsV6SiteControllerGetPaymentTypesResponse
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `version` | `string` | Template, Required | - |
| `authorization` | `?string` | Header, Optional | A staff user authorization token. |
| `requestActive` | `?bool` | Query, Optional | When `true`, the response only contains payment types which are activated.<br>When `false`, only deactivated payment types are returned.<br>Default: **All Payment Types** |

## Response Type

[`MindbodyPublicApiDtoModelsV6SiteControllerGetPaymentTypesResponse`](../../doc/models/mindbody-public-api-dto-models-v6-site-controller-get-payment-types-response.md)

## Example Usage

```php
$siteId = '-99';
$version = 'version4';

$result = $siteController->siteGetPaymentTypes($siteId, $version);
```


# Site Get Relationships

This endpoint retrieves the business site relationships.

```php
function siteGetRelationships(
    string $siteId,
    string $version,
    ?string $authorization = null,
    ?bool $requestActive = null,
    ?int $requestLimit = null,
    ?int $requestOffset = null
): MindbodyPublicApiDtoModelsV6SiteControllerGetRelationshipsResponse
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `version` | `string` | Template, Required | - |
| `authorization` | `?string` | Header, Optional | A staff user authorization token. |
| `requestActive` | `?bool` | Query, Optional | When `true`, the response only contains relationships which are activated.<br>When `false`, only deactivated relationships are returned.<br>Default: **All Relationships** |
| `requestLimit` | `?int` | Query, Optional | Number of results to include, defaults to 100 |
| `requestOffset` | `?int` | Query, Optional | Page offset, defaults to 0. |

## Response Type

[`MindbodyPublicApiDtoModelsV6SiteControllerGetRelationshipsResponse`](../../doc/models/mindbody-public-api-dto-models-v6-site-controller-get-relationships-response.md)

## Example Usage

```php
$siteId = '-99';
$version = 'version4';

$result = $siteController->siteGetRelationships($siteId, $version);
```


# Site Get Mobile Providers

Get the list of mobile providers that are supported by the business.

```php
function siteGetMobileProviders(
    string $siteId,
    string $version,
    ?string $authorization = null,
    ?bool $requestActive = null
): MindbodyPublicApiDtoModelsV6SiteControllerGetMobileProvidersResponse
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `version` | `string` | Template, Required | - |
| `authorization` | `?string` | Header, Optional | A staff user authorization token. |
| `requestActive` | `?bool` | Query, Optional | When `true`, the response only contains mobile providers which are activated.<br>When `false`, only deactivated mobile providers are returned.<br>Default: **All Mobile Providers** |

## Response Type

[`MindbodyPublicApiDtoModelsV6SiteControllerGetMobileProvidersResponse`](../../doc/models/mindbody-public-api-dto-models-v6-site-controller-get-mobile-providers-response.md)

## Example Usage

```php
$siteId = '-99';
$version = 'version4';

$result = $siteController->siteGetMobileProviders($siteId, $version);
```


# Site Get Prospect Stages

Get the list of prospect stages that represent the prospect stage options for prospective clients.

```php
function siteGetProspectStages(
    string $siteId,
    string $version,
    ?string $authorization = null,
    ?bool $requestActive = null
): MindbodyPublicApiDtoModelsV6SiteControllerGetProspectStagesResponse
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `version` | `string` | Template, Required | - |
| `authorization` | `?string` | Header, Optional | A staff user authorization token. |
| `requestActive` | `?bool` | Query, Optional | When `true`, the response only contains prospect stages which are activated.<br>When `false`, only deactivated prospect stages are returned.<br>Default: **All Prospect Stages** |

## Response Type

[`MindbodyPublicApiDtoModelsV6SiteControllerGetProspectStagesResponse`](../../doc/models/mindbody-public-api-dto-models-v6-site-controller-get-prospect-stages-response.md)

## Example Usage

```php
$siteId = '-99';
$version = 'version4';

$result = $siteController->siteGetProspectStages($siteId, $version);
```

