
# Mindbody Public Api Dto Models V6 Client Controller Get Client Complete Info Request

request for GetClientCompleteInfoRequest

## Structure

`MindbodyPublicApiDtoModelsV6ClientControllerGetClientCompleteInfoRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `client_id` | `string` | Required | The ID of the client to query. |
| `start_date` | `datetime` | Optional | Filters results to pricing options that are valid on or after this date. |
| `end_date` | `datetime` | Optional | Filters results to pricing options that are valid on or before this date. |
| `cross_regional_lookup` | `bool` | Optional | Used to retrieve a client’s data from multiple sites within an organization.<br>Default: **false** |
| `client_associated_sites_offset` | `int` | Optional | Used to retrieve a client’s pricing options from multiple sites within an organization when the client is associated with more than ten sites. To change which ten sites are searched, change this offset value. A value of 0 means that no sites are skipped and the first ten sites are returned. You can use the `CrossRegionalClientAssociations` value from `GET CrossRegionalClientAssociations` to determine how many sites the client is associated with. Note that you must always have `CrossRegionalLookup` set to `true` to use this parameter.<br /><br>Default: **0**<br><br>For example, if a client is associated with 25 sites, you need to call `GetClientServices` three times, as follows:<br><br>* Use `GET CrossRegionalClientAssociations` to determine how many sites a client is associated with, which tells you how many additional calls you need to make.<br>* Either omit `ClientAssociatedSitesOffset` or set it to 0 to return the client’s services (pricing options) from sites 1-10.<br>* Set `ClientAssociatedSitesOffset` to 10 to return the client pricing options from sites 11-20<br>* Set `ClientAssociatedSitesOffset` to 20 to return the client pricing options from sites 21-25 |
| `required_client_data` | `List of string` | Optional | Used to store the required type of data for particular client |

## Example (as JSON)

```json
{
  "ClientId": "ClientId6",
  "StartDate": null,
  "EndDate": null,
  "CrossRegionalLookup": null,
  "ClientAssociatedSitesOffset": null,
  "RequiredClientData": null
}
```

