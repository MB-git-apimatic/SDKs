
# Mindbody Public Api Dto Models V6 Client Controller Terminate Contract Request

## Structure

`MindbodyPublicApiDtoModelsV6ClientControllerTerminateContractRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `client_id` | `string` | Required | The RSSID of the client for whom the contract is getting terminated. |
| `client_contract_id` | `int` | Required | The unique ID of the sale of the contract |
| `termination_date` | `datetime` | Required | The date to terminate contract |
| `termination_code` | `string` | Optional | The termination code |
| `termination_comments` | `string` | Optional | The termination comments |

## Example (as JSON)

```json
{
  "ClientId": "ClientId6",
  "ClientContractId": 86,
  "TerminationDate": "2016-03-13T12:52:32.123Z",
  "TerminationCode": null,
  "TerminationComments": null
}
```

