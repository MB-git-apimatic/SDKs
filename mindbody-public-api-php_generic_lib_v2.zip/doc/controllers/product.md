# Product

```php
$productController = $client->getProductController();
```

## Class Name

`ProductController`


# Product Update Products

Update retail products available for purchase at a site.

```php
function productUpdateProducts(
    string $siteId,
    array $updateProductsRequests,
    string $version,
    ?string $authorization = null
): MindbodyPublicApiDtoModelsV6SaleControllerGetProductsResponse
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `updateProductsRequests` | [`MindbodyPublicApiDtoModelsV6SaleControllerUpdateProductRequest[]`](../../doc/models/mindbody-public-api-dto-models-v6-sale-controller-update-product-request.md) | Body, Required | - |
| `version` | `string` | Template, Required | - |
| `authorization` | `?string` | Header, Optional | A staff user authorization token. |

## Response Type

[`MindbodyPublicApiDtoModelsV6SaleControllerGetProductsResponse`](../../doc/models/mindbody-public-api-dto-models-v6-sale-controller-get-products-response.md)

## Example Usage

```php
$siteId = '-99';
$updateProductsRequests = [];

$updateProductsRequests[0] = new Models\MindbodyPublicApiDtoModelsV6SaleControllerUpdateProductRequest();

$updateProductsRequests[1] = new Models\MindbodyPublicApiDtoModelsV6SaleControllerUpdateProductRequest();

$version = 'version4';

$result = $productController->productUpdateProducts($siteId, $updateProductsRequests, $version);
```

