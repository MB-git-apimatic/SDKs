
# Mindbody Public Api Dto Models V6 Appointment Controller Get Staff Appointments Request

## Structure

`MindbodyPublicApiDtoModelsV6AppointmentControllerGetStaffAppointmentsRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `appointment_ids` | `List of int` | Optional | A list of the requested appointment IDs. |
| `location_ids` | `List of int` | Optional | A list of the requested location IDs. |
| `start_date` | `datetime` | Optional | The start date of the requested date range. If omitted, the default is used.<br><br />Default: **today’s date** |
| `end_date` | `datetime` | Optional | The end date of the requested date range.<br><br />Default: **StartDate** |
| `staff_ids` | `List of long\|int` | Optional | List of staff IDs to be returned. Use a value of zero to return all staff appointments. |
| `client_id` | `string` | Optional | The client ID to be returned. |
| `limit` | `int` | Optional | Number of results to include, defaults to 100 |
| `offset` | `int` | Optional | Page offset, defaults to 0. |

## Example (as JSON)

```json
{
  "AppointmentIds": null,
  "LocationIds": null,
  "StartDate": null,
  "EndDate": null,
  "StaffIds": null,
  "ClientId": null,
  "Limit": null,
  "Offset": null
}
```

