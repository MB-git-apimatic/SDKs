
# Type Enum

Contains the class description session type.

## Enumeration

`TypeEnum`

## Fields

| Name |
|  --- |
| `ALL` |
| `CLASS_` |
| `ENROLLMENT` |
| `APPOINTMENT` |
| `RESOURCE` |
| `MEDIA` |
| `ARRIVAL` |

