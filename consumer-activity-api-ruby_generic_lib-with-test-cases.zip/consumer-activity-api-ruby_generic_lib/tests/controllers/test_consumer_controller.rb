require_relative 'controller_test_base'

class ConsumerControllerTests < ControllerTestBase
  # Called only once for the class before any test has executed
  def setup
    @response_catcher = HttpResponseCatcher.new
    @controller = ConsumerController.new CONFIG, http_call_back: @response_catcher
  end

  # Get visits
  def test_get_visits

    api_key = "5ca97a37c3c94ee1af093a22cf27fdaa"
    start_date = "2022-08-01"
    is_test_data = true
    end_date = "2022-08-31"

    # Perform the API call through the SDK function
    result = @controller.get_verified_visits(api_key, start_date:start_date, is_test_data:is_test_data, end_date:end_date )

    # Test response code
    assert_equal(200, @response_catcher.response.status_code)

    # Test whether the captured response is as we expected
    refute_nil(result)

  end

  # Get visits
  def test_get_purchases

    api_key = "5ca97a37c3c94ee1af093a22cf27fdaa"
    start_date = "2022-08-01"
    is_test_data = true
    end_date = "2022-08-31"

    # Perform the API call through the SDK function
    result = @controller.get_verified_purchases(api_key, start_date:start_date, is_test_data:is_test_data, end_date:end_date )

    # Test response code
    assert_equal(200, @response_catcher.response.status_code)

    # Test whether the captured response is as we expected
    refute_nil(result)

  end

end