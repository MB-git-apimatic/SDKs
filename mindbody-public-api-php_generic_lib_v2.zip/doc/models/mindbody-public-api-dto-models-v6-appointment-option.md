
# Mindbody Public Api Dto Models V6 Appointment Option

An appointment option name/value pair

## Structure

`MindbodyPublicApiDtoModelsV6AppointmentOption`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `displayName` | `?string` | Optional | The name displayed for this appointment option. | getDisplayName(): ?string | setDisplayName(?string displayName): void |
| `name` | `?string` | Optional | The name given to this option. | getName(): ?string | setName(?string name): void |
| `value` | `?string` | Optional | The value of the option. | getValue(): ?string | setValue(?string value): void |
| `type` | `?string` | Optional | The data type of the option value. | getType(): ?string | setType(?string type): void |

## Example (as JSON)

```json
{
  "DisplayName": null,
  "Name": null,
  "Value": null,
  "Type": null
}
```

