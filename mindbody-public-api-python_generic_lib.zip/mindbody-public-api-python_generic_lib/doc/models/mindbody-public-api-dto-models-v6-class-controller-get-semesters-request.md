
# Mindbody Public Api Dto Models V6 Class Controller Get Semesters Request

Get Semesters Request Model

## Structure

`MindbodyPublicApiDtoModelsV6ClassControllerGetSemestersRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `semester_i_ds` | `List of int` | Optional | Get with semester ids |
| `start_date` | `datetime` | Optional | Filter semesters with start date |
| `end_date` | `datetime` | Optional | Filter semesters with end date |
| `active` | `bool` | Optional | Get Active semesters |
| `limit` | `int` | Optional | Number of results to include, defaults to 100 |
| `offset` | `int` | Optional | Page offset, defaults to 0. |

## Example (as JSON)

```json
{
  "SemesterIDs": null,
  "StartDate": null,
  "EndDate": null,
  "Active": null,
  "Limit": null,
  "Offset": null
}
```

