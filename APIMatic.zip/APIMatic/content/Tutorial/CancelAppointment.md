﻿## Cancel an Appointment
<script type="text/javascript">
monitor('cancel-an-appointment');
</script>

> Step 2: Get a client's visits

:::visible {language=http}
```
curl -X GET \
  'https://api.mindbodyonline.com/public/v6/client/clientvisits?clientId=100000062&endDate=2018-10-17' \
  -H 'Api-Key: {yourApiKey}' \
  -H 'Authorization: {staffAuthToken}' \
  -H 'SiteId: {yourSiteId}' \
  -A '{yourAppName}'
```
:::

:::visible {language=csharp}
```
var client = new RestClient("https://api.mindbodyonline.com/public/v6/client/clientvisits?clientId=100000062&endDate=2018-10-17");
var request = new RestRequest(Method.GET);
request.AddHeader("Authorization", "{staffAuthToken}");
request.AddHeader("SiteId", "{yourSiteId}");
request.AddHeader("Api-Key", "{yourApiKey}");
IRestResponse response = client.Execute(request);
```
:::

:::visible {language=php}
```
<?php

$request = new HttpRequest();
$request->setUrl('https://api.mindbodyonline.com/public/v6/client/clientvisits');
$request->setMethod(HTTP_METH_GET);

$request->setQueryData(array(
  'clientId' => '100000062',
  'endDate' => '2018-10-17'
));

$request->setHeaders(array(
  'Authorization' => '{staffAuthToken}',
  'SiteId' => '{yourSiteId}',
  'Api-Key' => '{yourApiKey}'
));

try {
  $response = $request->send();

  echo $response->getBody();
} catch (HttpException $ex) {
  echo $ex;
}
```
:::

:::visible {language=python}
```
import http.client

conn = http.client.HTTPSConnection("api.mindbodyonline.com")

headers = {
	'Api-Key': "{yourApiKey}",
    'SiteId': "{yourSiteId}",
    'Authorization': "{staffAuthToken}"
    }

conn.request("GET", "/public/v6/client/clientvisits?clientId=100000062&endDate=2018-10-17", headers=headers)

res = conn.getresponse()
data = res.read()

print(data.decode("utf-8"))
```
:::

:::visible {language=ruby}
```
require 'uri'
require 'net/http'

url = URI("https://api.mindbodyonline.com/public/v6/client/clientvisits?clientId=100000062&endDate=2018-10-17")

http = Net::HTTP.new(url.host, url.port)
http.use_ssl = true
http.verify_mode = OpenSSL::SSL::VERIFY_NONE

request = Net::HTTP::Get.new(url)
request["Api-Key"] = '{yourApiKey}'
request["SiteId"] = '{yourSiteId}'
request["Authorization"] = '{staffAuthToken}'

response = http.request(request)
puts response.read_body
```
:::

> Step 3: Cancel a booked appointment

:::visible {language=http}
```
curl -X POST \
  https://api.mindbodyonline.com/public/v6/appointment/updateappointment \
  -H 'Content-Type: application/json' \
  -H 'Api-Key: {yourApiKey}' \
  -H 'Authorization: {staffAuthToken}' \
  -H 'SiteId: {yourSiteId}' \
  -A '{yourAppName}'
  -d '{
	"AppointmentId": 45587,
	"Execute": "cancel"
}'
```
:::

:::visible {language=csharp}
```
var client = new RestClient("https://api.mindbodyonline.com/public/v6/appointment/updateappointment");
var request = new RestRequest(Method.POST);
request.AddHeader("Authorization", "{staffAuthToken}");
request.AddHeader("SiteId", "{yourSiteId}");
request.AddHeader("Api-Key", "{yourApiKey}");
request.AddParameter("application/json", "{\n\t\"AppointmentId\": 45587,\n\t\"Execute\": \"cancel\"\n}", ParameterType.RequestBody);
IRestResponse response = client.Execute(request);
```
:::

:::visible {language=php}
```
<?php

$request = new HttpRequest();
$request->setUrl('https://api.mindbodyonline.com/public/v6/appointment/updateappointment');
$request->setMethod(HTTP_METH_POST);

$request->setHeaders(array(
  'Authorization' => '{staffAuthToken}',
  'Content-Type' => 'application/json',
  'SiteId' => '{yourSiteId}',
  'Api-Key' => '{yourApiKey}'
));

$request->setBody('{
	"AppointmentId": 45587,
	"Execute": "cancel"
}');

try {
  $response = $request->send();

  echo $response->getBody();
} catch (HttpException $ex) {
  echo $ex;
}
```
:::

:::visible {language=python}
```
import http.client

conn = http.client.HTTPSConnection("api.mindbodyonline.com")

payload = "{\n\t\"AppointmentId\": 45587,\n\t\"Execute\": \"cancel\"\n}"

headers = {
    'Content-Type': "application/json",
	'Api-Key': "{yourApiKey}",
    'SiteId': "{yourSiteId}",
    'Authorization': "{staffAuthToken}"
    }

conn.request("POST", "/public/v6/appointment/updateappointment", payload, headers)

res = conn.getresponse()
data = res.read()

print(data.decode("utf-8"))
```
:::

:::visible {language=ruby}
```
require 'uri'
require 'net/http'

url = URI("https://api.mindbodyonline.com/public/v6/appointment/updateappointment")

http = Net::HTTP.new(url.host, url.port)
http.use_ssl = true
http.verify_mode = OpenSSL::SSL::VERIFY_NONE

request = Net::HTTP::Post.new(url)
request["Content-Type"] = 'application/json'
request["Api-Key"] = '{yourApiKey}'
request["SiteId"] = '{yourSiteId}'
request["Authorization"] = '{staffAuthToken}'
request.body = "{\n\t\"AppointmentId\": 45587,\n\t\"Execute\": \"cancel\"\n}"

response = http.request(request)
puts response.read_body
```
:::

<h3 class="toc-ignore">Summary</h3>
This tutorial demonstrates how a staff member can cancel an appointment for a client.

<h3 class="toc-ignore">Workflow</h3>
Note that you need to determine the client ID from your own application, as the Mindbody Public API does not validate client logins.
<ol class="step-list">
<li id="fpb1">Get a user authentication token for the staff member by passing the staff member's login credentials to the authentication endpoint. For a description of the user authentication process, see <a href="#/http/mindbody-public-api-v6-0/authentication/user-tokens">User Tokens</a>. For all following steps, put the token you receive into the <code>Authorization</code> header formatted as <code>Bearer {authToken}</code>.</li>
<li id="fpb2">Use the <a href="#get-client-visits">GetClientVisits</a> endpoint to retrieve the client's schedule, including the appointments and classes in which the client is enrolled. In the request to this endpoint, pass the client ID from your application and an end date to filter the results. Note that the visit object in the response contains both a class ID and an appointment ID. The one that contains a non-zero number indicates which type of visit this is. That is, if the class ID is non-zero, then this is a class. If the appointment ID is non-zero, then this is a appointment. Make sure that the visit that is returned is an appointment.</li>
<li id="fpb3">Use the <a href="#update-appointment">UpdateAppointment</a> endpoint to cancel the appointment with the appointment ID from <strong>step 2</strong>. Set <code>Execute</code> to <code>cancel</code> in the request.
<br><br>Note that the cancellation may fail if the staff member tries to cancel the appointment outside the cancellation window. For example, a business may require appointments to be cancelled at least 24 hours before the scheduled time. If staff members try to cancel 12 hours in advance, they are not able to cancel. Instead, they have to use a late cancel. For a late cancel, set <code>Execute</code> to <code>latecancel</code> instead of <code>cancel</code> in the request.</li>
</ol>
