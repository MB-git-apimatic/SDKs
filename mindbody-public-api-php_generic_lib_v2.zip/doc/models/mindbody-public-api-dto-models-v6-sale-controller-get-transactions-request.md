
# Mindbody Public Api Dto Models V6 Sale Controller Get Transactions Request

Transactions Request

## Structure

`MindbodyPublicApiDtoModelsV6SaleControllerGetTransactionsRequest`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `saleId` | `?int` | Optional | Filters the transaction results with the ID number associated with the sale. | getSaleId(): ?int | setSaleId(?int saleId): void |
| `transactionId` | `?int` | Optional | Filters the transaction results with the ID number generated when the sale is processed. | getTransactionId(): ?int | setTransactionId(?int transactionId): void |
| `clientId` | `?int` | Optional | Filters results to the requested client ID. | getClientId(): ?int | setClientId(?int clientId): void |
| `locationId` | `?int` | Optional | Filters the transaction results with the ID number associated with the location of the sale. | getLocationId(): ?int | setLocationId(?int locationId): void |
| `status` | `?string` | Optional | Filters the transaction results by the estimated transaction status. | getStatus(): ?string | setStatus(?string status): void |
| `transactionStartDateTime` | `?\DateTime` | Optional | Filters the transaction results that happpened after this date and time.<br>Default: **today’s date** | getTransactionStartDateTime(): ?\DateTime | setTransactionStartDateTime(?\DateTime transactionStartDateTime): void |
| `transactionEndDateTime` | `?\DateTime` | Optional | Filters the transaction results that happpened before this date and time.<br>Default: **today’s date** | getTransactionEndDateTime(): ?\DateTime | setTransactionEndDateTime(?\DateTime transactionEndDateTime): void |
| `limit` | `?int` | Optional | Number of results to include, defaults to 100 | getLimit(): ?int | setLimit(?int limit): void |
| `offset` | `?int` | Optional | Page offset, defaults to 0. | getOffset(): ?int | setOffset(?int offset): void |

## Example (as JSON)

```json
{
  "SaleId": null,
  "TransactionId": null,
  "ClientId": null,
  "LocationId": null,
  "Status": null,
  "TransactionStartDateTime": null,
  "TransactionEndDateTime": null,
  "Limit": null,
  "Offset": null
}
```

