
# Mindbody Public Api Dto Models V6 Staff Controller Update Staff Permissions Request

## Structure

`MindbodyPublicApiDtoModelsV6StaffControllerUpdateStaffPermissionsRequest`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `staffId` | `int` | Required | The ID of the staff member whose permission you want to change. Staff member must have a login. | getStaffId(): int | setStaffId(int staffId): void |
| `permissionGroupName` | `string` | Required | The name of the permission group. | getPermissionGroupName(): string | setPermissionGroupName(string permissionGroupName): void |

## Example (as JSON)

```json
{
  "StaffId": 156,
  "PermissionGroupName": "PermissionGroupName2"
}
```

