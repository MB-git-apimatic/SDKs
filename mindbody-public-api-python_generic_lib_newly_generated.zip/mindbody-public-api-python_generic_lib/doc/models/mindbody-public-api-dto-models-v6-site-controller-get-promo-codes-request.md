
# Mindbody Public Api Dto Models V6 Site Controller Get Promo Codes Request

## Structure

`MindbodyPublicApiDtoModelsV6SiteControllerGetPromoCodesRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `active_only` | `bool` | Optional | If true, filters results to show only promocodes that are active. If **false**, all promocodes are returned.<br>Default: **true** |
| `online_only` | `bool` | Optional | If `true`, filters results to show only promocodes that can be used for online sale.<br>If `false`, all promocodes are returned.<br>Default: **false** |
| `start_date` | `datetime` | Optional | Filters results to promocodes that were activated after this date. |
| `end_date` | `datetime` | Optional | Filters results to promocodes that were activated before this date. |
| `limit` | `int` | Optional | Number of results to include, defaults to 100 |
| `offset` | `int` | Optional | Page offset, defaults to 0. |

## Example (as JSON)

```json
{
  "ActiveOnly": null,
  "OnlineOnly": null,
  "StartDate": null,
  "EndDate": null,
  "Limit": null,
  "Offset": null
}
```

