
# Gender Preference Enum

The preferred gender of the appointment provider.

## Enumeration

`GenderPreferenceEnum`

## Fields

| Name |
|  --- |
| `ENUM_NONE` |
| `FEMALE` |
| `MALE` |

