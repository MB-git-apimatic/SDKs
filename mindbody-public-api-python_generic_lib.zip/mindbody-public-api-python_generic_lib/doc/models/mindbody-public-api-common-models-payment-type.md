
# Mindbody Public Api Common Models Payment Type

## Structure

`MindbodyPublicApiCommonModelsPaymentType`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `int` | Optional | - |
| `payment_type_name` | `string` | Optional | - |
| `active` | `bool` | Optional | - |
| `fee` | `float` | Optional | - |

## Example (as JSON)

```json
{
  "Id": null,
  "PaymentTypeName": null,
  "Active": null,
  "Fee": null
}
```

