
# Schedule Type Enum

The service category’s schedule type.

## Enumeration

`ScheduleTypeEnum`

## Fields

| Name |
|  --- |
| `ALL` |
| `CLASS_` |
| `ENROLLMENT` |
| `APPOINTMENT` |
| `RESOURCE` |
| `MEDIA` |
| `ARRIVAL` |

