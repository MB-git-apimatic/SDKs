# Consumer

```ruby
consumer_controller = client.consumer
```

## Class Name

`ConsumerController`

## Methods

* [Get Verified Visits](../../doc/controllers/consumer.md#get-verified-visits)
* [Get Verified Purchases](../../doc/controllers/consumer.md#get-verified-purchases)
* [Disconnect Consumer From a Partner](../../doc/controllers/consumer.md#disconnect-consumer-from-a-partner)


# Get Verified Visits

Get verified visits of a consumer for a given duration.

```ruby
def get_verified_visits(api_key,
                        start_date: nil,
                        end_date: nil,
                        is_test_data: nil)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `api_key` | `String` | Header, Required | - |
| `start_date` | `DateTime` | Query, Optional | Start date of the visit activity. It should be in 'yyyy-mm-dd' format and it cannot be older than 3 months. |
| `end_date` | `DateTime` | Query, Optional | End date of the visit activity. It should be in 'yyyy-mm-dd' format and future date is not allowed. |
| `is_test_data` | `TrueClass\|FalseClass` | Query, Optional | Is Test Data of visit activity. If enable then return test data of consumer else provide actual data. |

## Response Type

[`VisitResponse`](../../doc/models/visit-response.md)

## Example Usage

```ruby
api_key = 'API-Key4'

result = consumer_controller.get_verified_visits(api_key, )
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | Bad Request | [`ErrorResponseException`](../../doc/models/error-response-exception.md) |
| 401 | Unauthorized | [`ProblemDetailsException`](../../doc/models/problem-details-exception.md) |
| 403 | Forbidden | [`ProblemDetailsException`](../../doc/models/problem-details-exception.md) |


# Get Verified Purchases

Get verified purchases of a consumer for a given duration.

```ruby
def get_verified_purchases(api_key,
                           start_date: nil,
                           end_date: nil,
                           product_type: nil,
                           is_test_data: nil)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `api_key` | `String` | Header, Required | - |
| `start_date` | `DateTime` | Query, Optional | Start date of the Purchase activity. It should be in 'yyyy-mm-dd' format and it cannot be older than 3 months. |
| `end_date` | `DateTime` | Query, Optional | End date of the Purchase activity. It should be in 'yyyy-mm-dd' format and future date is not allowed. |
| `product_type` | `String` | Query, Optional | Product Type of the Purchase activity. |
| `is_test_data` | `TrueClass\|FalseClass` | Query, Optional | Is test data of purchase activity. If enable then return test data of consumer else provide actual data. |

## Response Type

[`PurchaseResponse`](../../doc/models/purchase-response.md)

## Example Usage

```ruby
api_key = 'API-Key4'

result = consumer_controller.get_verified_purchases(api_key, )
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | Bad Request | [`ErrorResponseException`](../../doc/models/error-response-exception.md) |
| 401 | Unauthorized | [`ProblemDetailsException`](../../doc/models/problem-details-exception.md) |
| 403 | Forbidden | [`ProblemDetailsException`](../../doc/models/problem-details-exception.md) |


# Disconnect Consumer From a Partner

Partners can revoke the consent of a specific consumer using this endpoint.

```ruby
def disconnect_consumer_from_a_partner(api_key)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `api_key` | `String` | Header, Required | - |

## Response Type

`void`

## Example Usage

```ruby
api_key = 'API-Key4'

result = consumer_controller.disconnect_consumer_from_a_partner(api_key)
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | Bad Request | [`ErrorResponseException`](../../doc/models/error-response-exception.md) |

