
# Mindbody Public Api Dto Models V6 Payroll Controller Get Tips Request

## Structure

`MindbodyPublicApiDtoModelsV6PayrollControllerGetTipsRequest`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `staffId` | `?int` | Optional | A list of staff IDs that you want to retrieve payroll information for. If you do not supply a `StaffId`, all active staff members return, ordered by staff ID. | getStaffId(): ?int | setStaffId(?int staffId): void |
| `startDateTime` | `?\DateTime` | Optional | The beginning of the date range for the payroll information to be returned. The maximum allowed date range is 14 days.<br><br>* If you do not supply a `StartDateTime`, data returns for the seven days prior to the `EndDateTime` that you supply.<br>* If you do not supply either a `StartDateTime` or an `EndDateTime`, the data returns for seven days prior to today’s date. | getStartDateTime(): ?\DateTime | setStartDateTime(?\DateTime startDateTime): void |
| `endDateTime` | `?\DateTime` | Optional | The end of the date range for the payroll information to be returned. The maximum allowed date range is 14 days.<br /><br>Default: **Today’s date**<br><br>* If you do not supply an `EndDateTime`, the data returns for the period from the `StartDateTime` that you supply to today’s date.<br>* If you do not supply an `EndDateTime` or a `StartDateTime`, data returns for the seven days prior to today’s date. | getEndDateTime(): ?\DateTime | setEndDateTime(?\DateTime endDateTime): void |
| `locationId` | `?int` | Optional | A LocationId that you want to retrieve payroll information for. If you do not supply a `LocationId`, data from all locations is returned. | getLocationId(): ?int | setLocationId(?int locationId): void |
| `limit` | `?int` | Optional | Number of results to include, defaults to 100 | getLimit(): ?int | setLimit(?int limit): void |
| `offset` | `?int` | Optional | Page offset, defaults to 0. | getOffset(): ?int | setOffset(?int offset): void |

## Example (as JSON)

```json
{
  "StaffId": null,
  "StartDateTime": null,
  "EndDateTime": null,
  "LocationId": null,
  "Limit": null,
  "Offset": null
}
```

