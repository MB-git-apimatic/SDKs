﻿## How to Set Up Direct Debit and Check Out
<script type="text/javascript">
monitor('how-to-set-up-direct-debit-and-check-out');
</script>

> Step 5: Purchase contract using direct debit

:::visible {language=http}
```
curl -X POST \
  https://api.mindbodyonline.com/public/v6/sale/purchasecontract \
  -H 'Api-Key: {yourApiKey}' \
  -H 'Authorization: {staffAuthToken}' \
  -H 'Content-Type: application/json' \
  -H 'SiteId: {yourSiteId}' \
  -A '{yourAppName}' \
  -d '{
  "LocationId": 1,
  "ClientId": "100000025",
  "ContractId": 241,
  "FirstPaymentOccurs": "Instant",
  "UseDirectDebit": true
}'
```
:::

:::visible {language=csharp}
```
var client = new RestClient("https://api.mindbodyonline.com/public/v6/sale/purchasecontract");
var request = new RestRequest(Method.POST);
request.AddHeader("User-Agent", "{yourAppName}");
request.AddHeader("Authorization", "{staffAuthToken}");
request.AddHeader("SiteId", "{yourSiteId}");
request.AddHeader("Api-Key", "{yourApiKey}");
request.AddParameter("application/json", "{\r\n  \"LocationId\": 1,\r\n  \"ClientId\": \"100000025\",\r\n  \"ContractId\": 241,\r\n  \"FirstPaymentOccurs\": \"Instant\",\r\n  \"UseDirectDebit\": true\r\n}", ParameterType.RequestBody);
IRestResponse response = client.Execute(request);
```
:::

:::visible {language=php}
```
<?php

$request = new HttpRequest();
$request->setUrl('https://api.mindbodyonline.com/public/v6/sale/purchasecontract');
$request->setMethod(HTTP_METH_POST);

$request->setHeaders(array(
  'User-Agent' => '{yourAppName}',
  'Authorization' => '{staffAuthToken}',
  'SiteId' => '{yourSiteId}',
  'Api-Key' => '{yourApiKey}',
  'Content-Type' => 'application/json'
));

$request->setBody('{
  "LocationId": 1,
  "ClientId": "100000025",
  "ContractId": 241,
  "FirstPaymentOccurs": "Instant",
  "UseDirectDebit": true
}');

try {
  $response = $request->send();

  echo $response->getBody();
} catch (HttpException $ex) {
  echo $ex;
}
```
:::

:::visible {language=python}
```
import http.client

conn = http.client.HTTPSConnection("api.mindbodyonline.com")

payload = "{\r\n  \"LocationId\": 1,\r\n  \"ClientId\": \"100000025\",\r\n  \"ContractId\": 241,\r\n  \"FirstPaymentOccurs\": \"Instant\",\r\n  \"UseDirectDebit\": true\r\n}"

headers = {
    'Content-Type': "application/json",
    'Api-Key': "{yourApiKey}",
    'SiteId': "{yourSiteId}",
    'Authorization': "{staffAuthToken}",
    'User-Agent': "{yourAppName}"
    }

conn.request("POST", "public/v6/sale/purchasecontract", payload, headers)

res = conn.getresponse()
data = res.read()

print(data.decode("utf-8"))
```
:::

:::visible {language=ruby}
```
require 'uri'
require 'net/http'

url = URI("https://api.mindbodyonline.com/public/v6/sale/purchasecontract")

http = Net::HTTP.new(url.host, url.port)

request = Net::HTTP::Post.new(url)
request["Content-Type"] = 'application/json'
request["Api-Key"] = '{yourApiKey}'
request["SiteId"] = '{yourSiteId}'
request["Authorization"] = '{staffAuthToken}'
request["User-Agent"] = '{yourAppName'
request.body = "{\r\n  \"LocationId\": 1,\r\n  \"ClientId\": \"100000025\",\r\n  \"ContractId\": 241,\r\n  \"FirstPaymentOccurs\": \"Instant\",\r\n  \"UseDirectDebit\": true\r\n}"

response = http.request(request)
puts response.read_body
```
:::

> Step 5: Use direct debit in POST CheckoutShoppingCart


:::visible {language=http}
```
curl -X POST \
  https://api.mindbodyonline.com/public/v6/sale/checkoutshoppingcart \
  -H 'Api-Key: {yourApiKey}' \
  -H 'Authorization: {staffAuthToken}' \
  -H 'Content-Type: application/json' \
  -H 'SiteId: {yourSiteId}' \
  -A '{yourAppName}' \
  -d '{
    "ClientId" : "100000025",
    "LocationId" : 1,
    "Items" : 
    [
        {
            "Item":{
                "Type": "Service",
                "Metadata":{
                    "Id": 10114
                }
            },
            "DiscountAmount" : 0,
            "Quantity" : 1
        }
    ],
    "Payments" : 
    [
        {
            "Type": "DirectDebit",
            "Metadata":{
                "Amount" : 75
            }
        }
    ]
}'
```
:::

:::visible {language=csharp}
```
var client = new RestClient("https://api.mindbodyonline.com/public/v6/sale/checkoutshoppingcart");
var request = new RestRequest(Method.POST);
request.AddHeader("SiteId", "{yourSiteId}");
request.AddHeader("Authorization", "{staffAuthToken}");
request.AddHeader("Api-Key", "{yourApiKey}");
request.AddHeader("User-Agent", "{yourAppName}");
request.AddParameter("application/json", "{\n    \"ClientId\" : \"100000025\",\n    \"LocationId\" : 1,\n    \"Items\" : \n    [\n        {\n            \"Item\":{\n                \"Type\": \"Service\",\n                \"Metadata\":{\n                    \"Id\": 10114\n                }\n            },\n            \"DiscountAmount\" : 0,\n            \"Quantity\" : 1\n        }\n    ],\n    \"Payments\" : \n    [\n        {\n            \"Type\": \"DirectDebit\",\n            \"Metadata\":{\n                \"Amount\" : 75\n            }\n        }\n    ]\n}", ParameterType.RequestBody);
IRestResponse response = client.Execute(request);
```
:::

:::visible {language=php}
```
<?php

$request = new HttpRequest();
$request->setUrl('https://api.mindbodyonline.com/public/v6/sale/checkoutshoppingcart');
$request->setMethod(HTTP_METH_POST);

$request->setHeaders(array(
  'SiteId' => '{yourSiteId}',
  'Authorization' => '{staffAuthToken}',
  'Api-Key' => '{yourApiKey}',
  'Content-Type' => 'application/json',
  'User-Agent' => '{yourAppName}'
));

$request->setBody('{
    "ClientId" : "100000025",
    "LocationId" : 1,
    "Items" : 
    [
        {
            "Item":{
                "Type": "Service",
                "Metadata":{
                    "Id": 10114
                }
            },
            "DiscountAmount" : 0,
            "Quantity" : 1
        }
    ],
    "Payments" : 
    [
        {
            "Type": "DirectDebit",
            "Metadata":{
                "Amount" : 75
            }
        }
    ]
}');

try {
  $response = $request->send();

  echo $response->getBody();
} catch (HttpException $ex) {
  echo $ex;
}
```
:::

:::visible {language=python}
```
import http.client

conn = http.client.HTTPSConnection("api.mindbodyonline.com")

payload = "{\n    \"ClientId\" : \"100000025\",\n    \"LocationId\" : 1,\n    \"Items\" : \n    [\n        {\n            \"Item\":{\n                \"Type\": \"Service\",\n                \"Metadata\":{\n                    \"Id\": 10114\n                }\n            },\n            \"DiscountAmount\" : 0,\n            \"Quantity\" : 1\n        }\n    ],\n    \"Payments\" : \n    [\n        {\n            \"Type\": \"DirectDebit\",\n            \"Metadata\":{\n                \"Amount\" : 75\n            }\n        }\n    ]\n}"

headers = {
    'User-Agent': "{yourAppName}",
    'Content-Type': "application/json",
    'Api-Key': "{yourApiKey}",
    'Authorization': "{staffAuthToken}",
    'SiteId': "{yourSiteId}"
    }

conn.request("POST", "public/v6/sale/checkoutshoppingcart", payload, headers)

res = conn.getresponse()
data = res.read()

print(data.decode("utf-8"))
```
:::

:::visible {language=ruby}
```
require 'uri'
require 'net/http'

url = URI("https://api.mindbodyonline.com/public/v6/sale/checkoutshoppingcart")

http = Net::HTTP.new(url.host, url.port)

request = Net::HTTP::Post.new(url)
request["User-Agent"] = '{yourAppName}'
request["Content-Type"] = 'application/json'
request["Api-Key"] = '{yourApiKey}'
request["Authorization"] = '{staffAuthToken}'
request["SiteId"] = '{yourSiteId}'
request.body = "{\n    \"ClientId\" : \"100000025\",\n    \"LocationId\" : 1,\n    \"Items\" : \n    [\n        {\n            \"Item\":{\n                \"Type\": \"Service\",\n                \"Metadata\":{\n                    \"Id\": 10114\n                }\n            },\n            \"DiscountAmount\" : 0,\n            \"Quantity\" : 1\n        }\n    ],\n    \"Payments\" : \n    [\n        {\n            \"Type\": \"DirectDebit\",\n            \"Metadata\":{\n                \"Amount\" : 75\n            }\n        }\n    ]\n}"

response = http.request(request)
puts response.read_body
```
:::

<h3 class="toc-ignore">Summary</h3>
This tutorial demonstrates how to use direct debit information to make purchases for a client.

<h3 class="toc-ignore">Workflow</h3>
<ol class="step-list">
    <li>Get a user authentication token for the staff member by passing their login credentials to the authentication endpoint. For a description of the user authentication process, see <a href="#/http/mindbody-public-api-v6-0/authentication/user-tokens">User Tokens</a>. For all following steps, put the token you receive into the <code>Authorization</code> header formatted as <code>Bearer {authToken}</code>.</li>
    <li><p>If the client exists and you have their ID, continue to the next step.</p><p>If the client does not exist, <a href="#/http/tutorials/add-a-new-client">add the client</a>, then store and use the returned <code>Id</code> for the rest of these steps.</p></li>
    <li><a href="#get-client-ddinfo">Get the client's direct debit info</a> to ensure they have usable information. If they have direct debit info, skip the next step and proceed to <strong>Step 5</strong>.</li>
    <li><a href="#add-client-ddinfo">Add direct debit info for the client</a>, then continue to the next step.</li>
	<li>See the example requests on the right to see how to use direct debit info in both <a href="#checkout-shopping-cart">POST CheckoutShoppingCart</a> and <a href="#purchase-contract">POST PurchaseContract</a>.</li>
</ol>