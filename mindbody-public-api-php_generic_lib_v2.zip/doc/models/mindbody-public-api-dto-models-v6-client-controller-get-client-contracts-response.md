
# Mindbody Public Api Dto Models V6 Client Controller Get Client Contracts Response

## Structure

`MindbodyPublicApiDtoModelsV6ClientControllerGetClientContractsResponse`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `paginationResponse` | [`?MindbodyPublicApiDtoModelsV6PaginationResponse`](../../doc/models/mindbody-public-api-dto-models-v6-pagination-response.md) | Optional | - | getPaginationResponse(): ?MindbodyPublicApiDtoModelsV6PaginationResponse | setPaginationResponse(?MindbodyPublicApiDtoModelsV6PaginationResponse paginationResponse): void |
| `contracts` | [`?(MindbodyPublicApiDtoModelsV6ClientContract[])`](../../doc/models/mindbody-public-api-dto-models-v6-client-contract.md) | Optional | Contains the details of the client’s contract. | getContracts(): ?array | setContracts(?array contracts): void |

## Example (as JSON)

```json
{
  "PaginationResponse": null,
  "Contracts": null
}
```

