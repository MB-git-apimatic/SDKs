﻿## SCA Regulatory Support

Strong Customer Authentication (SCA) is a new European regulatory requirement to reduce fraud and make online payments more secure. To accept payments and meet SCA requirements,  CheckoutShoppingCart, PurchaseContract, and PurchaseGiftCard endpoints were updated to facilitate an SCA challenge. This only impacts EU customers who use the Public API to conduct consumer transactions using Stripe. 

[**CheckoutShoppingCart endpoint**](#checkout-shopping-cart)

New optional request fields had been added: <br>
	**ConsumerPresent**<br>
	**PaymentAuthenticationCallbackUrl**<br>
	**TransactionIDs**

If any of the credit card payments are indicating an SCA challenge, then a second call into CheckoutShoppingCart is required where these challenged or pre-authorized credit card transactions will be needed to complete the process and capture the funds. These will be provided in the response from the first call to CheckoutShoppingCart along with AuthenticationUrls for any card authorizations that have an SCA challenge indicated. Note that if no SCA challenge is required, these will not be provided in the response and no second call into CheckoutShoppingCart is needed. Also note that this list may only contain 1 integer depending on whether your integration allows for multiple payments which is supported by the CheckoutShoppingCart endpoint. 

New element Transactions has been added to the response object: <br>
	**TransactionID**<br>
	**AuthenticationUrl**

If no SCA challenge is indicated, none of this information is needed and it will not be returned, and no second call into CheckoutShoppingCart is needed. If provided at least one of the indicated transactions will have an AuthenticationUrl where the consumer will need to accept or decline the transaction, and upon doing so will be redirected to the PaymentAuthenticationCallbackUrl indicated in the request. 

If your integration supports multiple credit card payments, there is a chance that more than one of them will have an SCA challenge indicated. It is up to your application to maintain this awareness and only make the second call into CheckoutShoppingCart when all the challenges have been addressed. 
Your integration will need to provide all these TransactionIDs in the second call back into CheckoutShoppingCart. Any TransactionResponse indicating only a TransactionID with no AuthenticationUrl, simply means that transaction has been preauthorized and has no SCA challenge indicated. 

[**PurchaseContract**](#purchase-contract) / [**PurchaseGiftCard endpoints**](#purchase-gift-card) 

New optional request fields had been added:  <br>
	**ConsumerPresent**<br>
	**PaymentAuthenticationCallbackUrl**

New element PaymentProcessingFailures has been added to the response object: <br>
	**Type** <br>
	**Message**<br>
	**AuthenticationRedirectUrl**

Details below are for PurchaseContract endpoint, updates to the PurchaseGiftCard endpoint are similar. 

If no SCA challenge is indicated, PurchaseContract.Status = Success, none of this information is needed and it will not be returned, and no second call into PurchaseContract is needed. If provided at least one of the indicated PaymentProcessingFailures, will have an AuthenticationRedirectUrl where the consumer will need to accept or decline the transaction, and upon doing so will be redirected to the PaymentAuthenticationCallbackUrl indicated in the request. 

Because PurchaseContract leverages a shopping cart via the Mindbody Marketplace, no additional information needs to be passed back in the second call into PurchaseContract to finalize the order. Note: The cart will only remain valid for 15 minutes, after which time the cart is abandoned and any authorized credit card transactions will be voided. 