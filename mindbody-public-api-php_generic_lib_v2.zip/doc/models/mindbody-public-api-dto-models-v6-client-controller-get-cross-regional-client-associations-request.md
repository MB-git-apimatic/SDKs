
# Mindbody Public Api Dto Models V6 Client Controller Get Cross Regional Client Associations Request

## Structure

`MindbodyPublicApiDtoModelsV6ClientControllerGetCrossRegionalClientAssociationsRequest`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `clientId` | `?string` | Optional | Looks up the cross regional associations by the client’s ID. Either `ClientId` or `Email` must be provided. If both are provided, the `ClientId` is used by default. | getClientId(): ?string | setClientId(?string clientId): void |
| `email` | `?string` | Optional | Looks up the cross regional associations by the client’s email address. Either `ClientId` or `Email` must be provided. If both are provided, the `ClientId` is used by default. | getEmail(): ?string | setEmail(?string email): void |
| `limit` | `?int` | Optional | Number of results to include, defaults to 100 | getLimit(): ?int | setLimit(?int limit): void |
| `offset` | `?int` | Optional | Page offset, defaults to 0. | getOffset(): ?int | setOffset(?int offset): void |

## Example (as JSON)

```json
{
  "ClientId": null,
  "Email": null,
  "Limit": null,
  "Offset": null
}
```

