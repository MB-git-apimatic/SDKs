
# Mindbody Public Api Common Models Payment Type

## Structure

`MindbodyPublicApiCommonModelsPaymentType`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `id` | `?int` | Optional | - | getId(): ?int | setId(?int id): void |
| `paymentTypeName` | `?string` | Optional | - | getPaymentTypeName(): ?string | setPaymentTypeName(?string paymentTypeName): void |
| `active` | `?bool` | Optional | - | getActive(): ?bool | setActive(?bool active): void |
| `fee` | `?float` | Optional | - | getFee(): ?float | setFee(?float fee): void |

## Example (as JSON)

```json
{
  "Id": null,
  "PaymentTypeName": null,
  "Active": null,
  "Fee": null
}
```

