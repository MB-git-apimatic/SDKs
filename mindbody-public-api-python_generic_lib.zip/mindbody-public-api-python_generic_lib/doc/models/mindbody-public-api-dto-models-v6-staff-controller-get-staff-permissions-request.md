
# Mindbody Public Api Dto Models V6 Staff Controller Get Staff Permissions Request

## Structure

`MindbodyPublicApiDtoModelsV6StaffControllerGetStaffPermissionsRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `staff_id` | `long\|int` | Required | The ID of the staff member whose permissions you want to return. |

## Example (as JSON)

```json
{
  "StaffId": 156
}
```

