﻿
<script type="text/javascript">
monitor('oauth');
</script>

OAuth is another way to authorize endpoints by obtaining access token. The OAuth 2.0 authorization is a framework that allows user to grant a third party website or application access to the user's protected resources, without necessarily revealing their credentials or even identity.

In OAuth, the client request access to resources controlled by the resource owner and hosted by the resource server and is issued a different set of credentials than those of the resource owner. Instead of using the resource owner's credentials to access protected resources, the partner obtains an access token i.e. a string denoting a specific scope, lifetime and other attributes.

Access tokens are issued to the third party clients by an authorization server with the approval of the resource owner, then the client uses the access token to access the protected resources. Access tokens are in Json Web Token (JWT) format. The permissions represented by the access token in OAuth terms are known as scopes.

For OAuth client creation, please <a href='https://support.mindbodyonline.com/s/contactapisupport'>Contact API Support</a>. OAuth 2.0 uses below two endpoints to get bearer access token to call Public API.

### Authorize

:::visible {language=http}
```
curl -X GET \
  'https://signin.mindbodyonline.com/connect/authorize?response_mode=form_post&response_type=code%20id_token&client_id={yourClientId}&redirect_uri={yourRedirectUri}&scope=email profile openid offline_access Mindbody.Api.Public.v6&subscriberId={subscriberId}&nonce={nonce}'
```
:::

:::visible {language=csharp}
```
var client = new RestClient("https://signin.mindbodyonline.com/connect/authorize?response_mode=form_post&response_type=code%20id_token&client_id={yourClientId}&redirect_uri={yourRedirectUri}&scope=email profile openid offline_access Mindbody.Api.Public.v6&subscriberId={subscriberId}&nonce={nonce}");
var request = new RestRequest(Method.GET);
IRestResponse response = client.Execute(request);
```
:::

:::visible {language=php}
```
<?php

$request = new HttpRequest();
$request->setUrl('https://signin.mindbodyonline.com/connect/authorize?response_mode=form_post&response_type=code%20id_token&client_id={yourClientId}&redirect_uri={yourRedirectUri}&scope=email profile openid offline_access Mindbody.Api.Public.v6&subscriberId={subscriberId}&nonce={nonce}');
$request->setMethod(METHOD_GET);

try {
  $response = $request->send();

  echo $response->getBody();
} catch (HttpException $ex) {
  echo $ex;
}

```
:::

:::visible {language=python}
```
import http.client

conn = http.client.HTTPSConnection("signin.mindbodyonline.com")
payload = ''
headers = {}
conn.request("GET", "/connect/authorize?response_mode=form_post&response_type=code%20id_token&client_id={yourClientId}&redirect_uri={yourRedirectUri}&scope=email profile openid offline_access Mindbody.Api.Public.v6&subscriberId={subscriberId}&nonce={nonce}", payload, headers)
res = conn.getresponse()
data = res.read()
print(data.decode("utf-8"))
```
:::

:::visible {language=ruby}
```
require "uri"
require "net/http"

url = URI("https://signin.mindbodyonline.com/connect/authorize?response_mode=form_post&response_type=code%20id_token&client_id={yourClientId}&redirect_uri={yourRedirectUri}&scope=email profile openid offline_access Mindbody.Api.Public.v6&subscriberId={subscriberId}&nonce={nonce}")

https = Net::HTTP.new(url.host, url.port)
https.use_ssl = true

request = Net::HTTP::Get.new(url)

response = https.request(request)
puts response.read_body
```
:::

<a href="https://signin.mindbodyonline.com/connect/authorize">https://signin.mindbodyonline.com/connect/authorize</a>

This endpoint initiates a sign in workflow.  An OAuth Client will need to be provisioned for your account in order to use this endpoint.

<h4 id="get-authorize-query-params">Query Parameters</h4>

**Name** | **Type** | **Description**
--- | --- | ---
**response_mode** | string | Use the value `form_post`.
**response_type** | string | Determines the authorization processing flow to be used.  Clients created as type web will be assigned the OpenID Connect hybrid flow and should use `code id_token`.  Clients created as type native or SPA will use OpenID Connect code flow with PKCE and should use `code`.
**client_id** | string | Your OAuth Client ID.
**redirect_uri** | string | Redirection URI to which the response will be sent.
**scope** | string | Use the value `email profile openid offline_access Mindbody.Api.Public.v6`.  Your OAuth Client would need to have been provisioned with this scope. `offline_access` scope is mandatory to pass if you want refresh token back in response.
**nonce** | string | Value used to associate a Client session with an ID Token.
**subscriberId** | string | The Subscriber ID.

<h4 id="get-authorize-response">Response</h4>

After a consumer navigates to the authorize endpoint, they will be redirected to a sign in page to complete the workflow.  This is where they will enter their username and password.

**Status Code** | **Description**
--- | ---
**200** | Redirect to OAuth provider

### Token

:::visible {language=http}
```
curl -X POST \
  'https://signin.mindbodyonline.com/connect/token' \
  -H 'Content-Type: application/x-www-form-urlencoded' \
  -d 'grant_type=authorization_code&client_id={yourClientId}&client_secret={yourClientSecret}&code={authorizationCode}&redirect_uri={yourRedirectUri}&subscriberId={subscriberId}&scope=email profile openid offline_access Mindbody.Api.Public.v6'
```
:::

:::visible {language=csharp}
```
var client = new RestClient("https://signin.mindbodyonline.com/connect/token");
var request = new RestRequest(Method.POST);
request.AddHeader("Content-Type", "application/x-www-form-urlencoded");
request.AddParameter("application/x-www-form-urlencoded", "grant_type=authorization_code&client_id={yourClientId}&client_secret={yourClientSecret}&code={authorizationCode}&redirect_uri={yourRedirectUri}&subscriberId={subscriberId}&scope=email profile openid offline_access Mindbody.Api.Public.v6", ParameterType.RequestBody);
IRestResponse response = client.Execute(request);
```
:::

:::visible {language=php}
```
<?php

$request = new HttpRequest();
$request->setUrl('https://signin.mindbodyonline.com/connect/token');
$request->setMethod(HTTP_METH_POST);

$request->setHeaders(array(
  'Content-Type' => 'application/x-www-form-urlencoded'
));

$request->setBody('grant_type=authorization_code&client_id={yourClientId}&client_secret={yourClientSecret}&code={authorizationCode}&redirect_uri={yourRedirectUri}&subscriberId={subscriberId}&scope=email profile openid offline_access Mindbody.Api.Public.v6');

try {
  $response = $request->send();

  echo $response->getBody();
} catch (HttpException $ex) {
  echo $ex;
}
```
:::

:::visible {language=python}
```
import http.client

conn = http.client.HTTPSConnection("signin.mindbodyonline.com")

payload = "grant_type=authorization_code&client_id={yourClientId}&client_secret={yourClientSecret}&code={authorizationCode}&redirect_uri={yourRedirectUri}&subscriberId={subscriberId}&scope=email profile openid offline_access Mindbody.Api.Public.v6"

headers = {
    'Content-Type': "application/x-www-form-urlencoded"
    }

conn.request("POST", "/connect/token", payload, headers)

res = conn.getresponse()
data = res.read()

print(data.decode("utf-8"))
```
:::

:::visible {language=ruby}
```
require 'uri'
require 'net/http'

url = URI("https://signin.mindbodyonline.com/connect/token")

http = Net::HTTP.new(url.host, url.port)
http.use_ssl = true
http.verify_mode = OpenSSL::SSL::VERIFY_NONE

request = Net::HTTP::Post.new(url)
request["Content-Type"] = 'application/x-www-form-urlencoded'
request.body = "grant_type=authorization_code&client_id={yourClientId}&client_secret={yourClientSecret}&code={authorizationCode}&redirect_uri={yourRedirectUri}&subscriberId={subscriberId}&scope=email profile openid offline_access Mindbody.Api.Public.v6"

response = http.request(request)
puts response.read_body
```
:::

<a href="https://signin.mindbodyonline.com/connect/token">https://signin.mindbodyonline.com/connect/token</a>

This endpoint is used to request an access token in exchange for an authorization code or a refresh token.  An OAuth Client will need to be provisioned for your account in order to use this endpoint.

<h4 id="post-token-form-data">Form Data</h4>

**Name** | **Type** | **Description**
--- | --- | ---
**grant_type** | string | Specifies the workflow that the client application is using to authenticate and authorize a user against the token server.  Possible values are `authorization_code` and `refresh_token`.
**client_id** | string | Your OAuth Client ID.
**client_secret** | string | Your OAuth Client Secret.
**code** | string | Required when `grant_type` is `authorization_code`
**redirect_uri** | string | Required when `grant_type` is `authorization_code`
**refresh_token** | string | Required when `grant_type` is `refresh_token`
**scope** | string | Use the value `email profile openid offline_access Mindbody.Api.Public.v6`.  Your OAuth Client would need to have been provisioned with this scope. `offline_access` scope is mandatory to pass if you want refresh token back in response.
**nonce**<br><span class="optional">*Optional*</span> | string | Value used to associate a Client session with an ID Token.
**subscriberId** | string | The Subscriber ID.

<h4 id="post-token-response">Response</h4>

>Example Response

```
{
    "id_token": "id_token",
    "access_token": "access_token",
    "refresh_token": "refresh_token",
    "token_type": "Bearer",
    "expires_in": 3600,
}
```

**Name** | **Type** | **Description**
--- | --- | ---
**id_token** | string | The ID Token is a security token that contains Claims about the Authentication of an End-User by an authorization server.
**access_token** | string | A JSON Web Token, used for authorization, that contains information about the token provider, client application, target API resource, etc.
**refresh_token** | string | Present when the scope parameter includes `offline_access`. A token that can be used to obtain a new set of tokens from the token server.
**token_type** | string | Type of the token is set to "Bearer".
**expires_in** | number | The lifetime in seconds of the access token.
