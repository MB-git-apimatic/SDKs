
# Status 1 Enum

## Enumeration

`Status1Enum`

## Fields

| Name |
|  --- |
| `BOOKED` |
| `COMPLETED` |
| `CONFIRMED` |
| `ARRIVED` |
| `NOSHOW` |
| `CANCELLED` |
| `LATECANCELLED` |

