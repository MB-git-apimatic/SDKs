
# Mindbody Public Api Dto Models V6 Client Controller Get Client Purchases Request

## Structure

`MindbodyPublicApiDtoModelsV6ClientControllerGetClientPurchasesRequest`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `clientId` | `string` | Required | The ID of the client you are querying for purchases. | getClientId(): string | setClientId(string clientId): void |
| `startDate` | `?\DateTime` | Optional | Filters results to purchases made on or after this timestamp.<br /><br>Default: **now** | getStartDate(): ?\DateTime | setStartDate(?\DateTime startDate): void |
| `endDate` | `?\DateTime` | Optional | Filters results to purchases made before this timestamp.<br /><br>Default: **end of today** | getEndDate(): ?\DateTime | setEndDate(?\DateTime endDate): void |
| `saleId` | `?int` | Optional | Filters results to the single record associated with this ID. | getSaleId(): ?int | setSaleId(?int saleId): void |
| `limit` | `?int` | Optional | Number of results to include, defaults to 100 | getLimit(): ?int | setLimit(?int limit): void |
| `offset` | `?int` | Optional | Page offset, defaults to 0. | getOffset(): ?int | setOffset(?int offset): void |

## Example (as JSON)

```json
{
  "ClientId": "ClientId6",
  "StartDate": null,
  "EndDate": null,
  "SaleId": null,
  "Limit": null,
  "Offset": null
}
```

