
# Mindbody Public Api Common Models Add on Small

## Structure

`MindbodyPublicApiCommonModelsAddOnSmall`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `id` | `?int` | Optional | - | getId(): ?int | setId(?int id): void |
| `name` | `?string` | Optional | - | getName(): ?string | setName(?string name): void |
| `staffId` | `?int` | Optional | - | getStaffId(): ?int | setStaffId(?int staffId): void |

## Example (as JSON)

```json
{
  "Id": null,
  "Name": null,
  "StaffId": null
}
```

