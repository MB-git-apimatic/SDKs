
# Mindbody Public Api Dto Models V6 Purchased Item

## Structure

`MindbodyPublicApiDtoModelsV6PurchasedItem`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `sale_detail_id` | `int` | Optional | The ID of the sale detail |
| `id` | `long\|int` | Optional | The ProductID of the item. |
| `is_service` | `bool` | Optional | When `true`, indicates that the purchased item was a pricing option for a service. |
| `barcode_id` | `string` | Optional | The BarcodeId of the item.<br>For services, BarcodeId may be null<br>If no barcode id is explicitly set by the business it is the internal id in a string format. |
| `description` | `string` | Optional | Description of the sale transaction/pricing option description |
| `contract_id` | `int` | Optional | Contract ID purchased by the client |
| `category_id` | `int` | Optional | Revenue Category ID |
| `sub_category_id` | `int` | Optional | Revenue Subcategory ID |
| `unit_price` | `float` | Optional | Per unit price of the item sold |
| `quantity` | `int` | Optional | Quantity of the products |
| `discount_percent` | `float` | Optional | Discount % applied during sale |
| `discount_amount` | `float` | Optional | Discount Amount |
| `tax_1` | `float` | Optional | Tax1 applicable for the product |
| `tax_2` | `float` | Optional | Tax2 applicable for the product |
| `tax_3` | `float` | Optional | Tax3 applicable for the product |
| `tax_4` | `float` | Optional | Tax4 applicable for the product |
| `tax_5` | `float` | Optional | Tax5 applicable for the product |
| `tax_amount` | `float` | Optional | Tax rate applicable for the product |
| `total_amount` | `float` | Optional | Charged to the customer for paying |
| `notes` | `string` | Optional | Notes |
| `returned` | `bool` | Optional | Returned or not |
| `payment_ref_id` | `int` | Optional | Payment Reference ID |
| `exp_date` | `datetime` | Optional | Expiration date of the pricing option purchased |
| `active_date` | `datetime` | Optional | Activation date of pricing option purchased |

## Example (as JSON)

```json
{
  "SaleDetailId": null,
  "Id": null,
  "IsService": null,
  "BarcodeId": null,
  "Description": null,
  "ContractId": null,
  "CategoryId": null,
  "SubCategoryId": null,
  "UnitPrice": null,
  "Quantity": null,
  "DiscountPercent": null,
  "DiscountAmount": null,
  "Tax1": null,
  "Tax2": null,
  "Tax3": null,
  "Tax4": null,
  "Tax5": null,
  "TaxAmount": null,
  "TotalAmount": null,
  "Notes": null,
  "Returned": null,
  "PaymentRefId": null,
  "ExpDate": null,
  "ActiveDate": null
}
```

