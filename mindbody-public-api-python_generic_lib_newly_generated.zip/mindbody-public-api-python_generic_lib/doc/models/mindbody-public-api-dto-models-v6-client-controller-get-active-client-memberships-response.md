
# Mindbody Public Api Dto Models V6 Client Controller Get Active Client Memberships Response

## Structure

`MindbodyPublicApiDtoModelsV6ClientControllerGetActiveClientMembershipsResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `pagination_response` | [`MindbodyPublicApiDtoModelsV6PaginationResponse`](../../doc/models/mindbody-public-api-dto-models-v6-pagination-response.md) | Optional | - |
| `client_memberships` | [`List of MindbodyPublicApiDtoModelsV6ClientMembership`](../../doc/models/mindbody-public-api-dto-models-v6-client-membership.md) | Optional | Details about the requested memberships. |

## Example (as JSON)

```json
{
  "PaginationResponse": null,
  "ClientMemberships": null
}
```

