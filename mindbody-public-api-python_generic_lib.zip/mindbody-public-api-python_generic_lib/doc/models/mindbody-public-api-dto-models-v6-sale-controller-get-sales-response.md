
# Mindbody Public Api Dto Models V6 Sale Controller Get Sales Response

## Structure

`MindbodyPublicApiDtoModelsV6SaleControllerGetSalesResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `pagination_response` | [`MindbodyPublicApiDtoModelsV6PaginationResponse`](../../doc/models/mindbody-public-api-dto-models-v6-pagination-response.md) | Optional | - |
| `sales` | [`List of MindbodyPublicApiDtoModelsV6Sale`](../../doc/models/mindbody-public-api-dto-models-v6-sale.md) | Optional | Contains the Sale objects, each of which describes the sale and payment for a purchase event. |

## Example (as JSON)

```json
{
  "PaginationResponse": null,
  "Sales": null
}
```

