
# Mindbody Public Api Dto Models V6 Appointment Controller Get Staff Appointments Request

## Structure

`MindbodyPublicApiDtoModelsV6AppointmentControllerGetStaffAppointmentsRequest`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `appointmentIds` | `?(int[])` | Optional | A list of the requested appointment IDs. | getAppointmentIds(): ?array | setAppointmentIds(?array appointmentIds): void |
| `locationIds` | `?(int[])` | Optional | A list of the requested location IDs. | getLocationIds(): ?array | setLocationIds(?array locationIds): void |
| `startDate` | `?\DateTime` | Optional | The start date of the requested date range. If omitted, the default is used.<br><br />Default: **today’s date** | getStartDate(): ?\DateTime | setStartDate(?\DateTime startDate): void |
| `endDate` | `?\DateTime` | Optional | The end date of the requested date range.<br><br />Default: **StartDate** | getEndDate(): ?\DateTime | setEndDate(?\DateTime endDate): void |
| `staffIds` | `?(int[])` | Optional | List of staff IDs to be returned. Use a value of zero to return all staff appointments. | getStaffIds(): ?array | setStaffIds(?array staffIds): void |
| `clientId` | `?string` | Optional | The client ID to be returned. | getClientId(): ?string | setClientId(?string clientId): void |
| `limit` | `?int` | Optional | Number of results to include, defaults to 100 | getLimit(): ?int | setLimit(?int limit): void |
| `offset` | `?int` | Optional | Page offset, defaults to 0. | getOffset(): ?int | setOffset(?int offset): void |

## Example (as JSON)

```json
{
  "AppointmentIds": null,
  "LocationIds": null,
  "StartDate": null,
  "EndDate": null,
  "StaffIds": null,
  "ClientId": null,
  "Limit": null,
  "Offset": null
}
```

