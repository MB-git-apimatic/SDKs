
# Mindbody Public Api Dto Models V6 Client Controller Get Contact Log Types Response

## Structure

`MindbodyPublicApiDtoModelsV6ClientControllerGetContactLogTypesResponse`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `paginationResponse` | [`?MindbodyPublicApiDtoModelsV6PaginationResponse`](../../doc/models/mindbody-public-api-dto-models-v6-pagination-response.md) | Optional | - | getPaginationResponse(): ?MindbodyPublicApiDtoModelsV6PaginationResponse | setPaginationResponse(?MindbodyPublicApiDtoModelsV6PaginationResponse paginationResponse): void |
| `contactLogTypes` | [`?(MindbodyPublicApiDtoModelsV6ContactLogType[])`](../../doc/models/mindbody-public-api-dto-models-v6-contact-log-type.md) | Optional | Contains the information about the contact log types. | getContactLogTypes(): ?array | setContactLogTypes(?array contactLogTypes): void |

## Example (as JSON)

```json
{
  "PaginationResponse": null,
  "ContactLogTypes": null
}
```

