
# Mindbody Public Api Common Models Appointment

## Structure

`MindbodyPublicApiCommonModelsAppointment`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `gender_preference` | `string` | Optional | - |
| `duration` | `int` | Optional | - |
| `provider_id` | `string` | Optional | - |
| `id` | `long\|int` | Optional | - |
| `status` | [`Status1Enum`](../../doc/models/status-1-enum.md) | Optional | - |
| `start_date_time` | `datetime` | Optional | - |
| `end_date_time` | `datetime` | Optional | - |
| `notes` | `string` | Optional | - |
| `staff_requested` | `bool` | Optional | - |
| `program_id` | `int` | Optional | - |
| `waitlist_entry_id` | `long\|int` | Optional | - |
| `session_type_id` | `int` | Optional | - |
| `location_id` | `int` | Optional | - |
| `staff_id` | `long\|int` | Optional | - |
| `client_id` | `string` | Optional | - |
| `first_appointment` | `bool` | Optional | - |
| `client_service_id` | `long\|int` | Optional | - |
| `resources` | [`List of MindbodyPublicApiCommonModelsResource`](../../doc/models/mindbody-public-api-common-models-resource.md) | Optional | - |
| `add_ons` | [`List of MindbodyPublicApiCommonModelsAddOnSmall`](../../doc/models/mindbody-public-api-common-models-add-on-small.md) | Optional | - |
| `is_waitlist` | `bool` | Optional | - |
| `online_description` | `string` | Optional | - |

## Example (as JSON)

```json
{
  "GenderPreference": null,
  "Duration": null,
  "ProviderId": null,
  "Id": null,
  "Status": null,
  "StartDateTime": null,
  "EndDateTime": null,
  "Notes": null,
  "StaffRequested": null,
  "ProgramId": null,
  "WaitlistEntryId": null,
  "SessionTypeId": null,
  "LocationId": null,
  "StaffId": null,
  "ClientId": null,
  "FirstAppointment": null,
  "ClientServiceId": null,
  "Resources": null,
  "AddOns": null,
  "IsWaitlist": null,
  "OnlineDescription": null
}
```

