
# Mindbody Public Api Dto Models V6 Client Controller Get Client Purchases Response

## Structure

`MindbodyPublicApiDtoModelsV6ClientControllerGetClientPurchasesResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `pagination_response` | [`MindbodyPublicApiDtoModelsV6PaginationResponse`](../../doc/models/mindbody-public-api-dto-models-v6-pagination-response.md) | Optional | - |
| `purchases` | [`List of MindbodyPublicApiDtoModelsV6ClientPurchaseRecord`](../../doc/models/mindbody-public-api-dto-models-v6-client-purchase-record.md) | Optional | Contains information that describes the item sold and the payment. |

## Example (as JSON)

```json
{
  "PaginationResponse": null,
  "Purchases": null
}
```

