
# Mindbody Public Api Dto Models V6 Appointment Controller Get Unavailabilities Request

## Structure

`MindbodyPublicApiDtoModelsV6AppointmentControllerGetUnavailabilitiesRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `staff_ids` | `List of long\|int` | Optional | A list of requested staff IDs. |
| `start_date` | `datetime` | Optional | The start date of the requested date range.<br><br />Default: **today’s date** |
| `end_date` | `datetime` | Optional | The end date of the requested date range.<br><br />Default: **today’s date** |
| `limit` | `int` | Optional | Number of results to include, defaults to 100 |
| `offset` | `int` | Optional | Page offset, defaults to 0. |

## Example (as JSON)

```json
{
  "StaffIds": null,
  "StartDate": null,
  "EndDate": null,
  "Limit": null,
  "Offset": null
}
```

