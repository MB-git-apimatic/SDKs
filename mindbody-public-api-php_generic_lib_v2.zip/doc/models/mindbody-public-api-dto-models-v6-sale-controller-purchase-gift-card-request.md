
# Mindbody Public Api Dto Models V6 Sale Controller Purchase Gift Card Request

## Structure

`MindbodyPublicApiDtoModelsV6SaleControllerPurchaseGiftCardRequest`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `test` | `?bool` | Optional | When `true`, allows you to test the request without affecting the database.<br /><br>When `false`, the request is carried out and the database is affected. | getTest(): ?bool | setTest(?bool test): void |
| `locationId` | `int` | Required | The ID of the location where the gift card is being sold. | getLocationId(): int | setLocationId(int locationId): void |
| `layoutId` | `?int` | Optional | The ID of the layout used for the gift card’s image. | getLayoutId(): ?int | setLayoutId(?int layoutId): void |
| `purchaserClientId` | `string` | Required | The RSSID of the client who is purchasing the gift card. | getPurchaserClientId(): string | setPurchaserClientId(string purchaserClientId): void |
| `giftCardId` | `int` | Required | The product ID of the gift card being purchased. | getGiftCardId(): int | setGiftCardId(int giftCardId): void |
| `sendEmailReceipt` | `?bool` | Optional | When `true`, indicates that a purchase receipt email should be sent to the purchasing client, if all settings are correctly configured.<br /><br>When `false`, no email is sent to the purchaser. | getSendEmailReceipt(): ?bool | setSendEmailReceipt(?bool sendEmailReceipt): void |
| `recipientEmail` | `?string` | Optional | The email address to send the gift card image to. This parameter is required if the `LayoutId` is not 0.<br /><br>Maximum length: **100** | getRecipientEmail(): ?string | setRecipientEmail(?string recipientEmail): void |
| `recipientName` | `?string` | Optional | The name of the person who is to receive the gift card. This parameter is required if the `LayoutId` is not 0.<br /><br>Maximum length: **20** | getRecipientName(): ?string | setRecipientName(?string recipientName): void |
| `title` | `?string` | Optional | The text to use as the title of the gift card, for example: Happy Birthday, Maria! This parameter is required if the `LayoutId` is not 0.<br /><br>Maximum length: **20** | getTitle(): ?string | setTitle(?string title): void |
| `giftMessage` | `?string` | Optional | A personal message to include in the gift card.<br /><br>Maximum length: **300** | getGiftMessage(): ?string | setGiftMessage(?string giftMessage): void |
| `deliveryDate` | `?\DateTime` | Optional | The date that the gift card’s image is to be delivered to the recipient. This parameter cannot be set to a date in the past. This parameter is required if the `LayoutId` is not 0.<br>Default: **today**<br>Minimum: **today** | getDeliveryDate(): ?\DateTime | setDeliveryDate(?\DateTime deliveryDate): void |
| `paymentInfo` | [`?MindbodyPublicApiDtoModelsV6SaleControllerCheckoutRequestPaymentsCheckoutPaymentInfo`](../../doc/models/mindbody-public-api-dto-models-v6-sale-controller-checkout-request-payments-checkout-payment-info.md) | Optional | - | getPaymentInfo(): ?MindbodyPublicApiDtoModelsV6SaleControllerCheckoutRequestPaymentsCheckoutPaymentInfo | setPaymentInfo(?MindbodyPublicApiDtoModelsV6SaleControllerCheckoutRequestPaymentsCheckoutPaymentInfo paymentInfo): void |
| `salesRepId` | `?int` | Optional | The ID of the staff member who is to be marked as the sales rep for this gift card purchase. | getSalesRepId(): ?int | setSalesRepId(?int salesRepId): void |
| `consumerPresent` | `?bool` | Optional | When `true`, indicates that the consumer is available to address any SCA challenge issued by the bank.  EU Only.<br /><br>Default: **false** | getConsumerPresent(): ?bool | setConsumerPresent(?bool consumerPresent): void |
| `paymentAuthenticationCallbackUrl` | `?string` | Optional | This is the Url the consumer will be redirected back to after completion of the Banks SCA challenge. | getPaymentAuthenticationCallbackUrl(): ?string | setPaymentAuthenticationCallbackUrl(?string paymentAuthenticationCallbackUrl): void |
| `barcodeId` | `?string` | Optional | Sets the barcode ID of the giftcard. When not provided, a barcode ID is automatically generated.<br /><br>If a giftcard with the given barcode ID already exists and the site supports reloadable giftcards, the existing giftcard is reloaded<br /><br>Maximum length: **100**<br>**Constraints**: *Pattern*: `^[^<>'"]{1,100}$` | getBarcodeId(): ?string | setBarcodeId(?string barcodeId): void |
| `senderName` | `?string` | Optional | Overrides the name that would otherwise be populated by specifying PurchaserClientId.<br /><br>Maximum length: **20**<br>**Constraints**: *Pattern*: `^[^<>'"]{1,20}$` | getSenderName(): ?string | setSenderName(?string senderName): void |

## Example (as JSON)

```json
{
  "Test": null,
  "LocationId": 50,
  "LayoutId": null,
  "PurchaserClientId": "PurchaserClientId0",
  "GiftCardId": 254,
  "SendEmailReceipt": null,
  "RecipientEmail": null,
  "RecipientName": null,
  "Title": null,
  "GiftMessage": null,
  "DeliveryDate": null,
  "PaymentInfo": null,
  "SalesRepId": null,
  "ConsumerPresent": null,
  "PaymentAuthenticationCallbackUrl": null,
  "BarcodeId": null,
  "SenderName": null
}
```

