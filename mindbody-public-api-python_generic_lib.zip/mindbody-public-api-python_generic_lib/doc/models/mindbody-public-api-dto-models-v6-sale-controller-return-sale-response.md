
# Mindbody Public Api Dto Models V6 Sale Controller Return Sale Response

ReturnSaleResponse

## Structure

`MindbodyPublicApiDtoModelsV6SaleControllerReturnSaleResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `return_sale_id` | `long\|int` | Optional | The returned sale ID |
| `trainer_id` | `long\|int` | Optional | The trainer ID who returned the sale |
| `amount` | `float` | Optional | The returned amount |

## Example (as JSON)

```json
{
  "ReturnSaleID": null,
  "TrainerID": null,
  "Amount": null
}
```

