﻿
To access live data from the business with which you are integrating, you'll need to retrieve a site-specific activation code from Mindbody. You must then provide the code to the owner of the business for which you are developing your application. Once the owner activates the connection, you can access live data from the owner's business.

Note that you'll also need the Site ID of the business for this process.

**To get an owner's permission to access the owner's live Mindbody business data**

1. Go to [Mindbody developer's portal](https://developers.mindbodyonline.com).
2. On the upper right corner, click **Log In**.
3. Enter your username and password and click **Log in**.
4. On the top right, click **Account**.
5. On the left sidebar, click **Site activation**.
6. Enter the Site ID of the business with which you are integrating.
7. Mindbody then generates and returns a site-specific activation code and an activation link.<br>If you want to automate steps 5-7, you can generate the code and link within your application by calling the [GetActivationCode](#get-activation-code) endpoint.
8. There are two ways that the owner can activate your access to site data:<ul><li>You can email the activation link to the business owner. Ask the owner to click the link, then log in to his or her Mindbody site using the owner account. If successful, the owner sees a page titled Integrating with Mindbody's API that has a green checkmark on the right side.</li><li>Alternatively, you can email the activation code to the owner and ask them to enter the code on the API Integration page of his or her site. This page is located under Manager Tools > Mindbody Add Ons > API Integrations.</li><li>You can also refer the owner to the [Mindbody support article](https://support.mindbodyonline.com/s/article/Setting-up-an-API-integration?language=en_US) that covers the owner's part of this process.</li></ul>
