
# Error

Contains information about a problem encountered while performing an operation.

## Structure

`Error`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `code` | `String` | Optional | The application-specific error code. |
| `message` | `String` | Optional | Explanation concerning this occurence of this error. |

## Example (as JSON)

```json
{
  "code": null,
  "message": null
}
```

