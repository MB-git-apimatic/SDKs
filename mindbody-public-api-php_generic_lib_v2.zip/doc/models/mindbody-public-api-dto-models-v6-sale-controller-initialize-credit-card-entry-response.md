
# Mindbody Public Api Dto Models V6 Sale Controller Initialize Credit Card Entry Response

## Structure

`MindbodyPublicApiDtoModelsV6SaleControllerInitializeCreditCardEntryResponse`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `callbackUrl` | `?string` | Optional | - | getCallbackUrl(): ?string | setCallbackUrl(?string callbackUrl): void |

## Example (as JSON)

```json
{
  "CallbackUrl": null
}
```

