
# Mindbody Public Api Dto Models V6 Staff Controller Get Sales Reps Request

This is the request class for the get sales reps API

## Structure

`MindbodyPublicApiDtoModelsV6StaffControllerGetSalesRepsRequest`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `salesRepNumbers` | `?(int[])` | Optional | This is the list of the sales rep numbers for which the salesrep data will be fetched. | getSalesRepNumbers(): ?array | setSalesRepNumbers(?array salesRepNumbers): void |
| `activeOnly` | `?bool` | Optional | When `true`, will return only active reps data.<br>Default : **false** | getActiveOnly(): ?bool | setActiveOnly(?bool activeOnly): void |
| `limit` | `?int` | Optional | Number of results to include, defaults to 100 | getLimit(): ?int | setLimit(?int limit): void |
| `offset` | `?int` | Optional | Page offset, defaults to 0. | getOffset(): ?int | setOffset(?int offset): void |

## Example (as JSON)

```json
{
  "SalesRepNumbers": null,
  "ActiveOnly": null,
  "Limit": null,
  "Offset": null
}
```

