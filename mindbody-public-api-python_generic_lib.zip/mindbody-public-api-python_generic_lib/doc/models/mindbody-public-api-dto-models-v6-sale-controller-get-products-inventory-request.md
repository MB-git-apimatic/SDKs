
# Mindbody Public Api Dto Models V6 Sale Controller Get Products Inventory Request

## Structure

`MindbodyPublicApiDtoModelsV6SaleControllerGetProductsInventoryRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `product_ids` | `List of string` | Optional | An IDs filter for products inventory data. |
| `location_ids` | `List of int` | Optional | The location IDs to use to determine the inventory data of the product of specific location.<br /><br>Default: **online store** |
| `barcode_ids` | `List of string` | Optional | An IDs is barcodeId to filter for products inventory data. |
| `limit` | `int` | Optional | Number of results to include, defaults to 100 |
| `offset` | `int` | Optional | Page offset, defaults to 0. |

## Example (as JSON)

```json
{
  "ProductIds": null,
  "LocationIds": null,
  "BarcodeIds": null,
  "Limit": null,
  "Offset": null
}
```

