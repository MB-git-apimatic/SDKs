﻿<script type="text/javascript">
monitor('api-keys');
</script>

> Example request passing Api-Key, SiteId, and Authorization headers:

:::visible {language=http}
```
curl -X GET \
  'https://api.mindbodyonline.com/public/v6/class/classes' \
  -H 'Api-Key: {yourApiKey}' \
  -H 'authorization: {staffUserToken}' \
  -H 'SiteId: {yourSiteId}' \
  -A '{yourAppName}'
```
:::

:::visible {language=csharp}
```
var client = new RestClient("https://api.mindbodyonline.com/public/v6/class/classes");
var request = new RestRequest(Method.GET);
request.AddHeader("authorization", "{staffUserToken}");
request.AddHeader("SiteId", "{yourSiteId}");
request.AddHeader("Api-Key", "{yourApiKey}");
IRestResponse response = client.Execute(request);
```
:::

:::visible {language=php}
```
<?php

$request = new HttpRequest();
$request->setUrl('https://api.mindbodyonline.com/public/v6/class/classes');
$request->setMethod(HTTP_METH_GET);

$request->setHeaders(array(
  'authorization' => '{staffUserToken}',
  'SiteId' => '{yourSiteId}',
  'Api-Key' => '{yourApiKey}'
));

try {
  $response = $request->send();

  echo $response->getBody();
} catch (HttpException $ex) {
  echo $ex;
}
```
:::

:::visible {language=python}
```
import http.client

conn = http.client.HTTPSConnection("api.mindbodyonline.com")

headers = {
    'Api-Key': "{yourApiKey}",
    'SiteId': "{yourSiteId}",
    'authorization': "{staffUserToken}"
    }

conn.request("GET", "/public/v6/class/classes", headers=headers)

res = conn.getresponse()
data = res.read()

print(data.decode("utf-8"))
```
:::

:::visible {language=ruby}
```
require 'uri'
require 'net/http'

url = URI("https://api.mindbodyonline.com/public/v6/class/classes")

http = Net::HTTP.new(url.host, url.port)
http.use_ssl = true
http.verify_mode = OpenSSL::SSL::VERIFY_NONE

request = Net::HTTP::Get.new(url)
request["Api-Key"] = '{yourApiKey}'
request["SiteId"] = '{yourSiteId}'
request["authorization"] = '{staffUserToken}'

response = http.request(request)
puts response.read_body
```
:::

The Mindbody Public API and Webhooks API support self-service API key management. When using the Public API, you must pass a `SiteId` header and an `Api-Key` header in your request to authenticate your integration.  The Public API V6.0 does not support the use of `SourceCredentials` nodes. 

You can create up to ten unique API keys for use with the Public API and  Webhooks API. 

We strongly recommend that, for security and ease of management, you: <ul><li>use a different API key for each integration (application).</li><li> store and use API keys only in intermediary server-side applications, not in client-facing applications.</li></ul>

**To create an API key**

1. Log in to your [Mindbody developer account](https://developers.mindbodyonline.com).
2. On the upper right menu, click **Account**.
3. On the left sidebar, click **API credentials**.
4. On the Credentials page, at the bottom under API Keys, click **Create new API Key**.
5. In the App Name box that appears, change the default name to a name that describes this application. If you plan to use multiple API keys, we recommend that you use descriptive names so that you can easily distinguish between your API keys.<br><br>If you do not type in a name, the API uses the default name of SourceName-_Key-Number_, where _Key-Number_ is the current count of keys plus one.<br><br>Note that you can change the name of an API key after you create it by editing the name in the table and then clicking **Save**. If you want the key to be active immediately, leave the Active? checkbox checked and then click **Create**. If you want to create the API key now but activate it sometime in the future, uncheck the Active? check box and then click **Create**. The API key's status is Inactive until you activate it.

Once you create an API key, an entry appears in the table. For example:

**Issued** | **App Name (click to edit)** | **Key** | **Status** | **Actions**
--- | --- | --- | --- | --- 
July 8 2018 12:05 | My Test Key | <button name="button">Show</button> | Active | <button name="button">Deactivate</button>

**Using API keys**

When using an `Api-Key` header, you must also provide a `SiteId` header. Note that only one `SiteId` may be passed with the `Api-Key` header in each request.

Note the following when using API keys:

<ul><li>Clicking <strong>Activate</strong> immediately activates an API key.</li><li>Clicking <strong>Deactivate</strong> makes an API key immediately inactive; all requests using this API key fail while it is inactive.</li><li>Clicking <strong>Show</strong> displays the API key; clicking <strong>Hide</strong> hides the API key.</li><li>To create a new API key after you have already created ten API keys, you must deactivate and then delete at least one API key. Inactive API keys count toward your total number of API keys; deleted API keys do not.</li></ul>

<aside class="caution">Clicking <strong>Delete</strong> deletes an API key completely. If you accidentally delete an API key that you are using in production, you can <a href='https://support.mindbodyonline.com/s/contactapisupport'> email Mindbody API Support</a> for assistance.</aside>  

The example in the right pane shows how you would use an API key in your application. Note the `Api-Key` and `SiteId` headers.
