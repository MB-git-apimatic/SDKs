
# Mindbody Public Api Dto Models V6 Class Controller Get Class Visits Request

## Structure

`MindbodyPublicApiDtoModelsV6ClassControllerGetClassVisitsRequest`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `classID` | `?int` | Optional | The class ID. | getClassID(): ?int | setClassID(?int classID): void |
| `lastModifiedDate` | `?\DateTime` | Optional | When included in the request, only records modified on or after the `LastModifiedDate` specified are included in the response. | getLastModifiedDate(): ?\DateTime | setLastModifiedDate(?\DateTime lastModifiedDate): void |

## Example (as JSON)

```json
{
  "ClassID": null,
  "LastModifiedDate": null
}
```

