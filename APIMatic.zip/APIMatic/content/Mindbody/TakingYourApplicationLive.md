﻿
Note that when you request to go live, you'll need to have the Site ID of the business with which you are initially integrating.

**To request approval to make your application go live**

1. Log into your developer account.
2. On the upper right, click **Dashboard**.
3. On the bottom of the page, click **Request Live Access**.
4. Fill out the application with the required information and click **Continue**.
5. Mindbody reviews your application. Once the issues, if any, are resolved, we update your account status and email you to let you know that your application is ready to go live.
6. Then on **Activate and Launch** stage, select **Continue** to complete your account setup.

There is only one more step needed to complete the process.
