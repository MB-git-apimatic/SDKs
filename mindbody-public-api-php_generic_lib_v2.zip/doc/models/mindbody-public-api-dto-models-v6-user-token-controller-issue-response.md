
# Mindbody Public Api Dto Models V6 User Token Controller Issue Response

POST UserToken/Issue successful response

## Structure

`MindbodyPublicApiDtoModelsV6UserTokenControllerIssueResponse`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `tokenType` | `?string` | Optional | - | getTokenType(): ?string | setTokenType(?string tokenType): void |
| `accessToken` | `?string` | Optional | The authentication token value. | getAccessToken(): ?string | setAccessToken(?string accessToken): void |
| `user` | [`?MindbodyPublicApiDtoModelsV6User`](../../doc/models/mindbody-public-api-dto-models-v6-user.md) | Optional | - | getUser(): ?MindbodyPublicApiDtoModelsV6User | setUser(?MindbodyPublicApiDtoModelsV6User user): void |

## Example (as JSON)

```json
{
  "TokenType": null,
  "AccessToken": null,
  "User": null
}
```

