
# Mindbody Public Api Common Models Sub Category

## Structure

`MindbodyPublicApiCommonModelsSubCategory`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `int` | Optional | - |
| `sub_category_name` | `string` | Optional | - |
| `active` | `bool` | Optional | - |

## Example (as JSON)

```json
{
  "Id": null,
  "SubCategoryName": null,
  "Active": null
}
```

