
# Mindbody Public Api Common Models Staff

## Structure

`MindbodyPublicApiCommonModelsStaff`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `id` | `?int` | Optional | - | getId(): ?int | setId(?int id): void |
| `firstName` | `?string` | Optional | - | getFirstName(): ?string | setFirstName(?string firstName): void |
| `lastName` | `?string` | Optional | - | getLastName(): ?string | setLastName(?string lastName): void |
| `displayName` | `?string` | Optional | - | getDisplayName(): ?string | setDisplayName(?string displayName): void |
| `email` | `?string` | Optional | - | getEmail(): ?string | setEmail(?string email): void |
| `bio` | `?string` | Optional | - | getBio(): ?string | setBio(?string bio): void |
| `address` | `?string` | Optional | - | getAddress(): ?string | setAddress(?string address): void |
| `address2` | `?string` | Optional | - | getAddress2(): ?string | setAddress2(?string address2): void |
| `city` | `?string` | Optional | - | getCity(): ?string | setCity(?string city): void |
| `state` | `?string` | Optional | - | getState(): ?string | setState(?string state): void |
| `postalCode` | `?string` | Optional | - | getPostalCode(): ?string | setPostalCode(?string postalCode): void |
| `foreignZip` | `?string` | Optional | - | getForeignZip(): ?string | setForeignZip(?string foreignZip): void |
| `country` | `?string` | Optional | - | getCountry(): ?string | setCountry(?string country): void |
| `workPhone` | `?string` | Optional | - | getWorkPhone(): ?string | setWorkPhone(?string workPhone): void |
| `homePhone` | `?string` | Optional | - | getHomePhone(): ?string | setHomePhone(?string homePhone): void |
| `cellPhone` | `?string` | Optional | - | getCellPhone(): ?string | setCellPhone(?string cellPhone): void |
| `active` | `?bool` | Optional | - | getActive(): ?bool | setActive(?bool active): void |
| `isSystem` | `?bool` | Optional | - | getIsSystem(): ?bool | setIsSystem(?bool isSystem): void |
| `smodeId` | `?int` | Optional | - | getSmodeId(): ?int | setSmodeId(?int smodeId): void |
| `appointmentTrn` | `?bool` | Optional | - | getAppointmentTrn(): ?bool | setAppointmentTrn(?bool appointmentTrn): void |
| `alwaysAllowDoubleBooking` | `?bool` | Optional | - | getAlwaysAllowDoubleBooking(): ?bool | setAlwaysAllowDoubleBooking(?bool alwaysAllowDoubleBooking): void |
| `independentContractor` | `?bool` | Optional | - | getIndependentContractor(): ?bool | setIndependentContractor(?bool independentContractor): void |
| `imageUrl` | `?string` | Optional | - | getImageUrl(): ?string | setImageUrl(?string imageUrl): void |
| `isMale` | `?bool` | Optional | - | getIsMale(): ?bool | setIsMale(?bool isMale): void |
| `reservationTrn` | `?bool` | Optional | - | getReservationTrn(): ?bool | setReservationTrn(?bool reservationTrn): void |
| `sortOrder` | `?int` | Optional | - | getSortOrder(): ?int | setSortOrder(?int sortOrder): void |
| `multiLocationPermission` | `?bool` | Optional | - | getMultiLocationPermission(): ?bool | setMultiLocationPermission(?bool multiLocationPermission): void |
| `name` | `?string` | Optional | - | getName(): ?string | setName(?string name): void |
| `providerIDs` | `?(string[])` | Optional | - | getProviderIDs(): ?array | setProviderIDs(?array providerIDs): void |
| `staffSettings` | [`?MindbodyPublicApiCommonModelsStaffSetting`](../../doc/models/mindbody-public-api-common-models-staff-setting.md) | Optional | - | getStaffSettings(): ?MindbodyPublicApiCommonModelsStaffSetting | setStaffSettings(?MindbodyPublicApiCommonModelsStaffSetting staffSettings): void |
| `rep` | `?bool` | Optional | - | getRep(): ?bool | setRep(?bool rep): void |
| `rep2` | `?bool` | Optional | - | getRep2(): ?bool | setRep2(?bool rep2): void |
| `rep3` | `?bool` | Optional | - | getRep3(): ?bool | setRep3(?bool rep3): void |
| `rep4` | `?bool` | Optional | - | getRep4(): ?bool | setRep4(?bool rep4): void |
| `rep5` | `?bool` | Optional | - | getRep5(): ?bool | setRep5(?bool rep5): void |
| `rep6` | `?bool` | Optional | - | getRep6(): ?bool | setRep6(?bool rep6): void |
| `assistant` | `?bool` | Optional | - | getAssistant(): ?bool | setAssistant(?bool assistant): void |
| `assistant2` | `?bool` | Optional | - | getAssistant2(): ?bool | setAssistant2(?bool assistant2): void |
| `employmentStart` | `?\DateTime` | Optional | - | getEmploymentStart(): ?\DateTime | setEmploymentStart(?\DateTime employmentStart): void |
| `employmentEnd` | `?\DateTime` | Optional | - | getEmploymentEnd(): ?\DateTime | setEmploymentEnd(?\DateTime employmentEnd): void |
| `empID` | `?string` | Optional | - | getEmpID(): ?string | setEmpID(?string empID): void |
| `appointments` | [`?(MindbodyPublicApiCommonModelsAppointment[])`](../../doc/models/mindbody-public-api-common-models-appointment.md) | Optional | - | getAppointments(): ?array | setAppointments(?array appointments): void |
| `unavailabilities` | [`?(MindbodyPublicApiCommonModelsUnavailability[])`](../../doc/models/mindbody-public-api-common-models-unavailability.md) | Optional | - | getUnavailabilities(): ?array | setUnavailabilities(?array unavailabilities): void |
| `availabilities` | [`?(MindbodyPublicApiCommonModelsAvailability[])`](../../doc/models/mindbody-public-api-common-models-availability.md) | Optional | - | getAvailabilities(): ?array | setAvailabilities(?array availabilities): void |
| `loginLocations` | [`?(MindbodyPublicApiCommonModelsLocation[])`](../../doc/models/mindbody-public-api-common-models-location.md) | Optional | - | getLoginLocations(): ?array | setLoginLocations(?array loginLocations): void |

## Example (as JSON)

```json
{
  "Id": null,
  "FirstName": null,
  "LastName": null,
  "DisplayName": null,
  "Email": null,
  "Bio": null,
  "Address": null,
  "Address2": null,
  "City": null,
  "State": null,
  "PostalCode": null,
  "ForeignZip": null,
  "Country": null,
  "WorkPhone": null,
  "HomePhone": null,
  "CellPhone": null,
  "Active": null,
  "IsSystem": null,
  "SmodeId": null,
  "AppointmentTrn": null,
  "AlwaysAllowDoubleBooking": null,
  "IndependentContractor": null,
  "ImageUrl": null,
  "IsMale": null,
  "ReservationTrn": null,
  "SortOrder": null,
  "MultiLocationPermission": null,
  "Name": null,
  "ProviderIDs": null,
  "StaffSettings": null,
  "Rep": null,
  "Rep2": null,
  "Rep3": null,
  "Rep4": null,
  "Rep5": null,
  "Rep6": null,
  "Assistant": null,
  "Assistant2": null,
  "EmploymentStart": null,
  "EmploymentEnd": null,
  "EmpID": null,
  "Appointments": null,
  "Unavailabilities": null,
  "Availabilities": null,
  "LoginLocations": null
}
```

