
# Mindbody Public Api Common Models Add on Small

## Structure

`MindbodyPublicApiCommonModelsAddOnSmall`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `long\|int` | Optional | - |
| `name` | `string` | Optional | - |
| `staff_id` | `long\|int` | Optional | - |

## Example (as JSON)

```json
{
  "Id": null,
  "Name": null,
  "StaffId": null
}
```

