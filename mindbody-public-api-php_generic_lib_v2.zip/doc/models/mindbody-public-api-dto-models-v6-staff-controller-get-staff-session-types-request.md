
# Mindbody Public Api Dto Models V6 Staff Controller Get Staff Session Types Request

## Structure

`MindbodyPublicApiDtoModelsV6StaffControllerGetStaffSessionTypesRequest`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `staffId` | `int` | Required | The ID of the staff member whose session types you want to return. | getStaffId(): int | setStaffId(int staffId): void |
| `programIds` | `?(int[])` | Optional | Filters results to session types that belong to one of the given program IDs. If omitted, all program IDs return. | getProgramIds(): ?array | setProgramIds(?array programIds): void |
| `onlineOnly` | `?bool` | Optional | When `true`, indicates that only the session types that can be booked online should be returned.<br>Default: false | getOnlineOnly(): ?bool | setOnlineOnly(?bool onlineOnly): void |
| `limit` | `?int` | Optional | Number of results to include, defaults to 100 | getLimit(): ?int | setLimit(?int limit): void |
| `offset` | `?int` | Optional | Page offset, defaults to 0. | getOffset(): ?int | setOffset(?int offset): void |

## Example (as JSON)

```json
{
  "StaffId": 156,
  "ProgramIds": null,
  "OnlineOnly": null,
  "Limit": null,
  "Offset": null
}
```

