
# Mindbody Public Api Common Models Category

## Structure

`MindbodyPublicApiCommonModelsCategory`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `int` | Optional | - |
| `category_name` | `string` | Optional | - |
| `description` | `string` | Optional | - |
| `service` | `bool` | Optional | - |
| `active` | `bool` | Optional | - |
| `is_primary` | `bool` | Optional | - |
| `is_secondary` | `bool` | Optional | - |
| `created_date_time_utc` | `datetime` | Optional | - |
| `modified_date_time_utc` | `datetime` | Optional | - |
| `sub_categories` | [`List of MindbodyPublicApiCommonModelsSubCategory`](../../doc/models/mindbody-public-api-common-models-sub-category.md) | Optional | - |
| `total_count` | `int` | Optional | - |

## Example (as JSON)

```json
{
  "Id": null,
  "CategoryName": null,
  "Description": null,
  "Service": null,
  "Active": null,
  "IsPrimary": null,
  "IsSecondary": null,
  "CreatedDateTimeUTC": null,
  "ModifiedDateTimeUTC": null,
  "SubCategories": null,
  "TotalCount": null
}
```

