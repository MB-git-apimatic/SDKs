
# Mindbody Public Api Dto Models V6 Client Controller Get Clients Request

## Structure

`MindbodyPublicApiDtoModelsV6ClientControllerGetClientsRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `client_i_ds` | `List of string` | Optional | The requested client IDs.<br>Default: **all IDs** that the authenticated user’s access level allows. |
| `search_text` | `string` | Optional | Text to use in the search. Can include FirstName, LastName, and Email. Note that user credentials must be provided. |
| `is_prospect` | `bool` | Optional | When `true`, filters the results to include only those clients marked as prospects for the business.<br /><br>When `false`, indicates that only those clients who are not marked prospects should be returned. |
| `last_modified_date` | `datetime` | Optional | Filters the results to include only the clients that have been modified on or after this date. |
| `unique_ids` | `List of long\|int` | Optional | Filters results to clients with these `UniqueIDs`. This parameter cannot be used with `ClientIDs` or `SearchText`.<br>Default: **all UniqueIDs** that the authenticated user’s access level allows. |
| `include_inactive` | `bool` | Optional | When `true`, indicates the results to include active and inactive clients.<br /><br>When `false`, indicates that only those clients who are marked as active should be returned. |
| `limit` | `int` | Optional | Number of results to include, defaults to 100 |
| `offset` | `int` | Optional | Page offset, defaults to 0. |

## Example (as JSON)

```json
{
  "ClientIDs": null,
  "SearchText": null,
  "IsProspect": null,
  "LastModifiedDate": null,
  "UniqueIds": null,
  "IncludeInactive": null,
  "Limit": null,
  "Offset": null
}
```

