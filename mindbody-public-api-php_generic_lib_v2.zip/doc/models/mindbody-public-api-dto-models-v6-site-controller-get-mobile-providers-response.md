
# Mindbody Public Api Dto Models V6 Site Controller Get Mobile Providers Response

Get Mobile Providers Response Object

## Structure

`MindbodyPublicApiDtoModelsV6SiteControllerGetMobileProvidersResponse`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `mobileProviders` | [`?(MindbodyPublicApiCommonModelsMobileProvider[])`](../../doc/models/mindbody-public-api-common-models-mobile-provider.md) | Optional | A list of mobile providers. | getMobileProviders(): ?array | setMobileProviders(?array mobileProviders): void |

## Example (as JSON)

```json
{
  "MobileProviders": null
}
```

