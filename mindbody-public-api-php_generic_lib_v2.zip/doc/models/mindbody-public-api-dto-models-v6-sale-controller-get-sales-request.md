
# Mindbody Public Api Dto Models V6 Sale Controller Get Sales Request

## Structure

`MindbodyPublicApiDtoModelsV6SaleControllerGetSalesRequest`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `saleId` | `?int` | Optional | The sale ID associated with the particular item. It Filters results to the requested sale ID. | getSaleId(): ?int | setSaleId(?int saleId): void |
| `startSaleDateTime` | `?\DateTime` | Optional | Filters results to sales that happened after this date and time. | getStartSaleDateTime(): ?\DateTime | setStartSaleDateTime(?\DateTime startSaleDateTime): void |
| `endSaleDateTime` | `?\DateTime` | Optional | Filters results to sales that happened before this date and time. | getEndSaleDateTime(): ?\DateTime | setEndSaleDateTime(?\DateTime endSaleDateTime): void |
| `paymentMethodId` | `?int` | Optional | Filters results to sales paid for by the given payment method ID which indicates payment method(s) (i.e. cash, VISA, AMEX, Check, etc.). | getPaymentMethodId(): ?int | setPaymentMethodId(?int paymentMethodId): void |
| `limit` | `?int` | Optional | Number of results to include, defaults to 100 | getLimit(): ?int | setLimit(?int limit): void |
| `offset` | `?int` | Optional | Page offset, defaults to 0. | getOffset(): ?int | setOffset(?int offset): void |

## Example (as JSON)

```json
{
  "SaleId": null,
  "StartSaleDateTime": null,
  "EndSaleDateTime": null,
  "PaymentMethodId": null,
  "Limit": null,
  "Offset": null
}
```

