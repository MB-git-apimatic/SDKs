﻿<script type="text/javascript">
monitor('add-a-new-client');
</script>

> Step 2: Get required client fields request


:::visible {language=http}
```
 curl -X GET \
   https://api.mindbodyonline.com/public/v6/client/requiredclientfields \
   -H 'Api-Key: {yourApiKey}' \
   -H 'SiteId: {yourSiteId}' \
   -A '{yourAppName}'
 ```
:::
 
:::visible {language=csharp}
```
 var client = new RestClient("https://api.mindbodyonline.com/public/v6/client/requiredclientfields");
 var request = new RestRequest(Method.GET);
 request.AddHeader("SiteId", "{yourSiteId}");
 request.AddHeader("Api-Key", "{yourApiKey}");
 IRestResponse response = client.Execute(request);
 ```
:::

:::visible {language=php}
```
<?php

$request = new HttpRequest();
$request->setUrl('https://api.mindbodyonline.com/public/v6/client/requiredclientfields');
$request->setMethod(HTTP_METH_GET);

$request->setHeaders(array(
  'SiteId' => '{yourSiteId}',
  'Api-Key' => '{yourApiKey}'
));

try {
  $response = $request->send();

  echo $response->getBody();
} catch (HttpException $ex) {
  echo $ex;
}
```
:::

:::visible {language=python}
```
import http.client

conn = http.client.HTTPSConnection("api.mindbodyonline.com")

headers = {
	'Api-Key': "{yourApiKey}",
    'SiteId': "{SiteId}",
    }

conn.request("GET", "/public/v6/client/requiredclientfields", headers=headers)

res = conn.getresponse()
data = res.read()

print(data.decode("utf-8"))
```
:::

:::visible {language=ruby}
```
require 'uri'
require 'net/http'

url = URI("https://api.mindbodyonline.com/public/v6/client/requiredclientfields")

http = Net::HTTP.new(url.host, url.port)
http.use_ssl = true
http.verify_mode = OpenSSL::SSL::VERIFY_NONE

request = Net::HTTP::Get.new(url)
request["Api-Key"] = '{yourApiKey}'
request["SiteId"] = '{yourSiteId}'

response = http.request(request)
puts response.read_body
```
:::

> Get required client fields response

```
{
    "RequiredClientFields": [
        "AddressLine1",
        "City",
        "State",
        "PostalCode",
        "BirthDate"
    ]
}
```

> Step 3: Add client request:

:::visible {language=http}
```
curl -X POST \
  https://api.mindbodyonline.com/public/v6/client/addclient \
  -H 'Content-Type: application/json' \
  -H 'Api-Key: {yourApiKey}' \
  -H 'SiteId: {yourSiteId}' \
  -A '{yourAppName}' \
  -d '{
    "FirstName": "John",
    "LastName": "Smith",
    "AddressLine1": "123 ABC Ct",
    "City": "San Luis Obispo",
    "State": "CA",
    "PostalCode": "93401",
    "BirthDate": "1990-01-01"
}'
```
:::

:::visible {language=csharp}
```
var client = new RestClient("https://api.mindbodyonline.com/public/v6/client/addclient");
var request = new RestRequest(Method.POST);
request.AddHeader("SiteId", "{yourSiteId}");
request.AddHeader("Api-Key", "{yourApiKey}");
request.AddParameter("application/json", "{\n\t\"FirstName\": \"John\",\n\t\"LastName\": \"Smith\",\n    \"AddressLine1\": \"123 ABC Ct\",\n    \"City\": \"San Luis Obispo\",\n    \"State\": \"CA\",\n    \"PostalCode\": \"93401\",\n    \"BirthDate\": \"1990-01-01\"\n}", ParameterType.RequestBody);
IRestResponse response = client.Execute(request);
```
:::

:::visible {language=php}
```
<?php

$request = new HttpRequest();
$request->setUrl('https://api.mindbodyonline.com/public/v6/client/addclient');
$request->setMethod(HTTP_METH_POST);

$request->setHeaders(array(
  'Content-Type' => 'application/json',
  'SiteId' => '{yourSiteId}',
  'Api-Key' => '{yourApiKey}'
));

$request->setBody('{
    "FirstName": "John",
    "LastName": "Smith",
    "AddressLine1": "123 ABC Ct",
    "City": "San Luis Obispo",
    "State": "CA",
    "PostalCode": "93401",
    "BirthDate": "1990-01-01"
}');

try {
  $response = $request->send();

  echo $response->getBody();
} catch (HttpException $ex) {
  echo $ex;
}
```
:::

:::visible {language=python}
```
import http.client

conn = http.client.HTTPSConnection("api.mindbodyonline.com")

payload = "{\n\t\"FirstName\": \"John\",\n\t\"LastName\": \"Smith\",\n    \"AddressLine1\": \"123 ABC Ct\",\n    \"City\": \"San Luis Obispo\",\n    \"State\": \"CA\",\n    \"PostalCode\": \"93401\",\n    \"BirthDate\": \"1990-01-01\"\n}"

headers = {
    'Content-Type': "application/json",
	'Api-Key': "{yourApiKey}",
    'SiteId': "{yourSiteId}"
    }

conn.request("POST", "/public/v6/client/addclient", payload, headers)

res = conn.getresponse()
data = res.read()

print(data.decode("utf-8"))
```
:::

:::visible {language=ruby}
```
require 'uri'
require 'net/http'

url = URI("https://api.mindbodyonline.com/public/v6/client/addclient")

http = Net::HTTP.new(url.host, url.port)
http.use_ssl = true
http.verify_mode = OpenSSL::SSL::VERIFY_NONE

request = Net::HTTP::Post.new(url)
request["Content-Type"] = 'application/json'
request["Api-Key"] = '{yourApiKey}'
request["SiteId"] = '{yourSiteId}'
request.body = "{\n\t\"FirstName\": \"John\",\n\t\"LastName\": \"Smith\",\n    \"AddressLine1\": \"123 ABC Ct\",\n    \"City\": \"San Luis Obispo\",\n    \"State\": \"CA\",\n    \"PostalCode\": \"93401\",\n    \"BirthDate\": \"1990-01-01\"\n}"

response = http.request(request)
puts response.read_body
```
:::

> See the [AddClient](#add-client) endpoint documentation for an example response.

<h3 class="toc-ignore">Summary</h3>
Starting the week of May 11th, 2020 all versions of the Public API will no longer allow duplicate clients to be created. This applies to both adding a client and updating a client record. A duplicate client is created when two profiles have the same first name, last name and email.

If you have purchased an Ultimate tier then AddClient and UpdateClient endpoint will automatically start showing new opportunity on Sales Pipeline if lead criteria match.

This tutorial demonstrates how a staff member can add a new client to the business.

<h3 class="toc-ignore">Workflow</h3>
<ol class="step-list">
	<li id="fpb1">Get a user authentication token for the staff member by passing the login credentials to the authentication endpoint. For examples and a description of the user authentication process, see <a href="#/http/mindbody-public-api-v6-0/authentication/user-tokens">User Tokens</a>. For all following steps, put the token you receive into the <code>Authorization</code> header formatted as <code>Bearer {authToken}</code>.</li>
	<li id="fpb2">
		<p>Client required fields determine the information that new clients need to provide so that a staff member can create a  client account for a new client at a business. For example, the business owner may want to collect the client's first and last names, email address, and phone number. Call the <a href="#get-required-client-fields"> GetRequiredClientFields</a> endpoint to retrieve the required fields.</p>
		<p>If <code>GetRequiredClientFields</code> returns <code>EmergContact</code> in the list of required fields, then all emergency contact parameters are required, which includes: <code>EmergencyContactInfoEmail</code>, <code>EmergencyContactInfoName</code>, <code>EmergencyContactInfoPhone</code>, and <code>EmergencyContactInfoRelationship</code>. If <code>EmergContact</code> is not in the list of required fielids, then none of the emergency contact parameters are required in this request.</p>
	</li>
	<li id="fpb3"><p>Call the <a href="#add-client">AddClient</a> endpoint to add the client, using the required fields that you obtained in <strong>Step 1</strong>.</p>
		<p>Setting <code>Test</code> to <code>true</code> allows you to test the request without affecting the database.</p>
		<p>A staff member with the <em>Add client</em> staff permission can bypass the required fields and add a new client using only first and last names.</p>
	</li>
	<li id="fpb4">
		<p>After the client has been added, you can call the <a href="#send-password-reset-email">SendPasswordResetEmail</a> endpoint to set up a client's account by passing in their email, first name, and last name. An email is then sent to the client with a link to create a password.</p>
	</li>
</ol>
    