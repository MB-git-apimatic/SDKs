
# Mindbody Public Api Dto Models V6 Client Controller Upload Client Photo Response

## Structure

`MindbodyPublicApiDtoModelsV6ClientControllerUploadClientPhotoResponse`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `clientId` | `?string` | Optional | The RSSID of the client for whom the photo was uploaded. | getClientId(): ?string | setClientId(?string clientId): void |
| `photoUrl` | `?string` | Optional | The URL of the uploaded photo. | getPhotoUrl(): ?string | setPhotoUrl(?string photoUrl): void |

## Example (as JSON)

```json
{
  "ClientId": null,
  "PhotoUrl": null
}
```

