
# Mindbody Public Api Dto Models V6 Appointment Controller Get Active Session Times Request

## Structure

`MindbodyPublicApiDtoModelsV6AppointmentControllerGetActiveSessionTimesRequest`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `scheduleType` | [`?string (ScheduleType1Enum)`](../../doc/models/schedule-type-1-enum.md) | Optional | Filters on the provided the schedule type. Either `SessionTypeIds` or `ScheduleType` must be provided. | getScheduleType(): ?string | setScheduleType(?string scheduleType): void |
| `sessionTypeIds` | `?(int[])` | Optional | Filters on the provided session type IDs. Either `SessionTypeIds` or `ScheduleType` must be provided. | getSessionTypeIds(): ?array | setSessionTypeIds(?array sessionTypeIds): void |
| `startTime` | `?\DateTime` | Optional | Filters results to times that start on or after this time on the current date. Any date provided is ignored.<br><br />Default: **00:00:00** | getStartTime(): ?\DateTime | setStartTime(?\DateTime startTime): void |
| `endTime` | `?\DateTime` | Optional | Filters results to times that end on or before this time on the current date. Any date provided is ignored..<br><br />Default: **23:59:59** | getEndTime(): ?\DateTime | setEndTime(?\DateTime endTime): void |
| `limit` | `?int` | Optional | Number of results to include, defaults to 100 | getLimit(): ?int | setLimit(?int limit): void |
| `offset` | `?int` | Optional | Page offset, defaults to 0. | getOffset(): ?int | setOffset(?int offset): void |

## Example (as JSON)

```json
{
  "ScheduleType": null,
  "SessionTypeIds": null,
  "StartTime": null,
  "EndTime": null,
  "Limit": null,
  "Offset": null
}
```

