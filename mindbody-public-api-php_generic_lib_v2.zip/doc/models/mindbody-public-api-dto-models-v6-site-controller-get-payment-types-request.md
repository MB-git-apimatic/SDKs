
# Mindbody Public Api Dto Models V6 Site Controller Get Payment Types Request

Get Payment Types Request Model

## Structure

`MindbodyPublicApiDtoModelsV6SiteControllerGetPaymentTypesRequest`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `active` | `?bool` | Optional | When `true`, the response only contains payment types which are activated.<br>When `false`, only deactivated payment types are returned.<br>Default: **All Payment Types** | getActive(): ?bool | setActive(?bool active): void |

## Example (as JSON)

```json
{
  "Active": null
}
```

