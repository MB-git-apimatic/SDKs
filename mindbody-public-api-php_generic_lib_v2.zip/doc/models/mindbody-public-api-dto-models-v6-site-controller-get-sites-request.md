
# Mindbody Public Api Dto Models V6 Site Controller Get Sites Request

## Structure

`MindbodyPublicApiDtoModelsV6SiteControllerGetSitesRequest`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `siteIds` | `?(int[])` | Optional | List of the requested site IDs. When omitted, returns all sites that the source has access to. | getSiteIds(): ?array | setSiteIds(?array siteIds): void |
| `limit` | `?int` | Optional | Number of results to include, defaults to 100 | getLimit(): ?int | setLimit(?int limit): void |
| `offset` | `?int` | Optional | Page offset, defaults to 0. | getOffset(): ?int | setOffset(?int offset): void |

## Example (as JSON)

```json
{
  "SiteIds": null,
  "Limit": null,
  "Offset": null
}
```

