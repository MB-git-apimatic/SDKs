
# Mindbody Public Api Dto Models V6 Site Controller Get Prospect Stages Request

Get Prospect Stages Request Model

## Structure

`MindbodyPublicApiDtoModelsV6SiteControllerGetProspectStagesRequest`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `active` | `?bool` | Optional | When `true`, the response only contains prospect stages which are activated.<br>When `false`, only deactivated prospect stages are returned.<br>Default: **All Prospect Stages** | getActive(): ?bool | setActive(?bool active): void |

## Example (as JSON)

```json
{
  "Active": null
}
```

