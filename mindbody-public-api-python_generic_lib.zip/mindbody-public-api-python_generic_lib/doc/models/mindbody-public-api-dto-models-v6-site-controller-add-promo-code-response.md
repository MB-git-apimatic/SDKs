
# Mindbody Public Api Dto Models V6 Site Controller Add Promo Code Response

## Structure

`MindbodyPublicApiDtoModelsV6SiteControllerAddPromoCodeResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `promo_code` | [`MindbodyPublicApiDtoModelsV6PromoCode`](../../doc/models/mindbody-public-api-dto-models-v6-promo-code.md) | Optional | - |

## Example (as JSON)

```json
{
  "PromoCode": null
}
```

