
# Mindbody Public Api Common Models Unavailability

## Structure

`MindbodyPublicApiCommonModelsUnavailability`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `id` | `?int` | Optional | - | getId(): ?int | setId(?int id): void |
| `startDateTime` | `?\DateTime` | Optional | - | getStartDateTime(): ?\DateTime | setStartDateTime(?\DateTime startDateTime): void |
| `endDateTime` | `?\DateTime` | Optional | - | getEndDateTime(): ?\DateTime | setEndDateTime(?\DateTime endDateTime): void |
| `description` | `?string` | Optional | - | getDescription(): ?string | setDescription(?string description): void |

## Example (as JSON)

```json
{
  "Id": null,
  "StartDateTime": null,
  "EndDateTime": null,
  "Description": null
}
```

