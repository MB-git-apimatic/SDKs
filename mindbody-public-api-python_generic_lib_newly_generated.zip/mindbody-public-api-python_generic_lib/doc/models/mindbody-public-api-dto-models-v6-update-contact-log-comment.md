
# Mindbody Public Api Dto Models V6 Update Contact Log Comment

## Structure

`MindbodyPublicApiDtoModelsV6UpdateContactLogComment`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `int` | Optional | The ID of the contact log comment to be updated. Pass a value of `0` to add a new comment to the contact log. |
| `text` | `string` | Optional | The new text for the comment. |

## Example (as JSON)

```json
{
  "Id": null,
  "Text": null
}
```

