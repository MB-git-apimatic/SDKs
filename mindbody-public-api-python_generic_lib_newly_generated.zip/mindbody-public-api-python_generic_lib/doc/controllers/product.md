# Product

```python
product_controller = client.product
```

## Class Name

`ProductController`


# Product Update Products

Update retail products available for purchase at a site.

```python
def product_update_products(self,
                           site_id,
                           update_products_requests,
                           version,
                           authorization=None)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `site_id` | `string` | Header, Required | ID of the site from which to pull data. |
| `update_products_requests` | [`List of MindbodyPublicApiDtoModelsV6SaleControllerUpdateProductRequest`](../../doc/models/mindbody-public-api-dto-models-v6-sale-controller-update-product-request.md) | Body, Required | - |
| `version` | `string` | Template, Required | - |
| `authorization` | `string` | Header, Optional | A staff user authorization token. |

## Response Type

[`MindbodyPublicApiDtoModelsV6SaleControllerGetProductsResponse`](../../doc/models/mindbody-public-api-dto-models-v6-sale-controller-get-products-response.md)

## Example Usage

```python
site_id = '-99'
update_products_requests = []

update_products_requests.append(MindbodyPublicApiDtoModelsV6SaleControllerUpdateProductRequest())

update_products_requests.append(MindbodyPublicApiDtoModelsV6SaleControllerUpdateProductRequest())

version = 'version4'

result = product_controller.product_update_products(site_id, update_products_requests, version)
```

