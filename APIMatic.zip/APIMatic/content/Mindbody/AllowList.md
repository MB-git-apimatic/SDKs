﻿
The Public API Allowlist is an optional feature for all supported versions to protect your services from unauthorized usage.
When IPv4 addresses or address ranges are registered via our allowlisting web tool, only those addresses or ranges will have access to the Public API.
Usage of address ranges are optional and specified in CIDR notation.

- To activate the allowlist feature, allow at least one IP address.
- The allowlist is disabled when the allowlist is empty.
- A single IP address allowed will be converted to an IP range of 1 via a CIDR subnet mask of `/32`.
- The Public API allowlist has a limit of 32 IP ranges per account.

To access the Allowlist tool:

1. Log in to your [Mindbody developer account](https://developers.mindbodyonline.com).
2. In the upper right, click **Account**.
3. In the left side bar, click **Allowlist**.
