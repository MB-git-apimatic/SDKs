
# Mindbody Public Api Dto Models V6 Appointment Controller Get Available Dates Request

## Structure

`MindbodyPublicApiDtoModelsV6AppointmentControllerGetAvailableDatesRequest`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `sessionTypeId` | `int` | Required | required requested session type ID. | getSessionTypeId(): int | setSessionTypeId(int sessionTypeId): void |
| `locationId` | `?int` | Optional | optional requested location ID. | getLocationId(): ?int | setLocationId(?int locationId): void |
| `staffId` | `?int` | Optional | optional requested staff ID. | getStaffId(): ?int | setStaffId(?int staffId): void |
| `startDate` | `?\DateTime` | Optional | The start date of the requested date range. If omitted, the default is used.<br><br />Default: **today’s date** | getStartDate(): ?\DateTime | setStartDate(?\DateTime startDate): void |
| `endDate` | `?\DateTime` | Optional | The end date of the requested date range.<br><br />Default: **StartDate** | getEndDate(): ?\DateTime | setEndDate(?\DateTime endDate): void |

## Example (as JSON)

```json
{
  "SessionTypeId": 50,
  "LocationId": null,
  "StaffId": null,
  "StartDate": null,
  "EndDate": null
}
```

