
# Action Enum

## Enumeration

`ActionEnum`

## Fields

| Name |
|  --- |
| `NONE` |
| `ADDED` |
| `UPDATED` |
| `FAILED` |
| `REMOVED` |

