
# Mindbody Public Api Dto Models V6 Staff Controller Get Staff Session Types Response

## Structure

`MindbodyPublicApiDtoModelsV6StaffControllerGetStaffSessionTypesResponse`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `paginationResponse` | [`?MindbodyPublicApiDtoModelsV6PaginationResponse`](../../doc/models/mindbody-public-api-dto-models-v6-pagination-response.md) | Optional | - | getPaginationResponse(): ?MindbodyPublicApiDtoModelsV6PaginationResponse | setPaginationResponse(?MindbodyPublicApiDtoModelsV6PaginationResponse paginationResponse): void |
| `staffSessionTypes` | [`?(MindbodyPublicApiDtoModelsV6StaffSessionType[])`](../../doc/models/mindbody-public-api-dto-models-v6-staff-session-type.md) | Optional | Contains information about staff member session types. | getStaffSessionTypes(): ?array | setStaffSessionTypes(?array staffSessionTypes): void |

## Example (as JSON)

```json
{
  "PaginationResponse": null,
  "StaffSessionTypes": null
}
```

