
# Mindbody Public Api Dto Models V6 User

## Structure

`MindbodyPublicApiDtoModelsV6User`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `long\|int` | Optional | The user’s ID at the business. This is always 0 for Admin and Owner type users. |
| `first_name` | `string` | Optional | The user’s first name. |
| `last_name` | `string` | Optional | The user’s last name. |
| `mtype` | `string` | Optional | The user’s type. Possible values are:<br><br>* Staff<br>* Owner<br>* Admin |

## Example (as JSON)

```json
{
  "Id": null,
  "FirstName": null,
  "LastName": null,
  "Type": null
}
```

