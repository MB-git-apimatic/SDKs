
# Mindbody Public Api Dto Models V6 Appointment Controller Update Availability Request

This is the update avaialability request coming DTO

## Structure

`MindbodyPublicApiDtoModelsV6AppointmentControllerUpdateAvailabilityRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `availability_ids` | `List of int` | Optional | Availability Ids that are to be updated |
| `public_display` | [`PublicDisplayEnum`](../../doc/models/public-display-enum.md) | Optional | Choice that decides whether the availablity should be publicly visible, masked or hidden. |
| `days_of_week` | [`List of DaysOfWeekEnum`](../../doc/models/days-of-week-enum.md) | Optional | The day of the week |
| `program_ids` | `List of int` | Optional | The program Ids |
| `start_date_time` | `datetime` | Optional | - |
| `end_date_time` | `datetime` | Optional | The end date and time |
| `location_id` | `int` | Optional | The location id |
| `unavailable_description` | `string` | Optional | The description for the unavailability |
| `test` | `bool` | Optional | The test flag |

## Example (as JSON)

```json
{
  "AvailabilityIds": null,
  "PublicDisplay": null,
  "DaysOfWeek": null,
  "ProgramIds": null,
  "StartDateTime": null,
  "EndDateTime": null,
  "LocationId": null,
  "UnavailableDescription": null,
  "Test": null
}
```

