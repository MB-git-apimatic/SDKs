﻿<h2 id="developer-resource">Developer Resources</h2>
<script type="text/javascript">
    monitor('developer-resource');
</script>

This section includes resources for developers to use when building integrations with Mindbody.

<h3 id="swagger"><span>Swagger</span></h3>

Check out the [Mindbody Public API V6.0 Swagger documentation](https://api.mindbodyonline.com/public/v6/swagger/index) where you can explore V6.0 API calls in your browser.