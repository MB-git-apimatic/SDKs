
# Mindbody Public Api Dto Models V6 Site Controller Get Relationships Request

Get Relationships Request Model

## Structure

`MindbodyPublicApiDtoModelsV6SiteControllerGetRelationshipsRequest`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `active` | `?bool` | Optional | When `true`, the response only contains relationships which are activated.<br>When `false`, only deactivated relationships are returned.<br>Default: **All Relationships** | getActive(): ?bool | setActive(?bool active): void |
| `limit` | `?int` | Optional | Number of results to include, defaults to 100 | getLimit(): ?int | setLimit(?int limit): void |
| `offset` | `?int` | Optional | Page offset, defaults to 0. | getOffset(): ?int | setOffset(?int offset): void |

## Example (as JSON)

```json
{
  "Active": null,
  "Limit": null,
  "Offset": null
}
```

