
# Mindbody Public Api Dto Models V6 Appointment Controller Get Schedule Items Request

## Structure

`MindbodyPublicApiDtoModelsV6AppointmentControllerGetScheduleItemsRequest`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `locationIds` | `?(int[])` | Optional | A list of requested location IDs. | getLocationIds(): ?array | setLocationIds(?array locationIds): void |
| `staffIds` | `?(int[])` | Optional | A list of requested staff IDs. | getStaffIds(): ?array | setStaffIds(?array staffIds): void |
| `startDate` | `?\DateTime` | Optional | The start date of the requested date range.<br><br />Default: **today’s date** | getStartDate(): ?\DateTime | setStartDate(?\DateTime startDate): void |
| `endDate` | `?\DateTime` | Optional | The end date of the requested date range.<br><br />Default: **today’s date** | getEndDate(): ?\DateTime | setEndDate(?\DateTime endDate): void |
| `ignorePrepFinishTimes` | `?bool` | Optional | When `true`, appointment preparation and finish unavailabilities are not returned.<br><br />Default: **false** | getIgnorePrepFinishTimes(): ?bool | setIgnorePrepFinishTimes(?bool ignorePrepFinishTimes): void |
| `limit` | `?int` | Optional | Number of results to include, defaults to 100 | getLimit(): ?int | setLimit(?int limit): void |
| `offset` | `?int` | Optional | Page offset, defaults to 0. | getOffset(): ?int | setOffset(?int offset): void |

## Example (as JSON)

```json
{
  "LocationIds": null,
  "StaffIds": null,
  "StartDate": null,
  "EndDate": null,
  "IgnorePrepFinishTimes": null,
  "Limit": null,
  "Offset": null
}
```

