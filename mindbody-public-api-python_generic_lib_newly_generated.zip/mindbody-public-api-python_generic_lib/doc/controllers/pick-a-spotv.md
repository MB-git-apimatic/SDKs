# Pick a Spotv

```python
pick_a_spotv_controller = client.pick_a_spotv
```

## Class Name

`PickASpotvController`

## Methods

* [Pick a Spotv Class List](../../doc/controllers/pick-a-spotv.md#pick-a-spotv-class-list)
* [Pick a Spotv Class](../../doc/controllers/pick-a-spotv.md#pick-a-spotv-class)
* [Pick a Spotv Reservation Get](../../doc/controllers/pick-a-spotv.md#pick-a-spotv-reservation-get)
* [Pick a Spotv Reservation Put](../../doc/controllers/pick-a-spotv.md#pick-a-spotv-reservation-put)
* [Pick a Spotv Reservation Post](../../doc/controllers/pick-a-spotv.md#pick-a-spotv-reservation-post)
* [Pick a Spotv Reservation Delete](../../doc/controllers/pick-a-spotv.md#pick-a-spotv-reservation-delete)


# Pick a Spotv Class List

```python
def pick_a_spotv_class_list(self,
                           site_id,
                           version,
                           authorization=None)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `site_id` | `string` | Header, Required | ID of the site from which to pull data. |
| `version` | `string` | Template, Required | - |
| `authorization` | `string` | Header, Optional | A staff user authorization token. |

## Response Type

`object`

## Example Usage

```python
site_id = '-99'
version = 'version4'

result = pick_a_spotv_controller.pick_a_spotv_class_list(site_id, version)
```


# Pick a Spotv Class

```python
def pick_a_spotv_class(self,
                      class_id,
                      site_id,
                      version,
                      authorization=None)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `class_id` | `string` | Template, Required | - |
| `site_id` | `string` | Header, Required | ID of the site from which to pull data. |
| `version` | `string` | Template, Required | - |
| `authorization` | `string` | Header, Optional | A staff user authorization token. |

## Response Type

`object`

## Example Usage

```python
class_id = 'classId0'
site_id = '-99'
version = 'version4'

result = pick_a_spotv_controller.pick_a_spotv_class(class_id, site_id, version)
```


# Pick a Spotv Reservation Get

```python
def pick_a_spotv_reservation_get(self,
                                path_info,
                                site_id,
                                version,
                                authorization=None)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `path_info` | `string` | Template, Required | - |
| `site_id` | `string` | Header, Required | ID of the site from which to pull data. |
| `version` | `string` | Template, Required | - |
| `authorization` | `string` | Header, Optional | A staff user authorization token. |

## Response Type

`object`

## Example Usage

```python
path_info = 'pathInfo8'
site_id = '-99'
version = 'version4'

result = pick_a_spotv_controller.pick_a_spotv_reservation_get(path_info, site_id, version)
```


# Pick a Spotv Reservation Put

```python
def pick_a_spotv_reservation_put(self,
                                path_info,
                                site_id,
                                version,
                                authorization=None)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `path_info` | `string` | Template, Required | - |
| `site_id` | `string` | Header, Required | ID of the site from which to pull data. |
| `version` | `string` | Template, Required | - |
| `authorization` | `string` | Header, Optional | A staff user authorization token. |

## Response Type

`object`

## Example Usage

```python
path_info = 'pathInfo8'
site_id = '-99'
version = 'version4'

result = pick_a_spotv_controller.pick_a_spotv_reservation_put(path_info, site_id, version)
```


# Pick a Spotv Reservation Post

```python
def pick_a_spotv_reservation_post(self,
                                 path_info,
                                 site_id,
                                 version,
                                 authorization=None)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `path_info` | `string` | Template, Required | - |
| `site_id` | `string` | Header, Required | ID of the site from which to pull data. |
| `version` | `string` | Template, Required | - |
| `authorization` | `string` | Header, Optional | A staff user authorization token. |

## Response Type

`object`

## Example Usage

```python
path_info = 'pathInfo8'
site_id = '-99'
version = 'version4'

result = pick_a_spotv_controller.pick_a_spotv_reservation_post(path_info, site_id, version)
```


# Pick a Spotv Reservation Delete

```python
def pick_a_spotv_reservation_delete(self,
                                   path_info,
                                   site_id,
                                   version,
                                   authorization=None)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `path_info` | `string` | Template, Required | - |
| `site_id` | `string` | Header, Required | ID of the site from which to pull data. |
| `version` | `string` | Template, Required | - |
| `authorization` | `string` | Header, Optional | A staff user authorization token. |

## Response Type

`object`

## Example Usage

```python
path_info = 'pathInfo8'
site_id = '-99'
version = 'version4'

result = pick_a_spotv_controller.pick_a_spotv_reservation_delete(path_info, site_id, version)
```

