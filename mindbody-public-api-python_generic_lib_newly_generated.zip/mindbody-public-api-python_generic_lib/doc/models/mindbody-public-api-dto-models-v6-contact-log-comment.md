
# Mindbody Public Api Dto Models V6 Contact Log Comment

A contact log comment.

## Structure

`MindbodyPublicApiDtoModelsV6ContactLogComment`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `int` | Optional | The comment’s ID. |
| `text` | `string` | Optional | The comment’s body text. |
| `created_date_time` | `datetime` | Optional | The local time when the comment was created. |
| `created_by` | [`MindbodyPublicApiDtoModelsV6Staff`](../../doc/models/mindbody-public-api-dto-models-v6-staff.md) | Optional | - |

## Example (as JSON)

```json
{
  "Id": null,
  "Text": null,
  "CreatedDateTime": null,
  "CreatedBy": null
}
```

