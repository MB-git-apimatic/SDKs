
# Purchase

## Structure

`Purchase`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `consumer_id` | `String` | Optional | - |
| `product_name` | `String` | Optional | - |
| `product_category` | `String` | Optional | - |
| `payment_method` | `String` | Optional | - |
| `amount_paid` | `Float` | Optional | - |
| `purchase_date` | `DateTime` | Optional | - |
| `product_type` | `String` | Optional | - |
| `quantity` | `Integer` | Optional | - |

## Example (as JSON)

```json
{
  "consumerId": null,
  "productName": null,
  "productCategory": null,
  "paymentMethod": null,
  "amountPaid": null,
  "purchaseDate": null,
  "productType": null,
  "quantity": null
}
```

