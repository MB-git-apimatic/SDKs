
# Mindbody Public Api Dto Models V6 Site Controller Get Resources Request

## Structure

`MindbodyPublicApiDtoModelsV6SiteControllerGetResourcesRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `session_type_ids` | `List of int` | Optional | List of session type IDs.<br /><br>Default: **all** |
| `location_id` | `int` | Optional | The location of the resource. This parameter is ignored if `EndDateTime` or `LocationID` is not set.<br /><br>Default: **all** |
| `start_date_time` | `datetime` | Optional | The time the resource starts. This parameter is ignored if `EndDateTime` or `LocationID` is not set. |
| `end_date_time` | `datetime` | Optional | The time the resource ends. This parameter is ignored if `EndDateTime` or `LocationID` is not set. |
| `limit` | `int` | Optional | Number of results to include, defaults to 100 |
| `offset` | `int` | Optional | Page offset, defaults to 0. |

## Example (as JSON)

```json
{
  "SessionTypeIds": null,
  "LocationId": null,
  "StartDateTime": null,
  "EndDateTime": null,
  "Limit": null,
  "Offset": null
}
```

