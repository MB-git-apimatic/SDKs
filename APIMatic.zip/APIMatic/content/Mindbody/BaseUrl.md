﻿<script type="text/javascript">
monitor('base-url');
</script>

The base URL for the Public API is:<br><br>
[https://api.mindbodyonline.com/public/v6/](https://api.mindbodyonline.com/public/v6/)
