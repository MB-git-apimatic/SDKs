
# Mindbody Public Api Dto Models V6 Client Controller Formula Note Response

An individual Client Formula Note.

## Structure

`MindbodyPublicApiDtoModelsV6ClientControllerFormulaNoteResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `long\|int` | Optional | The unique Id of the Formula Note. |
| `client_id` | `string` | Optional | The unique Id of the Client for the formula note |
| `appointment_id` | `long\|int` | Optional | The unique Id of the Appointment if the Formula Note was added to a specific appointment. |
| `entry_date` | `datetime` | Optional | The Date the Formula Note was created. |
| `note` | `string` | Optional | The Note itself |
| `site_id` | `int` | Optional | The SiteId where the Formula Note originated. |
| `site_name` | `string` | Optional | The name of the Site where the Formula Note originated. |
| `staff_first_name` | `string` | Optional | The first name of the Staff for the associated appointment. |
| `staff_last_name` | `string` | Optional | The last name of the Staff for the associated appointment. |
| `staff_display_name` | `string` | Optional | The display name of the Staff for the associated appointment. |

## Example (as JSON)

```json
{
  "Id": null,
  "ClientId": null,
  "AppointmentId": null,
  "EntryDate": null,
  "Note": null,
  "SiteId": null,
  "SiteName": null,
  "StaffFirstName": null,
  "StaffLastName": null,
  "StaffDisplayName": null
}
```

