
# Mindbody Public Api Dto Models V6 Class Controller Remove Client From Class Request

## Structure

`MindbodyPublicApiDtoModelsV6ClassControllerRemoveClientFromClassRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `client_id` | `string` | Required | The RSSID of the client to remove from the specified class. |
| `class_id` | `int` | Required | The ID of the class that you want to remove the client from. |
| `test` | `bool` | Optional | When `true`, the request ensures that its parameters are valid without affecting real data.<br /><br>When `false`, the request performs as intended and may affect live client data.<br /><br>Default: **false** |
| `send_email` | `bool` | Optional | When `true`, indicates that the client should be sent an email. Depending on the site and client settings, an email may or may not be sent.<br /><br>Default: **false** |
| `late_cancel` | `bool` | Optional | When `true`, indicates that the client is to be late cancelled from the class.<br /><br>When `false`, indicates that the client is to be early cancelled from the class.<br /><br>Default: **false** |

## Example (as JSON)

```json
{
  "ClientId": "ClientId6",
  "ClassId": 58,
  "Test": null,
  "SendEmail": null,
  "LateCancel": null
}
```

