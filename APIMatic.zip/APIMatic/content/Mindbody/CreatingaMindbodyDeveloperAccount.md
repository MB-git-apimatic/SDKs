﻿<h1 id="mindbody-public-api-v6-0">Mindbody Public API V6.0</h1>
<script type="text/javascript">
    monitor('mindbody-public-api-v6-0');
</script>

<h2 id="getting-started">Getting Started</h2>
<script type="text/javascript">
    monitor('getting-started');
</script>

To develop and integrate an application using the Mindbody Public APIs, you'll need to do the following:

1. Create a Mindbody developer account.
2. Write your application, using the Mindbody sandbox for development and testing.
3. Request approval from Mindbody to take your application live.
4. Request a site-specific activation code or an activation link for a specific business owner's Mindbody account so that your application can access the owner's business data.
5. Send the activation code or the activation link to the business owner to activate.

You'll need to follow these processes in the order given.

<h3 id="creating-dev-account"><span>Creating a Mindbody Developer Account</span></h3>

Before you can log in to the developer portal, you must create a Mindbody developer account.

**To create a Mindbody developer account**

1. [Fill out the form for a developer account](https://developers.mindbodyonline.com/Home/SignUp).
<br>It is important to note that Mindbody takes the business name that you enter on this form and makes it the ```SourceName``` parameter used for Public API calls. This name cannot be changed once you have submitted this form.
2. Click **Submit**.
<br>You can then log in to your developer account from [https://developers.mindbodyonline.com/Home/LogIn](https://developers.mindbodyonline.com/Home/LogIn)
