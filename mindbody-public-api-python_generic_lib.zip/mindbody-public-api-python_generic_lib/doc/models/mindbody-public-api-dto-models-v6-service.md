
# Mindbody Public Api Dto Models V6 Service

## Structure

`MindbodyPublicApiDtoModelsV6Service`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `price` | `float` | Optional | The cost of the pricing option when sold at a physical location. |
| `online_price` | `float` | Optional | The cost of the pricing option when sold online. |
| `tax_included` | `float` | Optional | The amount of tax included in the price, if inclusive pricing is enabled. |
| `program_id` | `int` | Optional | The ID of the program that this pricing option applies to. |
| `tax_rate` | `float` | Optional | The tax rate applied to the pricing option. This field is populated only when you include a `LocationID` in the request. |
| `product_id` | `int` | Optional | The unique ID of the pricing option. |
| `id` | `string` | Optional | The barcode ID of the pricing option. |
| `name` | `string` | Optional | The name of the pricing option. |
| `count` | `int` | Optional | The initial count of usages available for the pricing option. |
| `sell_online` | `bool` | Optional | A flag for whether or not the pricing option is sold online. |
| `mtype` | `string` | Optional | Indicates if the pricing option is a drop-in, series, or unlimiited. |
| `expiration_type` | `string` | Optional | Indicates if the pricing option begins its activation on the date of sale or first usage. |
| `expiration_unit` | `string` | Optional | The unit, either days or months, of ExpirationLength. |
| `expiration_length` | `int` | Optional | The lifetime of a pricing option. |
| `revenue_category` | `string` | Optional | The revenue category of the pricing option. |
| `membership_id` | `int` | Optional | The ID that this pricing option grants membership to. |
| `sell_at_location_ids` | `List of int` | Optional | The location IDs where this pricing option is sold. |
| `use_at_location_ids` | `List of int` | Optional | The location IDs where this pricing option may be used. |
| `priority` | `string` | Optional | The priority of the pricing option. |
| `is_intro_offer` | `bool` | Optional | A flag that indicates if this pricing option is an introductory offer. |
| `intro_offer_type` | `string` | Optional | Indicates if this pricing option may be purchased to new clients or all clients. |
| `is_third_party_discount_pricing` | `bool` | Optional | A flag that indicates if this pricing option involves a third party discount |
| `program` | `string` | Optional | The name of the program corresponding to ProgramId. |
| `discontinued` | `bool` | Optional | Whether this pricing option has been discontinued or not |

## Example (as JSON)

```json
{
  "Price": null,
  "OnlinePrice": null,
  "TaxIncluded": null,
  "ProgramId": null,
  "TaxRate": null,
  "ProductId": null,
  "Id": null,
  "Name": null,
  "Count": null,
  "SellOnline": null,
  "Type": null,
  "ExpirationType": null,
  "ExpirationUnit": null,
  "ExpirationLength": null,
  "RevenueCategory": null,
  "MembershipId": null,
  "SellAtLocationIds": null,
  "UseAtLocationIds": null,
  "Priority": null,
  "IsIntroOffer": null,
  "IntroOfferType": null,
  "IsThirdPartyDiscountPricing": null,
  "Program": null,
  "Discontinued": null
}
```

