
# Mindbody Public Api Dto Models V6 Credit Card Info

INformation about an individual credit card

## Structure

`MindbodyPublicApiDtoModelsV6CreditCardInfo`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `credit_card_number` | `string` | Optional | - |
| `exp_month` | `string` | Optional | - |
| `exp_year` | `string` | Optional | - |
| `billing_name` | `string` | Optional | - |
| `billing_address` | `string` | Optional | - |
| `billing_city` | `string` | Optional | - |
| `billing_state` | `string` | Optional | - |
| `billing_postal_code` | `string` | Optional | - |
| `save_info` | `bool` | Optional | - |
| `card_id` | `string` | Optional | Card Id of a stored instruments card |

## Example (as JSON)

```json
{
  "CreditCardNumber": null,
  "ExpMonth": null,
  "ExpYear": null,
  "BillingName": null,
  "BillingAddress": null,
  "BillingCity": null,
  "BillingState": null,
  "BillingPostalCode": null,
  "SaveInfo": null,
  "CardId": null
}
```

