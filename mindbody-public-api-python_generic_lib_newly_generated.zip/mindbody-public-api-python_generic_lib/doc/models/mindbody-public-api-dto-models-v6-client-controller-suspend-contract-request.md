
# Mindbody Public Api Dto Models V6 Client Controller Suspend Contract Request

## Structure

`MindbodyPublicApiDtoModelsV6ClientControllerSuspendContractRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `client_id` | `string` | Required | The RSSID of the client for whom the contract is getting suspended. |
| `client_contract_id` | `int` | Required | The unique ID of the sale of the contract |
| `suspension_type` | `string` | Optional | The suspension type |
| `suspension_start` | `datetime` | Optional | The date to start contract suspension |
| `duration` | `int` | Optional | The number of (DurationUnit) the suspension lasts |
| `duration_unit` | `int` | Optional | The unit applied to duration |
| `open_ended` | `bool` | Optional | Indicates open ended suspension |
| `suspension_notes` | `string` | Optional | The suspension notes |
| `suspension_fee` | `float` | Optional | charge to suspend a contract for a set period of time |

## Example (as JSON)

```json
{
  "ClientId": "ClientId6",
  "ClientContractId": 86,
  "SuspensionType": null,
  "SuspensionStart": null,
  "Duration": null,
  "DurationUnit": null,
  "OpenEnded": null,
  "SuspensionNotes": null,
  "SuspensionFee": null
}
```

