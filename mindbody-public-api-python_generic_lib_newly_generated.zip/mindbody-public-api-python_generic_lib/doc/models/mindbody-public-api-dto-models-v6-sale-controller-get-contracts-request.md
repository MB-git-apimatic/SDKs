
# Mindbody Public Api Dto Models V6 Sale Controller Get Contracts Request

## Structure

`MindbodyPublicApiDtoModelsV6SaleControllerGetContractsRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `contract_ids` | `List of int` | Optional | When included, the response only contains details about the specified contract IDs. |
| `sold_online` | `bool` | Optional | When `true`, the response only contains details about contracts and AutoPay options that can be sold online.<br>When `false`, all contracts are returned.<br>Default: **false** |
| `location_id` | `int` | Required | The ID of the location that has the requested contracts and AutoPay options. |
| `consumer_id` | `long\|int` | Optional | The ID of the client. |
| `promo_code` | `string` | Optional | PromoCode to apply |
| `limit` | `int` | Optional | Number of results to include, defaults to 100 |
| `offset` | `int` | Optional | Page offset, defaults to 0. |

## Example (as JSON)

```json
{
  "ContractIds": null,
  "SoldOnline": null,
  "LocationId": 50,
  "ConsumerId": null,
  "PromoCode": null,
  "Limit": null,
  "Offset": null
}
```

