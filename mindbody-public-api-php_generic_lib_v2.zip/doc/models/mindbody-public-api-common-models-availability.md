
# Mindbody Public Api Common Models Availability

## Structure

`MindbodyPublicApiCommonModelsAvailability`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `id` | `?int` | Optional | - | getId(): ?int | setId(?int id): void |
| `staff` | [`?MindbodyPublicApiCommonModelsStaff`](../../doc/models/mindbody-public-api-common-models-staff.md) | Optional | - | getStaff(): ?MindbodyPublicApiCommonModelsStaff | setStaff(?MindbodyPublicApiCommonModelsStaff staff): void |
| `sessionType` | [`?MindbodyPublicApiCommonModelsSessionType`](../../doc/models/mindbody-public-api-common-models-session-type.md) | Optional | - | getSessionType(): ?MindbodyPublicApiCommonModelsSessionType | setSessionType(?MindbodyPublicApiCommonModelsSessionType sessionType): void |
| `programs` | [`?(MindbodyPublicApiCommonModelsProgram[])`](../../doc/models/mindbody-public-api-common-models-program.md) | Optional | - | getPrograms(): ?array | setPrograms(?array programs): void |
| `startDateTime` | `?\DateTime` | Optional | - | getStartDateTime(): ?\DateTime | setStartDateTime(?\DateTime startDateTime): void |
| `endDateTime` | `?\DateTime` | Optional | - | getEndDateTime(): ?\DateTime | setEndDateTime(?\DateTime endDateTime): void |
| `bookableEndDateTime` | `?\DateTime` | Optional | - | getBookableEndDateTime(): ?\DateTime | setBookableEndDateTime(?\DateTime bookableEndDateTime): void |
| `location` | [`?MindbodyPublicApiCommonModelsLocation`](../../doc/models/mindbody-public-api-common-models-location.md) | Optional | - | getLocation(): ?MindbodyPublicApiCommonModelsLocation | setLocation(?MindbodyPublicApiCommonModelsLocation location): void |
| `prepTime` | `?int` | Optional | - | getPrepTime(): ?int | setPrepTime(?int prepTime): void |
| `finishTime` | `?int` | Optional | - | getFinishTime(): ?int | setFinishTime(?int finishTime): void |

## Example (as JSON)

```json
{
  "Id": null,
  "Staff": null,
  "SessionType": null,
  "Programs": null,
  "StartDateTime": null,
  "EndDateTime": null,
  "BookableEndDateTime": null,
  "Location": null,
  "PrepTime": null,
  "FinishTime": null
}
```

