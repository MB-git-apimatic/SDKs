﻿## Purchase an Appointment Pass
<script type="text/javascript">
monitor('purchase-an-appointment-pass');
</script>

> Step 2: Get locations

:::visible {language=http}
```
curl -X GET \
  'https://api.mindbodyonline.com/public/v6/site/locations' \
  -H 'Api-Key: {yourApiKey}' \
  -H 'Authorization: {staffAuthToken}' \
  -H 'SiteId: {yourSiteId}' \
  -A '{yourAppName}'
```
:::

:::visible {language=csharp}
```
var client = new RestClient("https://api.mindbodyonline.com/public/v6/site/locations");
var request = new RestRequest(Method.GET);
request.AddHeader("Authorization", "{staffAuthToken}");
request.AddHeader("SiteId", "{yourSiteId}");
request.AddHeader("Api-Key", "{yourApiKey}");
IRestResponse response = client.Execute(request);
```
:::

:::visible {language=php}
```
<?php

$request = new HttpRequest();
$request->setUrl('https://api.mindbodyonline.com/public/v6/site/locations');
$request->setMethod(HTTP_METH_GET);

$request->setHeaders(array(
  'Authorization' => '{staffAuthToken}',
  'SiteId' => '{yourSiteId}',
  'Api-Key' => '{yourApiKey}'
));

try {
  $response = $request->send();

  echo $response->getBody();
} catch (HttpException $ex) {
  echo $ex;
}
```
:::

:::visible {language=python}
```
import http.client

conn = http.client.HTTPSConnection("api.mindbodyonline.com")

headers = {
	'Api-Key': "{yourApiKey}",
    'SiteId': "{yourSiteId}",
    'Authorization': "{staffAuthToken}"
    }

conn.request("GET", "/public/v6/site/locations", headers=headers)

res = conn.getresponse()
data = res.read()

print(data.decode("utf-8"))
```
:::

:::visible {language=ruby}
```
require 'uri'
require 'net/http'

url = URI("https://api.mindbodyonline.com/public/v6/site/locations")

http = Net::HTTP.new(url.host, url.port)
http.use_ssl = true
http.verify_mode = OpenSSL::SSL::VERIFY_NONE

request = Net::HTTP::Get.new(url)
request["Api-Key"] = '{yourApiKey}'
request["SiteId"] = '{yourSiteId}'
request["Authorization"] = '{staffAuthToken}'

response = http.request(request)
puts response.read_body
```
:::

> Step 3: Get session types

:::visible {language=http}
```
curl -X GET \
  'https://api.mindbodyonline.com/public/v6/site/sessiontypes' \
  -H 'Api-Key: {yourApiKey}' \
  -H 'Authorization: {staffAuthToken}' \
  -H 'SiteId: {yourSiteId}' \
  -A '{yourAppName}'
```
:::

:::visible {language=csharp}
```
var client = new RestClient("https://api.mindbodyonline.com/public/v6/site/sessiontypes");
var request = new RestRequest(Method.GET);
request.AddHeader("Authorization", "{staffAuthToken}");
request.AddHeader("SiteId", "{yourSiteId}");
request.AddHeader("Api-Key", "{yourApiKey}");
IRestResponse response = client.Execute(request);
```
:::

:::visible {language=php}
```
<?php

$request = new HttpRequest();
$request->setUrl('https://api.mindbodyonline.com/public/v6/site/sessiontypes');
$request->setMethod(HTTP_METH_GET);

$request->setHeaders(array(
  'Authorization' => '{staffAuthToken}',
  'SiteId' => '{yourSiteId}',
  'Api-Key' => '{yourApiKey}'
));

try {
  $response = $request->send();

  echo $response->getBody();
} catch (HttpException $ex) {
  echo $ex;
}
```
:::

:::visible {language=python}
```
import http.client

conn = http.client.HTTPSConnection("api.mindbodyonline.com")

headers = {
	'Api-Key': "{yourApiKey}",
    'SiteId': "{yourSiteId}",
    'Authorization': "{staffAuthToken}"
    }

conn.request("GET", "/public/v6/site/sessiontypes", headers=headers)

res = conn.getresponse()
data = res.read()

print(data.decode("utf-8"))
```
:::

:::visible {language=ruby}
```
require 'uri'
require 'net/http'

url = URI("https://api.mindbodyonline.com/public/v6/site/sessiontypes")

http = Net::HTTP.new(url.host, url.port)
http.use_ssl = true
http.verify_mode = OpenSSL::SSL::VERIFY_NONE

request = Net::HTTP::Get.new(url)
request["Api-Key"] = '{yourApiKey}'
request["SiteId"] = '{yourSiteId}'
request["Authorization"] = '{staffAuthToken}'

response = http.request(request)
puts response.read_body
```
:::

> Step 4: Get services for a specific session type

:::visible {language=http}
```
curl -X GET \
  'https://api.mindbodyonline.com/public/v6/sale/services?sessionTypeId=34' \
  -H 'Api-Key: {yourApiKey}' \
  -H 'Authorization: {staffAuthToken}' \
  -H 'SiteId: {yourSiteId}' \
  -A '{yourAppName}'
```
:::

:::visible {language=csharp}
```
var client = new RestClient("https://api.mindbodyonline.com/public/v6/sale/services?sessionTypeId=34");
var request = new RestRequest(Method.GET);
request.AddHeader("Authorization", "{staffAuthToken}");
request.AddHeader("SiteId", "{yourSiteId}");
request.AddHeader("Api-Key", "{yourApiKey}");
IRestResponse response = client.Execute(request);
```
:::

:::visible {language=php}
```
<?php

$request = new HttpRequest();
$request->setUrl('https://api.mindbodyonline.com/public/v6/sale/services');
$request->setMethod(HTTP_METH_GET);

$request->setQueryData(array(
  'sessionTypeId' => '34'
));

$request->setHeaders(array(
  'Authorization' => '{staffAuthToken}',
  'SiteId' => '{yourSiteId}',
  'Api-Key' => '{yourApiKey}'
));

try {
  $response = $request->send();

  echo $response->getBody();
} catch (HttpException $ex) {
  echo $ex;
}
```
:::

:::visible {language=python}
```
import http.client

conn = http.client.HTTPSConnection("api.mindbodyonline.com")

headers = {
	'Api-Key': "{yourApiKey}",
    'SiteId': "{yourSiteId}",
    'Authorization': "{staffAuthToken}"
    }

conn.request("GET", "/public/v6/sale/services?sessionTypeId=34", headers=headers)

res = conn.getresponse()
data = res.read()

print(data.decode("utf-8"))
```
:::

:::visible {language=ruby}
```
require 'uri'
require 'net/http'

url = URI("https://api.mindbodyonline.com/public/v6/sale/services?sessionTypeId=34")

http = Net::HTTP.new(url.host, url.port)
http.use_ssl = true
http.verify_mode = OpenSSL::SSL::VERIFY_NONE

request = Net::HTTP::Get.new(url)
request["Api-Key"] = '{yourApiKey}'
request["SiteId"] = '{yourSiteId}'
request["Authorization"] = '{staffAuthToken}'

response = http.request(request)
puts response.read_body
```
:::

> Step 5: Purchase a service that will pay for a session type

:::visible {language=http}
```
curl -X POST \
  'https://api.mindbodyonline.com/public/v6/sale/checkoutshoppingcart' \
  -H 'Content-Type: application/json' \
  -H 'Api-Key: {yourApiKey}' \
  -H 'Authorization: {staffAuthToken}' \
  -H 'SiteId: {yourSiteId}' \
  -A '{yourAppName}' \
  -d '{
	"ClientId" : "100000556",
	"Test" : false,
	"LocationId" : 1,
	"Items" : 
	[
		{
			"Item":{
				"Type": "Service",
				"Metadata":{
					"Id": 10114
				}
			},
			"DiscountAmount" : 0,
			"Quantity" : 1
		}
	],
	"Payments" : 
	[
		{
			"Type": "Comp",
			"Metadata":{
				"Amount" : 75
			}
		}
	]
}'
```
:::

:::visible {language=csharp}
```
var client = new RestClient("https://api.mindbodyonline.com/public/v6/sale/checkoutshoppingcart");
var request = new RestRequest(Method.POST);
request.AddHeader("Authorization", "{staffAuthToken}");
request.AddHeader("SiteId", "{yourSiteId}");
request.AddHeader("Api-Key", "{yourApiKey}");
request.AddParameter("application/json", "{\r\n\t\"ClientId\" : \"100000556\",\r\n\t\"Test\" : false,\r\n\t\"LocationId\" : 1,\r\n\t\"Items\" : \r\n\t[\r\n\t\t{\r\n\t\t\t\"Item\":{\r\n\t\t\t\t\"Type\": \"Service\",\r\n\t\t\t\t\"Metadata\":{\r\n\t\t\t\t\t\"Id\": 10114\r\n\t\t\t\t}\r\n\t\t\t},\r\n\t\t\t\"DiscountAmount\" : 0,\r\n\t\t\t\"Quantity\" : 1\r\n\t\t}\r\n\t],\r\n\t\"Payments\" : \r\n\t[\r\n\t\t{\r\n\t\t\t\"Type\": \"Comp\",\r\n\t\t\t\"Metadata\":{\r\n\t\t\t\t\"Amount\" : 75\r\n\t\t\t}\r\n\t\t}\r\n\t]\r\n}", ParameterType.RequestBody);
IRestResponse response = client.Execute(request);
```
:::

:::visible {language=php}
```
<?php

$request = new HttpRequest();
$request->setUrl('https://api.mindbodyonline.com/public/v6/sale/checkoutshoppingcart');
$request->setMethod(HTTP_METH_POST);

$request->setHeaders(array(
  'Authorization' => '{staffAuthToken}',
  'Content-Type' => 'application/json',
  'SiteId' => '{yourSiteId}',
  'Api-Key' => '{yourApiKey}'
));

$request->setBody('{
	"ClientId" : "100000556",
	"Test" : false,
	"LocationId" : 1,
	"Items" : 
	[
		{
			"Item":{
				"Type": "Service",
				"Metadata":{
					"Id": 10114
				}
			},
			"DiscountAmount" : 0,
			"Quantity" : 1
		}
	],
	"Payments" : 
	[
		{
			"Type": "Comp",
			"Metadata":{
				"Amount" : 75
			}
		}
	]
}');

try {
  $response = $request->send();

  echo $response->getBody();
} catch (HttpException $ex) {
  echo $ex;
}
```
:::

:::visible {language=python}
```
import http.client

conn = http.client.HTTPSConnection("api.mindbodyonline.com")

payload = "{\r\n\t\"ClientId\" : \"100000556\",\r\n\t\"Test\" : false,\r\n\t\"LocationId\" : 1,\r\n\t\"Items\" : \r\n\t[\r\n\t\t{\r\n\t\t\t\"Item\":{\r\n\t\t\t\t\"Type\": \"Service\",\r\n\t\t\t\t\"Metadata\":{\r\n\t\t\t\t\t\"Id\": 10114\r\n\t\t\t\t}\r\n\t\t\t},\r\n\t\t\t\"DiscountAmount\" : 0,\r\n\t\t\t\"Quantity\" : 1\r\n\t\t}\r\n\t],\r\n\t\"Payments\" : \r\n\t[\r\n\t\t{\r\n\t\t\t\"Type\": \"Comp\",\r\n\t\t\t\"Metadata\":{\r\n\t\t\t\t\"Amount\" : 75\r\n\t\t\t}\r\n\t\t}\r\n\t]\r\n}"

headers = {
    'Content-Type': "application/json",
	'Api-Iey': "{yourApiKey}",
    'SiteId': "{yourSiteId}",
    'Authorization': "{staffAuthToken}"
    }

conn.request("POST", "/public/v6/sale/checkoutshoppingcart", payload, headers)

res = conn.getresponse()
data = res.read()

print(data.decode("utf-8"))
```
:::

:::visible {language=ruby}
```
require 'uri'
require 'net/http'

url = URI("https://api.mindbodyonline.com/public/v6/sale/checkoutshoppingcart")

http = Net::HTTP.new(url.host, url.port)
http.use_ssl = true
http.verify_mode = OpenSSL::SSL::VERIFY_NONE

request = Net::HTTP::Post.new(url)
request["Content-Type"] = 'application/json'
request["Api-Key"] = '{yourApiKey}'
request["SiteId"] = '{yourSiteId}'
request["Authorization"] = '{staffAuthToken}'
request.body = "{\r\n\t\"ClientId\" : \"100000556\",\r\n\t\"Test\" : false,\r\n\t\"LocationId\" : 1,\r\n\t\"Items\" : \r\n\t[\r\n\t\t{\r\n\t\t\t\"Item\":{\r\n\t\t\t\t\"Type\": \"Service\",\r\n\t\t\t\t\"Metadata\":{\r\n\t\t\t\t\t\"Id\": 10114\r\n\t\t\t\t}\r\n\t\t\t},\r\n\t\t\t\"DiscountAmount\" : 0,\r\n\t\t\t\"Quantity\" : 1\r\n\t\t}\r\n\t],\r\n\t\"Payments\" : \r\n\t[\r\n\t\t{\r\n\t\t\t\"Type\": \"Comp\",\r\n\t\t\t\"Metadata\":{\r\n\t\t\t\t\"Amount\" : 75\r\n\t\t\t}\r\n\t\t}\r\n\t]\r\n}"

response = http.request(request)
puts response.read_body
```
:::

<h3 class="toc-ignore">Summary</h3>
This tutorial demonstrates how a staff member can purchase an appointment pass for a client. The client must be able to pay with a stored credit card, account balance, or gift card.

<h3 class="toc-ignore">Workflow</h3>

Note that you need to determine the client ID from your own application, as the Mindbody Public API does not validate client logins.

<ol class="step-list">
<li>Get a user authentication token for the staff member by passing the staff member's login credentials to the authentication endpoint. For a description of the user authentication process, see <a href="#user-tokens">User Tokens</a>. For all following steps, put the token you receive into the <code>Authorization</code> header formatted as <code>Bearer {authToken}</code>.</li>
<li>Use the <a href="#get-locations">GetLocations</a> endpoint to retrieve business locations. Each location object that returns has a location ID.</li>
<li>Use the <a href="#get-session-types">GetSessionTypes</a> endpoint to retrieve session types. Each session type object that returns has an ID. You need the session type ID of the appointment that the client wants to purchase a pass for.</li>
<li>Use the <a href="#get-services">GetServices</a> endpoint, which lists services based on the session type, to get a service ID. Use the session type ID from <strong>Step 3</strong> to find services that pay for that session type.</li>
<li><p>Use the <a href="#checkout-shopping-cart">CheckoutShoppingCart</a> endpoint to check out and purchase the service. You need to provide the service ID from <strong>Step 4</strong> and the client ID from your own application. You can set <code>Test</code> to <code>true</code> to test the request without affecting the database.</p><p>The <code>Amount</code> under <code>PaymentInfo</code> must match the shopping cart total for the payment to go through. We do not recommend calculating the total amount yourself. Instead, obtain the total for the entire cart first, and then use that as the total amount. For more information, see the <a href="#get-shopping-cart-total">Get Shopping Cart Total</a> tutorial.</p>
</ol>

<h4>Note</h4>
Protect yourself from processor fees and credit card fraud.  Remember to always protect your web forms that leverage <a href="#checkout-shopping-cart">POST CheckoutShoppingCart</a>, <a href="#purchase-contract">POST PurchaseContract</a> or <a href="#purchase-gift-card">POST PurchaseGiftCard</a> with a CAPTCHA!
