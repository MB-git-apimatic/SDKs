
# Mindbody Public Api Dto Models V6 Sale Controller Update Service Response

A response from the Update Services API method.

## Structure

`MindbodyPublicApiDtoModelsV6SaleControllerUpdateServiceResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `services` | [`List of MindbodyPublicApiDtoModelsV6Service`](../../doc/models/mindbody-public-api-dto-models-v6-service.md) | Optional | List of services as response |

## Example (as JSON)

```json
{
  "Services": null
}
```

