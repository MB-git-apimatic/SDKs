﻿<script type="text/javascript">
monitor('pagination');
</script>

> Example request using pagination parameters to skip the first 20 results and returning the next 10:

:::visible {language=http}
```
curl -X GET \
  'https://api.mindbodyonline.com/public/v6/class/classes?limit=10&offset=20' \
  -H 'Api-Key: {yourApiKey}' \
  -H 'authorization: {staffUserToken}' \
  -H 'SiteId: {yourSiteId}' \
  -A '{yourAppName}'
```
:::

:::visible {language=csharp}
```
var client = new RestClient("https://api.mindbodyonline.com/public/v6/class/classes?limit=10&offset=20");
var request = new RestRequest(Method.GET);
request.AddHeader("authorization", "{staffUserToken}");
request.AddHeader("SiteId", "{yourSiteId}");
request.AddHeader("Api-Key", "{yourApiKey}");
IRestResponse response = client.Execute(request);
```
:::

:::visible {language=php}
```
<?php

$request = new HttpRequest();
$request->setUrl('https://api.mindbodyonline.com/public/v6/class/classes');
$request->setMethod(HTTP_METH_GET);

$request->setQueryData(array(
  'limit' => '10',
  'offset' => '20'
));

$request->setHeaders(array(
  'authorization' => '{staffUserToken}',
  'SiteId' => '{yourSiteId}',
  'Api-Key' => '{yourApiKey}'
));

try {
  $response = $request->send();

  echo $response->getBody();
} catch (HttpException $ex) {
  echo $ex;
}
```
:::

:::visible {language=python}
```
import http.client

conn = http.client.HTTPSConnection("api.mindbodyonline.com")

headers = {
    'Api-Key': "{yourApiKey}",
    'SiteId': "{yourSiteId}",
    'authorization': "{staffUserToken}"
    }

conn.request("GET", "/public/v6/class/classes?limit=10&offset=20", headers=headers)

res = conn.getresponse()
data = res.read()

print(data.decode("utf-8"))
```
:::

:::visible {language=ruby}
```
require 'uri'
require 'net/http'

url = URI("https://api.mindbodyonline.com/public/v6/class/classes?limit=10&offset=20")

http = Net::HTTP.new(url.host, url.port)
http.use_ssl = true
http.verify_mode = OpenSSL::SSL::VERIFY_NONE

request = Net::HTTP::Get.new(url)
request["Api-Key"] = '{yourApiKey}'
request["SiteId"] = '{yourSiteId}'
request["authorization"] = '{staffUserToken}'

response = http.request(request)
puts response.read_body
```
:::

> Example pagination information returned in the response body:

```
{
    "PaginationResponse": {
        "RequestedLimit": 10,
        "RequestedOffset": 20,
        "PageSize": 10,
        "TotalResults": 128
    },
    "Classes": [
		. . .
    ]
}
```

Most of the Public API GET endpoints support paging to handle larger amounts of data. If you do not explicitly set a limit, your requests default to 100 results and no offset. The query parameters and response associated with pagination are described in the next two tables.  

#### Query Parameters
**Name** | **Type** | **Description**
--- | --- | ---
**Limit** | number | The number of results to include. <br>Default: **100**<br>Maximum: **200**
**Offset** |number | Specifies the number of records that you want the call to skip. The list of results is offset by this amount. <br>Default: **0**

#### Response
**Name** | **Type** | **Description**
--- | --- | ---
**RequestedLimit** | number | The requested pagination limit used in this response.
**RequestedOffset** | number | The number of records skipped over to reach the results returned in the response.
**PageSize** | number | The number of results returned in this response.
**TotalResults** | number | The total number of results in the dataset.
