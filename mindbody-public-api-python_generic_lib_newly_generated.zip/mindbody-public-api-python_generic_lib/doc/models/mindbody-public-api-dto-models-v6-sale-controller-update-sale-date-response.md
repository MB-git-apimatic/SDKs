
# Mindbody Public Api Dto Models V6 Sale Controller Update Sale Date Response

## Structure

`MindbodyPublicApiDtoModelsV6SaleControllerUpdateSaleDateResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `sale` | [`MindbodyPublicApiDtoModelsV6Sale`](../../doc/models/mindbody-public-api-dto-models-v6-sale.md) | Optional | - |

## Example (as JSON)

```json
{
  "Sale": null
}
```

