
# Mindbody Public Api Dto Models V6 Sale Controller Update Sale Date Response

## Structure

`MindbodyPublicApiDtoModelsV6SaleControllerUpdateSaleDateResponse`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `sale` | [`?MindbodyPublicApiDtoModelsV6Sale`](../../doc/models/mindbody-public-api-dto-models-v6-sale.md) | Optional | - | getSale(): ?MindbodyPublicApiDtoModelsV6Sale | setSale(?MindbodyPublicApiDtoModelsV6Sale sale): void |

## Example (as JSON)

```json
{
  "Sale": null
}
```

