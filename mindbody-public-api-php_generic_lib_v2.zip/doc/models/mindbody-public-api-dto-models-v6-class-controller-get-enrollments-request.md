
# Mindbody Public Api Dto Models V6 Class Controller Get Enrollments Request

## Structure

`MindbodyPublicApiDtoModelsV6ClassControllerGetEnrollmentsRequest`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `classScheduleIds` | `?(int[])` | Optional | A list of the requested class schedule IDs. If omitted, all class schedule IDs return. | getClassScheduleIds(): ?array | setClassScheduleIds(?array classScheduleIds): void |
| `endDate` | `?\DateTime` | Optional | The end of the date range. The response returns any active enrollments that occur on or before this day.<br /><br>Default: **StartDate** | getEndDate(): ?\DateTime | setEndDate(?\DateTime endDate): void |
| `locationIds` | `?(int[])` | Optional | List of the IDs for the requested locations. If omitted, all location IDs return. | getLocationIds(): ?array | setLocationIds(?array locationIds): void |
| `programIds` | `?(int[])` | Optional | List of the IDs for the requested programs. If omitted, all program IDs return. | getProgramIds(): ?array | setProgramIds(?array programIds): void |
| `sessionTypeIds` | `?(int[])` | Optional | List of the IDs for the requested session types. If omitted, all session types IDs return. | getSessionTypeIds(): ?array | setSessionTypeIds(?array sessionTypeIds): void |
| `staffIds` | `?(int[])` | Optional | List of the IDs for the requested staff IDs. If omitted, all staff IDs return. | getStaffIds(): ?array | setStaffIds(?array staffIds): void |
| `startDate` | `?\DateTime` | Optional | The start of the date range. The response returns any active enrollments that occur on or after this day.<br /><br>Default: **today’s date** | getStartDate(): ?\DateTime | setStartDate(?\DateTime startDate): void |
| `limit` | `?int` | Optional | Number of results to include, defaults to 100 | getLimit(): ?int | setLimit(?int limit): void |
| `offset` | `?int` | Optional | Page offset, defaults to 0. | getOffset(): ?int | setOffset(?int offset): void |

## Example (as JSON)

```json
{
  "ClassScheduleIds": null,
  "EndDate": null,
  "LocationIds": null,
  "ProgramIds": null,
  "SessionTypeIds": null,
  "StaffIds": null,
  "StartDate": null,
  "Limit": null,
  "Offset": null
}
```

