
# Mindbody Public Api Dto Models V6 Client Controller Get Client Formula Notes Response

## Structure

`MindbodyPublicApiDtoModelsV6ClientControllerGetClientFormulaNotesResponse`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `paginationResponse` | [`?MindbodyPublicApiDtoModelsV6PaginationResponse`](../../doc/models/mindbody-public-api-dto-models-v6-pagination-response.md) | Optional | - | getPaginationResponse(): ?MindbodyPublicApiDtoModelsV6PaginationResponse | setPaginationResponse(?MindbodyPublicApiDtoModelsV6PaginationResponse paginationResponse): void |
| `formulaNotes` | [`?(MindbodyPublicApiDtoModelsV6ClientControllerFormulaNoteResponse[])`](../../doc/models/mindbody-public-api-dto-models-v6-client-controller-formula-note-response.md) | Optional | Contains details about the client’s formula. | getFormulaNotes(): ?array | setFormulaNotes(?array formulaNotes): void |

## Example (as JSON)

```json
{
  "PaginationResponse": null,
  "FormulaNotes": null
}
```

