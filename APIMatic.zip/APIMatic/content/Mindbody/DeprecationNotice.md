﻿
Mindbody is deprecating all Public API version 5.x APIs to make way for more usable and maintainable alternatives in version 6.0. This offers improved standards, security, and ease of use to the API consumers. With more exciting changes to come, you can expect more thoughtful design and uniformity moving forward. 

With that in mind, as of **30th June 2024** the Public API version 5.0 and 5.1 will reach **end of life**. 

<h4 id="what-is-the-mindbody-public-application-programming-interface">What will happen if I do nothing?</h4>

Since the 5.0 and 5.1 APIs are going to be removed, any apps or services using 5.0 or 5.1 resources will not work. If you rely on a script, integration, or app that makes requests using 5.0 resources OR 5.1 resources, you will need to update it to use a 6.0 alternative as soon as possible. 

<h4 id="what-is-the-mindbody-public-application-programming-interface">Why are we deprecating?</h4>


**Improved Security [API key token combination]**

1. In V6.0 you do not need to use source credentials at all. It focuses on working with API-Key only for partner validation.
2. For user authentication, a token needs to be generated using user credentials.
3. Performing any modification to the data token is mandatory whereas getting requests is not mandatory.
4. Endpoints will provide you with a limited set of details, if no token has been passed with request, to keep the data from being exposed outside.
5. In any of these scenarios, API-key will be mandatory to verify the partners.

**Single Authentication mechanism [ Support for OAUTH 2.0]**

The Authentication for V6.0 API is token-based. As a caller, we need to ensure the token generation and send the token with the API request in the Authorization header. 
V6.0 APIs also support the OAuth 2.0 token.

**Better performance**

1. V6.0 REST API does not need much bandwidth when requests are sent to the server making it faster than V5 SOAP.
2. Efficient (SOAP uses XML for all messages, REST uses smaller message formats).
3. A reduced number of bulk operating APIs makes the V6.0 APIs lightweight and quick in request processing.
4. Redis caching is implemented wherever required to help with the fast processing of frequent requests. 

**Discontinued support provided by Microsoft for old framework**

Microsoft has discontinued support for the older frameworks and any framework issue cannot be resolved. Hence, upgrading to the latest technologies will help us with the continuous support from Microsoft.

**Ease of use**

1. To make the call to V6.0 APIs all we need is the token, API-Key, and Site ID.
2. No need to enter source credentials or user credentials as part of the API call every time.
3. JSON input format, for the request/response, makes it more readable and easier to work with.
4. No need to maintain any secondary action URL for the API call.
 

<h4 id="what-is-the-mindbody-public-application-programming-interface">Summary of Changes </h4>

There are some general changes across the APIs as mentioned below: 
<ol>
<li>V6.0 API authentication is done solely with a token generated from the IssueToken endpoint or with OAUTH 2.0. </li>
<li>For certain APIs like update service/products etc., we have restricted the bulk update count to 100, to improve the performance. This is to avoid the load on the APIs per call. </li>
<li>Segregation of the complex endpoint into logical separate endpoints makes it easier to consume these endpoints. The separation is done to reduce the burden on a single endpoint and to keep the concerns separate across endpoints while focusing on a single responsibility. </li>
<li>The single responsibility for a single endpoint improves the performance. V6.0 Rest API standards will work as below. </li>
</ol>
<ol>
For example:  
V5 SOAP AddOrUpdateAvailabilites were separated into 2 V6.0 REST endpoints.
<li>First will be the POST endpoint to add the availabilities.</li>
<li>The second will be the PUT endpoint updating the availabilities. </li>
</ol>

 
<h4 id="what-is-the-mindbody-public-application-programming-interface">Deprecated APIs and 6.0 alternatives</h4>

The endpoint request and response have no significant change when it comes to migrating to V6.0. The difference is in the endpoint URLs. 

Below is the category-wise list of endpoints that can be used while migrating to V6.0. 

<h4>Appointment </h4>

<a href='https://developers.mindbodyonline.com/PublicDocumentation/V6#appointment-endpoint'>https://developers.mindbodyonline.com/PublicDocumentation/V6#appointment-endpoint</a>.

**V5.X endpoint** | **Equivalent V6.0 endpoint**
--- | ---
/AppointmentService.asmx/GetActiveSessionTimes | <a href='https://developers.mindbodyonline.com/PublicDocumentation/V6#get-active-session-times'>/appointment/activesessiontimes</a>
Functionality missing | <a href='https://developers.mindbodyonline.com/PublicDocumentation/V6#get-appointment-add-ons'>/appointment/addons</a>
Functionality missing | <a href='https://developers.mindbodyonline.com/PublicDocumentation/V6#get-appointment-available-dates'>/appointment/availabledates</a>
/AppointmentService.asmx/GetAppointmentOptions | <a href='https://developers.mindbodyonline.com/PublicDocumentation/V6#get-appointment-options'>/appointment/appointmentoptions</a>
/AppointmentService.asmx/GetBookableItems | <a href='https://developers.mindbodyonline.com/PublicDocumentation/V6#get-bookable-items'>/appointment/bookableitems</a>
/AppointmentService.asmx/GetScheduleItems | <a href='https://developers.mindbodyonline.com/PublicDocumentation/V6#get-schedule-items'>/appointment/scheduleitems</a>
/AppointmentService.asmx/GetStaffAppointments | <a href='https://developers.mindbodyonline.com/PublicDocumentation/V6#get-staff-appointments'>/appointment/staffappointments</a>
/AppointmentService.asmx/AddOrUpdateAppointments | <a href='https://developers.mindbodyonline.com/PublicDocumentation/V6#add-appointment'>/appointment/addappointment</a>
/AppointmentService.asmx/AddOrUpdateAvailabilities | <a href='https://developers.mindbodyonline.com/PublicDocumentation/V6#add-availabilities'>/appointment/availabilities</a>
Functionality missing | <a href='https://developers.mindbodyonline.com/PublicDocumentation/V6#add-appointment-addon'>/appointment/addappointmentaddon</a> 
/AppointmentService.asmx/AddOrUpdateAppointments | <a href='https://developers.mindbodyonline.com/PublicDocumentation/V6#update-appointment'>/appointment/updateappointment</a>
/AppointmentService.asmx/AddOrUpdateAvailabilities | <a href='https://developers.mindbodyonline.com/PublicDocumentation/V6#update-availabilities'>/appointment/availabilities</a>
Functionality missing | <a href='https://developers.mindbodyonline.com/PublicDocumentation/V6#delete-appointment-addon'>/appointment/deleteappointmentaddon</a>
/AppointmentService.asmx/AddOrUpdateAvailabilities | <a href='https://developers.mindbodyonline.com/PublicDocumentation/V6#delete-contactlog'>/appointment/availabilities</a>


<h4>Class </h4>

<a href='https://developers.mindbodyonline.com/PublicDocumentation/V6#class-endpoint'>https://developers.mindbodyonline.com/PublicDocumentation/V6#class-endpoint</a>.

**V5.X endpoint** | **Equivalent V6.0 endpoint**
--- | ---
/ClassService.asmx/GetClasses | <a href='https://developers.mindbodyonline.com/PublicDocumentation/V6#get-classes'>/class/classes</a>
/ClassService.asmx/GetClassDescriptions | <a href='https://developers.mindbodyonline.com/PublicDocumentation/V6#get-class-descriptions'>/class/classdescriptions</a>
/ClassService.asmx/GetClassSchedules | <a href='https://developers.mindbodyonline.com/PublicDocumentation/V6#get-class-schedules'>/class/classschedules</a>
/ClassService.asmx/GetClassVisits | <a href='https://developers.mindbodyonline.com/PublicDocumentation/V6#get-class-visit'>/class/classvisits</a>
/ClassService.asmx/GetCourses | <a href='https://developers.mindbodyonline.com/PublicDocumentation/V6#get-courses'>/class/courses</a>
/ClassService.asmx/GetWaitlistEntries | <a href='https://developers.mindbodyonline.com/PublicDocumentation/V6#get-wait-list-entries'>/class/waitlistentries</a>
/ClassService.asmx/GetSemesters | <a href='https://developers.mindbodyonline.com/PublicDocumentation/V6#get-semesters'>/class/semesters</a>
/ClassService.asmx/AddClientToClass | <a href='https://developers.mindbodyonline.com/PublicDocumentation/V6#add-client-to-class'>/class/addclienttoclass</a>
/ClassService.asmx/RemoveClientsFromClasses | <a href='https://developers.mindbodyonline.com/PublicDocumentation/V6#remove-client-from-class'>/class/removeclientfromclass</a>
/ClassService.asmx/RemoveClientsFromClasses | <a href='https://developers.mindbodyonline.com/PublicDocumentation/V6#remove-clients-from-classes'>/class/removeclientsfromclass</a>
/ClassService.asmx/RemoveFromWaitlist | <a href='https://developers.mindbodyonline.com/PublicDocumentation/V6#remove-from-waitlist'>/class/removefromwaitlist</a>
/ClassService.asmx/SubstituteClassTeacher | <a href='https://developers.mindbodyonline.com/PublicDocumentation/V6#substitute-class-teacher'>/class/substituteclassteacher</a>
/ClassService.asmx/SubstituteClassTeacher | <a href ='https://developers.mindbodyonline.com/PublicDocumentation/V6#cancel-single-class'>/class/cancelsingleclass</a>


<h4>Clients</h4>

<a href='https://developers.mindbodyonline.com/PublicDocumentation/V6#client-endpoints'>https://developers.mindbodyonline.com/PublicDocumentation/V6#client-endpoints</a>.
 
**V5.X endpoint** | **Equivalent V6.0 endpoint**
--- | ---
/ClientService.asmx/GetActiveClientMemberships | <a href='https://developers.mindbodyonline.com/PublicDocumentation/V6#get-active-client-memberships'>/client/activeclientmemberships</a>
Functionality missing | <a href='https://developers.mindbodyonline.com/PublicDocumentation/V6#get-active-clients-memberships'>/client/activeclientsmemberships</a>
/ClientService.asmx/GetClientAccountBalances | <a href='https://developers.mindbodyonline.com/PublicDocumentation/V6#get-client-account-balances'>/client/clientaccountbalances</a>
/ClientService.asmx/GetClientContactLogs | <a href='https://developers.mindbodyonline.com/PublicDocumentation/V6#get-contact-logs'>/client/contactlogs</a>
/ClientService.asmx/GetClientContracts | <a href='https://developers.mindbodyonline.com/PublicDocumentation/V6#get-client-contracts'>/client/clientcontracts</a>
Functionality missing | <a href='https://developers.mindbodyonline.com/PublicDocumentation/V6#get-client-ddinfo'>/client/clientdirectdebitinfo</a>
Functionality missing | <a href='https://developers.mindbodyonline.com/PublicDocumentation/V6#get-client-duplicates'>/client/clientduplicates</a>
/ClientService.asmx/GetClientFormulaNotes | <a href='https://developers.mindbodyonline.com/PublicDocumentation/V6#client-formula-notes'>/client/clientformulanotes</a>
/ClientService.asmx/GetClientIndexes | <a href='https://developers.mindbodyonline.com/PublicDocumentation/V6#get-client-indexes'>/client/clientindexes</a>
/ClientService.asmx/GetClientPurchases | <a href='https://developers.mindbodyonline.com/PublicDocumentation/V6#get-client-purchases'>/client/clientpurchases</a>
/ClientService.asmx/GetClientReferralTypes | <a href='https://developers.mindbodyonline.com/PublicDocumentation/V6#get-client-referral-types'>/client/clientreferraltypes</a>
Functionality missing | <a href='https://developers.mindbodyonline.com/PublicDocumentation/V6#get-client-rewards'>/client/clientrewards</a>
/ClientService.asmx/GetClients | <a href='https://developers.mindbodyonline.com/PublicDocumentation/V6#get-clients'>/client/clients</a>
Functionality missing | <a href='https://developers.mindbodyonline.com/PublicDocumentation/V6#get-clientcompleteinfo'>/client/clientcompleteinfo</a>
/ClientService.asmx/GetClientServices | <a href='https://developers.mindbodyonline.com/PublicDocumentation/V6#get-client-services'>/client/clientservices</a>
/ClientService.asmx/GetClientVisits | <a href='https://developers.mindbodyonline.com/PublicDocumentation/V6#get-client-visits'>/client/clientvisits</a>
/ClientService.asmx/GetClientSchedule | <a href='https://developers.mindbodyonline.com/PublicDocumentation/V6#get-client-schedule'>/client/clientschedule</a>
/ClientService.asmx/GetCrossRegionalClientAssociations | <a href='https://developers.mindbodyonline.com/PublicDocumentation/V6#get-cross-regional-client-associations'>/client/crossregionalclientassociations</a>
/ClientService.asmx/GetCustomClientFields | <a href='https://developers.mindbodyonline.com/PublicDocumentation/V6#get-custom-client-fields'>/client/customclientfields</a>
/ClientService.asmx/GetRequiredClientFields | <a href='https://developers.mindbodyonline.com/PublicDocumentation/V6#get-required-client-fields'>/client/requiredclientfields</a>
/ClientService.asmx/GetContactLogTypes | <a href='https://developers.mindbodyonline.com/PublicDocumentation/V6#get-contactlogtypes'>/client/contactlogtypes</a>
/ClientService.asmx/AddOrUpdateClients | <a href='https://developers.mindbodyonline.com/PublicDocumentation/V6#add-client'>/client/addclient</a>
Functionality missing | <a href='https://developers.mindbodyonline.com/PublicDocumentation/V6#add-client-ddinfo'>/client/addclientdirectdebitinfo</a>
/ClientService.asmx/AddClientFormulaNote | <a href='https://developers.mindbodyonline.com/PublicDocumentation/V6#add-client-formula-note'>/client/addclientformulanote</a>
/ClientService.asmx/AddOrUpdateContactLogs | <a href='https://developers.mindbodyonline.com/PublicDocumentation/V6#add-contact-log'>/client/addcontactlog</a>
Functionality missing | <a href='https://developers.mindbodyonline.com/PublicDocumentation/V6#send-auto-email'>/client/sendautoemail</a>
/ClientService.asmx/SendUserNewPassword | <a href='https://developers.mindbodyonline.com/PublicDocumentation/V6#send-password-reset-email'>/client/sendpasswordresetemail</a>
/ClientService.asmx/AddOrUpdateClients | <a href='https://developers.mindbodyonline.com/PublicDocumentation/V6#update-client'>/client/updateclient</a>
Functionality missing | <a href='https://developers.mindbodyonline.com/PublicDocumentation/V6#update-client-rewards'>/client/clientrewards</a>
/ClientService.asmx/UpdateClientServices | <a href='https://developers.mindbodyonline.com/PublicDocumentation/V6#update-client-service'>/client/updateclientservice</a>
Functionality missing | <a href='https://developers.mindbodyonline.com/PublicDocumentation/V6#update-client-visit'>/client/updateclientvisit</a>
/ClientService.asmx/AddOrUpdateContactLogs | <a href='https://developers.mindbodyonline.com/PublicDocumentation/V6#update-contact-log'>/client/updatecontactlog</a>
/ClientService.asmx/UploadClientDocument | <a href='https://developers.mindbodyonline.com/PublicDocumentation/V6#upload-client-document'>/client/uploadclientdocument</a>
/ClientService.asmx/UploadClientPhoto | <a href='https://developers.mindbodyonline.com/PublicDocumentation/V6#upload-client-photo'>/client/uploadclientphoto</a>
Functionality missing | <a href='https://developers.mindbodyonline.com/PublicDocumentation/V6#delete-client-ddinfo'>/client/clientdirectdebitinfo</a>
Functionality missing | <a href='https://developers.mindbodyonline.com/PublicDocumentation/V6#delete-contactlog'>/client/deletecontactlog</a>
/ClientService.asmx/DeleteClientFormulaNote | <a href='https://developers.mindbodyonline.com/PublicDocumentation/V6#delete-client-formula-note'>/client/clientformulanote</a>


<h4>Enrollment</h4>

<a href='https://developers.mindbodyonline.com/PublicDocumentation/V6#enrollments-endpoint'>https://developers.mindbodyonline.com/PublicDocumentation/V6#enrollments-endpoint</a>.
 
**V5.X endpoint** | **Equivalent V6.0 endpoint**
--- | ---
/ClassService.asmx/GetEnrollments | <a href='https://developers.mindbodyonline.com/PublicDocumentation/V6#get-enrollments'>/enrollment/enrollments</a>
/ClassService.asmx/AddClientsToEnrollments | <a href='https://developers.mindbodyonline.com/PublicDocumentation/V6#add-client-to-enrollment'>/enrollment/addclienttoenrollment</a>


<h4>Payroll</h4>

<a href='https://developers.mindbodyonline.com/PublicDocumentation/V6#payroll-endpoint'>https://developers.mindbodyonline.com/PublicDocumentation/V6#payroll-endpoint</a>.
 
**V5.X endpoint** | **Equivalent V6.0 endpoint**
--- | ---
Functionality missing | <a href='https://developers.mindbodyonline.com/PublicDocumentation/V6#get-commissions'>/payroll/commissions</a>
Functionality missing | <a href='https://developers.mindbodyonline.com/PublicDocumentation/V6#get-scheduled-service-earnings'>/payroll/scheduledserviceearnings</a>
Functionality missing | <a href='https://developers.mindbodyonline.com/PublicDocumentation/V6#get-time-cards'>/payroll/timecards</a>
Functionality missing | <a href='https://developers.mindbodyonline.com/PublicDocumentation/V6#get-tipshttps://developers.mindbodyonline.com/PublicDocumentation/V6#get-accepted-card-types'>/payroll/tips</a>


<h4>Sale</h4>

<a href='https://developers.mindbodyonline.com/PublicDocumentation/V6#sale-endpoint'>https://developers.mindbodyonline.com/PublicDocumentation/V6#sale-endpoint</a>.
 
**V5.X endpoint** | **Equivalent V6.0 endpoint**
--- | ---
/SaleService.asmx/GetAcceptedCardType | <a href='https://developers.mindbodyonline.com/PublicDocumentation/V6#get-accepted-card-types'>/sale/acceptedcardtypes</a>
/SaleService.asmx/GetContracts | <a href='https://developers.mindbodyonline.com/PublicDocumentation/V6#get-contracts'>/sale/contracts</a>
/SaleService.asmx/GetCustomPaymentMethods | <a href='https://developers.mindbodyonline.com/PublicDocumentation/V6#get-custom-payment-methods'>/sale/custompaymentmethods</a>
Functionality missing | <a href='https://developers.mindbodyonline.com/PublicDocumentation/V6#get-gift-card-balance'>/sale/giftcardbalance</a>
Functionality missing | <a href='https://developers.mindbodyonline.com/PublicDocumentation/V6#get-gift-cards'>/sale/giftcards</a>
/SaleService.asmx/GetPackages | <a href='https://developers.mindbodyonline.com/PublicDocumentation/V6#get-packages'>/sale/packages</a>
/SaleService.asmx/GetProducts | <a href='https://developers.mindbodyonline.com/PublicDocumentation/V6#get-products'>/sale/products</a>
Functionality missing | <a href='https://developers.mindbodyonline.com/PublicDocumentation/V6#get-products-inventory'>/sale/productsinventory</a>
/SaleService.asmx/GetSales | <a href='https://developers.mindbodyonline.com/PublicDocumentation/V6#get-sales'>/sale/sales</a>
/SaleService.asmx/GetServices | <a href='https://developers.mindbodyonline.com/PublicDocumentation/V6#get-services'>/sale/services</a>
Functionality missing | <a href='https://developers.mindbodyonline.com/PublicDocumentation/V6#get-transactions'>/sale/transactions</a>
/SaleService.asmx/CheckoutShoppingCart  | <a href='https://developers.mindbodyonline.com/PublicDocumentation/V6#checkout-shopping-cart'>/sale/checkoutshoppingcart</a>
Functionality missing | <a href='https://developers.mindbodyonline.com/PublicDocumentation/V6#purchase-account-credit'>/sale/purchaseaccountcredit</a>
/SaleService.asmx/PurchaseContracts  | <a href='https://developers.mindbodyonline.com/PublicDocumentation/V6#purchase-contract'>/sale/purchasecontract</a>
Functionality missing | <a href='https://developers.mindbodyonline.com/PublicDocumentation/V6#purchase-gift-card'>/sale/purchasegiftcard</a>
/SaleService.asmx/UpdateProducts | <a href='https://developers.mindbodyonline.com/PublicDocumentation/V6#update-product-price'>/sale/updateproductprice</a>
/SaleService.asmx/ReturnSale | <a href='https://developers.mindbodyonline.com/PublicDocumentation/V6#post-return-sale'>/sale/returnsale</a>
/SaleService.asmx/UpdateProducts | <a href='https://developers.mindbodyonline.com/PublicDocumentation/V6#update-products'>/sale/products</a>
/SaleService.asmx/UpdateServices | <a href='https://developers.mindbodyonline.com/PublicDocumentation/V6#update-services'>/sale/services</a>
/SaleService.asmx/UpdateSaleDate | <a href='https://developers.mindbodyonline.com/PublicDocumentation/V6#update-sale-date'>/sale/updatesaledate</a>


<h4>Site</h4>

<a href='https://developers.mindbodyonline.com/PublicDocumentation/V6#site-endpoint'>https://developers.mindbodyonline.com/PublicDocumentation/V6#site-endpoint</a>.
 
**V5.X endpoint** | **Equivalent V6.0 endpoint**
--- | ---
/SiteService.asmx/GetActivationCode | <a href='https://developers.mindbodyonline.com/PublicDocumentation/V6#get-activation-code'>/site/activationcode</a>
/SiteService.asmx/GetGenders | <a href='https://developers.mindbodyonline.com/PublicDocumentation/V6#get-genders'>/site/genders</a>
/SiteService.asmx/GetLocations | <a href='https://developers.mindbodyonline.com/PublicDocumentation/V6#get-locations'>/site/locations</a>
Functionality missing | <a href='https://developers.mindbodyonline.com/PublicDocumentation/V6#get-memberships'>/site/memberships</a>
/SiteService.asmx/GetPrograms | <a href='https://developers.mindbodyonline.com/PublicDocumentation/V6#get-programs'>/site/programs</a>
Functionality missing | <a href='https://developers.mindbodyonline.com/PublicDocumentation/V6#get-promocodes'>/site/promocodes</a>
/SiteService.asmx/GetResources | <a href='https://developers.mindbodyonline.com/PublicDocumentation/V6#get-resources'>/site/resources</a>
/SiteService.asmx/GetSessionTypes | <a href='https://developers.mindbodyonline.com/PublicDocumentation/V6#get-session-types'>/site/sessiontypes</a>
/SiteService.asmx/GetSites | <a href='https://developers.mindbodyonline.com/PublicDocumentation/V6#get-sites'>/site/sites</a>
Functionality missing | <a href='https://developers.mindbodyonline.com/PublicDocumentation/V6#get-categories'>/site/categories</a>
Functionality missing | <a href='https://developers.mindbodyonline.com/PublicDocumentation/V6#get-paymenttypes'>/site/paymenttypes</a>
/SiteService.asmx/GetRelationships | <a href='https://developers.mindbodyonline.com/PublicDocumentation/V6#get-relationships'>/site/relationships</a>
/SiteService.asmx/GetMobileProviders | <a href='https://developers.mindbodyonline.com/PublicDocumentation/V6#get-mobile-providers'>/site/mobileproviders</a>
/SiteService.asmx/GetProspectStages | <a href='https://developers.mindbodyonline.com/PublicDocumentation/V6#get-prospect-stages'>/site/prospectstages</a>
Functionality missing | <a href='https://developers.mindbodyonline.com/PublicDocumentation/V6#add-promocode'>/site/addpromocode</a>

 
<h4>Staff</h4>

<a href='https://developers.mindbodyonline.com/PublicDocumentation/V6#staff-endpoint'>https://developers.mindbodyonline.com/PublicDocumentation/V6#staff-endpoint</a>.
 
**V5.X endpoint** | **Equivalent V6.0 endpoint**
--- | ---
/StaffService.asmx/GetStaff | <a href='https://developers.mindbodyonline.com/PublicDocumentation/V6#get-staff'>/staff/staff</a>
/StaffService.asmx/GetStaffPermissions | <a href='https://developers.mindbodyonline.com/PublicDocumentation/V6#get-staff-permissions'>/staff/staffpermissions</a>
/StaffService.asmx/GetStaffImgURL | <a href='https://developers.mindbodyonline.com/PublicDocumentation/V6#get-staff-image-url'>/staff/imageurl</a>
Functionality missing | <a href='https://developers.mindbodyonline.com/PublicDocumentation/V6#get-staff-session-types'>/staff/sessiontypes</a>
/StaffService.asmx/GetSalesReps | <a href='https://developers.mindbodyonline.com/PublicDocumentation/V6#get-sales-reps'>/staff/salesreps</a>
/StaffService.asmx/AddOrUpdateStaff | <a href='https://developers.mindbodyonline.com/PublicDocumentation/V6#add-staff'>/staff/addstaff</a>
Functionality missing | <a href='https://developers.mindbodyonline.com/PublicDocumentation/V6#add-staff-availability'>/staff/staffavailability</a>
Functionality missing | <a href='https://developers.mindbodyonline.com/PublicDocumentation/V6#assign-staff-session-type'>/staff/assignsessiontype</a>
Functionality missing | <a href='https://developers.mindbodyonline.com/PublicDocumentation/V6#update-staff'>/staff/updatestaffpermissions</a>
/StaffService.asmx/AddOrUpdateStaff | <a href='https://developers.mindbodyonline.com/PublicDocumentation/V6#update-staff-permissions'>/staff/updatestaff</a>

<h4 id="what-is-the-mindbody-public-application-programming-interface">Authentication changes</h4> 

We have all the details related to authentication mentioned in the developer portal. Request you to look at the same under the public API. 

<a href='https://developers.mindbodyonline.com/PublicDocumentation/V6#authentication'>https://developers.mindbodyonline.com/PublicDocumentation/V6#authentication</a>.
 
  