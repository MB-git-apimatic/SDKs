
# Mindbody Public Api Common Models Category

## Structure

`MindbodyPublicApiCommonModelsCategory`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `id` | `?int` | Optional | - | getId(): ?int | setId(?int id): void |
| `categoryName` | `?string` | Optional | - | getCategoryName(): ?string | setCategoryName(?string categoryName): void |
| `description` | `?string` | Optional | - | getDescription(): ?string | setDescription(?string description): void |
| `service` | `?bool` | Optional | - | getService(): ?bool | setService(?bool service): void |
| `active` | `?bool` | Optional | - | getActive(): ?bool | setActive(?bool active): void |
| `isPrimary` | `?bool` | Optional | - | getIsPrimary(): ?bool | setIsPrimary(?bool isPrimary): void |
| `isSecondary` | `?bool` | Optional | - | getIsSecondary(): ?bool | setIsSecondary(?bool isSecondary): void |
| `createdDateTimeUTC` | `?\DateTime` | Optional | - | getCreatedDateTimeUTC(): ?\DateTime | setCreatedDateTimeUTC(?\DateTime createdDateTimeUTC): void |
| `modifiedDateTimeUTC` | `?\DateTime` | Optional | - | getModifiedDateTimeUTC(): ?\DateTime | setModifiedDateTimeUTC(?\DateTime modifiedDateTimeUTC): void |
| `subCategories` | [`?(MindbodyPublicApiCommonModelsSubCategory[])`](../../doc/models/mindbody-public-api-common-models-sub-category.md) | Optional | - | getSubCategories(): ?array | setSubCategories(?array subCategories): void |
| `totalCount` | `?int` | Optional | - | getTotalCount(): ?int | setTotalCount(?int totalCount): void |

## Example (as JSON)

```json
{
  "Id": null,
  "CategoryName": null,
  "Description": null,
  "Service": null,
  "Active": null,
  "IsPrimary": null,
  "IsSecondary": null,
  "CreatedDateTimeUTC": null,
  "ModifiedDateTimeUTC": null,
  "SubCategories": null,
  "TotalCount": null
}
```

