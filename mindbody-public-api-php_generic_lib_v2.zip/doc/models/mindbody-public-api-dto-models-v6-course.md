
# Mindbody Public Api Dto Models V6 Course

A course.

## Structure

`MindbodyPublicApiDtoModelsV6Course`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `id` | `?int` | Optional | The course ID. | getId(): ?int | setId(?int id): void |
| `name` | `?string` | Optional | The course name. | getName(): ?string | setName(?string name): void |
| `description` | `?string` | Optional | A description of the course. | getDescription(): ?string | setDescription(?string description): void |
| `notes` | `?string` | Optional | Any notes that have been written about the course. | getNotes(): ?string | setNotes(?string notes): void |
| `startDate` | `?\DateTime` | Optional | Date and time that the course starts. | getStartDate(): ?\DateTime | setStartDate(?\DateTime startDate): void |
| `endDate` | `?\DateTime` | Optional | Date and time that the course ends. | getEndDate(): ?\DateTime | setEndDate(?\DateTime endDate): void |
| `location` | [`?MindbodyPublicApiDtoModelsV6Location`](../../doc/models/mindbody-public-api-dto-models-v6-location.md) | Optional | - | getLocation(): ?MindbodyPublicApiDtoModelsV6Location | setLocation(?MindbodyPublicApiDtoModelsV6Location location): void |
| `organizer` | [`?MindbodyPublicApiDtoModelsV6Staff`](../../doc/models/mindbody-public-api-dto-models-v6-staff.md) | Optional | - | getOrganizer(): ?MindbodyPublicApiDtoModelsV6Staff | setOrganizer(?MindbodyPublicApiDtoModelsV6Staff organizer): void |
| `program` | [`?MindbodyPublicApiDtoModelsV6Program`](../../doc/models/mindbody-public-api-dto-models-v6-program.md) | Optional | - | getProgram(): ?MindbodyPublicApiDtoModelsV6Program | setProgram(?MindbodyPublicApiDtoModelsV6Program program): void |
| `imageUrl` | `?string` | Optional | The URL of the image associated with this course, if one exists. | getImageUrl(): ?string | setImageUrl(?string imageUrl): void |

## Example (as JSON)

```json
{
  "Id": null,
  "Name": null,
  "Description": null,
  "Notes": null,
  "StartDate": null,
  "EndDate": null,
  "Location": null,
  "Organizer": null,
  "Program": null,
  "ImageUrl": null
}
```

