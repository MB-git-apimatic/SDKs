# Enrollment

```python
enrollment_controller = client.enrollment
```

## Class Name

`EnrollmentController`

## Methods

* [Enrollment Add Client to Enrollment](../../doc/controllers/enrollment.md#enrollment-add-client-to-enrollment)
* [Enrollment Get Enrollments](../../doc/controllers/enrollment.md#enrollment-get-enrollments)
* [Enrollment Add Enrollment Schedule](../../doc/controllers/enrollment.md#enrollment-add-enrollment-schedule)
* [Enrollment Update Enrollment Schedule](../../doc/controllers/enrollment.md#enrollment-update-enrollment-schedule)


# Enrollment Add Client to Enrollment

Book a client into an enrollment.

```python
def enrollment_add_client_to_enrollment(self,
                                       request,
                                       site_id,
                                       version,
                                       authorization=None)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `request` | [`MindbodyPublicApiDtoModelsV6ClassControllerAddClientToEnrollmentRequest`](../../doc/models/mindbody-public-api-dto-models-v6-class-controller-add-client-to-enrollment-request.md) | Body, Required | - |
| `site_id` | `string` | Header, Required | ID of the site from which to pull data. |
| `version` | `string` | Template, Required | - |
| `authorization` | `string` | Header, Optional | A staff user authorization token. |

## Response Type

[`MindbodyPublicApiDtoModelsV6ClassSchedule`](../../doc/models/mindbody-public-api-dto-models-v6-class-schedule.md)

## Example Usage

```python
request = MindbodyPublicApiDtoModelsV6ClassControllerAddClientToEnrollmentRequest()
request.client_id = 'ClientId0'
request.class_schedule_id = 36
site_id = '-99'
version = 'version4'

result = enrollment_controller.enrollment_add_client_to_enrollment(request, site_id, version)
```


# Enrollment Get Enrollments

Returns a list of enrollments. An enrollment is a service, such as a workshop or an event, that a staff member offers to multiple students, who commit to coming to all or most of the scheduled sessions. Enrollments typically run for a limited time only.

When a user token is not passed with the request or the passed user token has insufficient viewing permissions, only the following staff data is returned in the response:

* FirstName
* LastName
* Id
* Bio
* DisplayName
* ImageUrl

```python
def enrollment_get_enrollments(self,
                              site_id,
                              version,
                              authorization=None,
                              request_class_schedule_ids=None,
                              request_end_date=None,
                              request_limit=None,
                              request_location_ids=None,
                              request_offset=None,
                              request_program_ids=None,
                              request_session_type_ids=None,
                              request_staff_ids=None,
                              request_start_date=None)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `site_id` | `string` | Header, Required | ID of the site from which to pull data. |
| `version` | `string` | Template, Required | - |
| `authorization` | `string` | Header, Optional | A staff user authorization token. |
| `request_class_schedule_ids` | `List of int` | Query, Optional | A list of the requested class schedule IDs. If omitted, all class schedule IDs return. |
| `request_end_date` | `datetime` | Query, Optional | The end of the date range. The response returns any active enrollments that occur on or before this day.<br /><br>Default: **StartDate** |
| `request_limit` | `int` | Query, Optional | Number of results to include, defaults to 100 |
| `request_location_ids` | `List of int` | Query, Optional | List of the IDs for the requested locations. If omitted, all location IDs return. |
| `request_offset` | `int` | Query, Optional | Page offset, defaults to 0. |
| `request_program_ids` | `List of int` | Query, Optional | List of the IDs for the requested programs. If omitted, all program IDs return. |
| `request_session_type_ids` | `List of int` | Query, Optional | List of the IDs for the requested session types. If omitted, all session types IDs return. |
| `request_staff_ids` | `List of long\|int` | Query, Optional | List of the IDs for the requested staff IDs. If omitted, all staff IDs return. |
| `request_start_date` | `datetime` | Query, Optional | The start of the date range. The response returns any active enrollments that occur on or after this day.<br /><br>Default: **today’s date** |

## Response Type

[`MindbodyPublicApiDtoModelsV6ClassControllerGetEnrollmentsResponse`](../../doc/models/mindbody-public-api-dto-models-v6-class-controller-get-enrollments-response.md)

## Example Usage

```python
site_id = '-99'
version = 'version4'

result = enrollment_controller.enrollment_get_enrollments(site_id, version)
```


# Enrollment Add Enrollment Schedule

```python
def enrollment_add_enrollment_schedule(self,
                                      request,
                                      site_id,
                                      version,
                                      authorization=None)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `request` | [`MindbodyPublicApiDtoModelsV6AddClassEnrollmentScheduleRequest`](../../doc/models/mindbody-public-api-dto-models-v6-add-class-enrollment-schedule-request.md) | Body, Required | - |
| `site_id` | `string` | Header, Required | ID of the site from which to pull data. |
| `version` | `string` | Template, Required | - |
| `authorization` | `string` | Header, Optional | A staff user authorization token. |

## Response Type

`object`

## Example Usage

```python
request = MindbodyPublicApiDtoModelsV6AddClassEnrollmentScheduleRequest()
site_id = '-99'
version = 'version4'

result = enrollment_controller.enrollment_add_enrollment_schedule(request, site_id, version)
```


# Enrollment Update Enrollment Schedule

```python
def enrollment_update_enrollment_schedule(self,
                                         request,
                                         site_id,
                                         version,
                                         authorization=None)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `request` | [`MindbodyPublicApiDtoModelsV6UpdateClassEnrollmentScheduleRequest`](../../doc/models/mindbody-public-api-dto-models-v6-update-class-enrollment-schedule-request.md) | Body, Required | - |
| `site_id` | `string` | Header, Required | ID of the site from which to pull data. |
| `version` | `string` | Template, Required | - |
| `authorization` | `string` | Header, Optional | A staff user authorization token. |

## Response Type

`object`

## Example Usage

```python
request = MindbodyPublicApiDtoModelsV6UpdateClassEnrollmentScheduleRequest()
site_id = '-99'
version = 'version4'

result = enrollment_controller.enrollment_update_enrollment_schedule(request, site_id, version)
```

