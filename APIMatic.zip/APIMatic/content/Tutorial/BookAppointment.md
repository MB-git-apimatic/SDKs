﻿<script type="text/javascript">
monitor('book-an-appointment');
</script>

> Step 2: Get the locations

:::visible {language=http}
```shell
curl -X GET \
  https://api.mindbodyonline.com/public/v6/site/locations \
  -H 'Api-Key: {yourApiKey}' \
  -H 'SiteId: {yourSiteId}' \
  -A '{yourAppName}'
```
:::

:::visible {language=csharp}
```
var client = new RestClient("https://api.mindbodyonline.com/public/v6/site/locations");
var request = new RestRequest(Method.GET);
request.AddHeader("SiteId", "{yourSiteId}");
request.AddHeader("Api-Key", "{yourApiKey}");
IRestResponse response = client.Execute(request);
```
:::

:::visible {language=php}
```
<?php

$request = new HttpRequest();
$request->setUrl('https://api.mindbodyonline.com/public/v6/site/locations');
$request->setMethod(HTTP_METH_GET);

$request->setHeaders(array(
  'SiteId' => '{yourSiteId}',
  'Api-Key' => '{yourApiKey}'
));

try {
  $response = $request->send();

  echo $response->getBody();
} catch (HttpException $ex) {
  echo $ex;
}
```
:::

:::visible {language=python}
```
import http.client

conn = http.client.HTTPSConnection("api.mindbodyonline.com")

headers = {
	'Api-Key': "{yourApiKey}",
    'SiteId': "{yourSiteId}"
    }

conn.request("GET", "public/v6/site/locations", headers=headers)

res = conn.getresponse()
data = res.read()

print(data.decode("utf-8"))
```
:::

:::visible {language=ruby}
```
require 'uri'
require 'net/http'

url = URI("https://api.mindbodyonline.com/public/v6/site/locations")

http = Net::HTTP.new(url.host, url.port)

request = Net::HTTP::Get.new(url)
request["Api-Key"] = '{yourApiKey}'
request["SiteId"] = '{yourSiteId}'

response = http.request(request)
puts response.read_body
```
:::
> Step 3: Get the session types

:::visible {language=http}
```
curl -X GET \
  https://api.mindbodyonline.com/public/v6/site/sessiontypes \
  -H 'Api-Key: {yourApiKey}' \
  -H 'SiteId: {yourSiteId}' \
  -A '{yourAppName}'
```
:::

:::visible {language=csharp}
```
var client = new RestClient("https://api.mindbodyonline.com/public/v6/site/sessiontypes");
var request = new RestRequest(Method.GET);
request.AddHeader("SiteId", "{yourSiteId}");
request.AddHeader("Api-Key", "{yourApiKey}");
IRestResponse response = client.Execute(request);
```
:::

:::visible {language=php}
```
<?php

$request = new HttpRequest();
$request->setUrl('https://api.mindbodyonline.com/public/v6/site/sessiontypes');
$request->setMethod(HTTP_METH_GET);

$request->setHeaders(array(
  'SiteId' => '{yourSiteId}',
  'Api-Key' => '{yourApiKey}'
));

try {
  $response = $request->send();

  echo $response->getBody();
} catch (HttpException $ex) {
  echo $ex;
}
```
:::

:::visible {language=python}
```
import http.client

conn = http.client.HTTPSConnection("api.mindbodyonline.com")

headers = {
	'Api-Key': "{yourApiKey}",
    'SiteId': "{yourSiteId}"
    }

conn.request("GET", "public/v6/site/sessiontypes", headers=headers)

res = conn.getresponse()
data = res.read()

print(data.decode("utf-8"))
```
:::

:::visible {language=ruby}
```
require 'uri'
require 'net/http'

url = URI("https://api.mindbodyonline.com/public/v6/site/sessiontypes")

http = Net::HTTP.new(url.host, url.port)

request = Net::HTTP::Get.new(url)
request["Api-Key"] = '{yourApiKey}'
request["SiteId"] = '{yourSiteId}'

response = http.request(request)
puts response.read_body
```
:::
> Step 4: Get the bookable items

:::visible {language=http}
```
curl -X GET \
  'https://api.mindbodyonline.com/public/v6/appointment/bookableitems?sessionTypeIds=2&locationIds=1' \
  -H 'Api-Key: {yourApiKey}' \
  -H 'Authorization: {staffAuthToken}' \
  -H 'SiteId: {yourSiteId}' \
  -A '{yourAppName}'
```
:::

:::visible {language=csharp}
```
var client = new RestClient("https://api.mindbodyonline.com/public/v6/appointment/bookableitems?sessionTypeIds=2&locationIds=1");
var request = new RestRequest(Method.GET);
request.AddHeader("Authorization", "{staffAuthToken}");
request.AddHeader("SiteId", "{yourSiteId}");
request.AddHeader("Api-Key", "{yourApiKey}");
IRestResponse response = client.Execute(request);
```
:::

:::visible {language=php}
```
<?php

$request = new HttpRequest();
$request->setUrl('https://api.mindbodyonline.com/public/v6/appointment/bookableitems');
$request->setMethod(HTTP_METH_GET);

$request->setQueryData(array(
  'sessionTypeIds' => '2',
  'locationIds' => '1'
));

$request->setHeaders(array(
  'Authorization' => '{staffAuthToken}',
  'SiteId' => '{yourSiteId}',
  'Api-Key' => '{yourApiKey}'
));

try {
  $response = $request->send();

  echo $response->getBody();
} catch (HttpException $ex) {
  echo $ex;
}
```
:::

:::visible {language=python}
```
import http.client

conn = http.client.HTTPSConnection("api.mindbodyonline.com")

headers = {
	'Api-Key': "{yourApiKey}",
    'SiteId': "{yourSiteId}",
    'Authorization': "{staffAuthToken}"
    }

conn.request("GET", "public/v6/appointment/bookableitems", headers=headers)

res = conn.getresponse()
data = res.read()

print(data.decode("utf-8"))
```
:::

:::visible {language=ruby}
```
require 'uri'
require 'net/http'

url = URI("https://api.mindbodyonline.com/public/v6/appointment/bookableitems?sessionTypeIds=2&locationIds=1")

http = Net::HTTP.new(url.host, url.port)

request = Net::HTTP::Get.new(url)
request["Api-Key"] = '{yourApiKey}'
request["SiteId"] = '{yourSiteId}'
request["Authorization"] = '{staffAuthToken}'

response = http.request(request)
puts response.read_body
```
:::
> Step 5: Get the client services

:::visible {language=http}
```
curl -X GET \
  'https://api.mindbodyonline.com/public/v6/client/clientservices?clientId=100000527&sessionTypeIds=2' \
  -H 'Api-Key: {yourApiKey}' \
  -H 'SiteId: {yourSiteId}' \
  -A '{yourAppName}'
```
:::

:::visible {language=csharp}
```csharp
var client = new RestClient("https://api.mindbodyonline.com/public/v6/client/clientservices?clientId=100000527&sessionTypeIds=2");
var request = new RestRequest(Method.GET);
request.AddHeader("SiteId", "{yourSiteId}");
request.AddHeader("Api-Key", "{yourApiKey}");
IRestResponse response = client.Execute(request);
```
:::

:::visible {language=php}
```
<?php

$request = new HttpRequest();
$request->setUrl('https://api.mindbodyonline.com/public/v6/client/clientservices');
$request->setMethod(HTTP_METH_GET);

$request->setQueryData(array(
  'clientId' => '100000527',
  'sessionTypeIds' => '2'
));

$request->setHeaders(array(
  'SiteId' => '{yourSiteId}',
  'Api-Key' => '{yourApiKey}'
));

try {
  $response = $request->send();

  echo $response->getBody();
} catch (HttpException $ex) {
  echo $ex;
}
```
:::

:::visible {language=python}
```
import http.client

conn = http.client.HTTPSConnection("api.mindbodyonline.com")

headers = {
	'Api-Key': "{yourApiKey}",
    'SiteId': "{yourSiteId}"
    }

conn.request("GET", "public/v6/client/clientservices", headers=headers)

res = conn.getresponse()
data = res.read()

print(data.decode("utf-8"))
```
:::

:::visible {language=ruby}
```
require 'uri'
require 'net/http'

url = URI("https://api.mindbodyonline.com/public/v6/client/clientservices?clientId=100000527&sessionTypeIds=2")

http = Net::HTTP.new(url.host, url.port)
request = Net::HTTP::Get.new(url)
request["Api-Key"] = '{yourApiKey}'
request["SiteId"] = '{yourSiteId}'

response = http.request(request)
puts response.read_body
```
:::
> Step 6: Add the appointment

:::visible {language=http}
```
curl -X POST \
  https://api.mindbodyonline.com/public/v6/appointment/addappointment \
  -H 'Api-Key: {yourApiKey}' \
  -H 'Content-Type: application/json' \
  -H 'Authorization: {staffAuthToken}' \
  -H 'SiteId: {yourSiteId}' \
  -A '{yourAppName}' \
  -d '{
	"StartDateTime": "2018-10-16T15:00:00",
	"LocationId": 1,
	"StaffId": 22,
	"ClientId": "100000934",
	"SessionTypeId": 2,
	"ClientServiceId": 86602,
	"ApplyPayment": true,
	"IgnoreDefaultSessionLength": false,
	"SendEmail": false,
	"Test": false
}'
```
:::

:::visible {language=csharp}
```
var client = new RestClient("https://api.mindbodyonline.com/public/v6/appointment/addappointment");
var request = new RestRequest(Method.POST);
request.AddHeader("Authorization", "{staffAuthToken}");
request.AddHeader("SiteId", "{yourSiteId}");
request.AddHeader("Api-Key", "{yourApiKey}");
request.AddParameter("application/json", "{\r\n\t\"StartDateTime\": \"2018-10-16T15:00:00\",\r\n\t\"LocationId\": 1,\r\n\t\"StaffId\": 22,\r\n\t\"ClientId\": \"100000934\",\r\n\t\"SessionTypeId\": 2,\r\n\t\"ClientServiceId\": 86602,\r\n\t\"ApplyPayment\": true,\r\n\t\"IgnoreDefaultSessionLength\": false,\r\n\t\"SendEmail\": false,\r\n\t\"Test\": false\r\n}\r\n", ParameterType.RequestBody);
IRestResponse response = client.Execute(request);
```
:::

:::visible {language=php}
```
<?php

$request = new HttpRequest();
$request->setUrl('https://api.mindbodyonline.com/public/v6/appointment/addappointment');
$request->setMethod(HTTP_METH_POST);

$request->setHeaders(array(
  'Authorization' => '{staffAuthToken}',
  'Content-Type' => 'application/json',
  'SiteId' => '{yourSiteId}',
  'Api-Key' => '{yourApiKey}'
));

$request->setBody('{
	"StartDateTime": "2018-10-16T15:00:00",
	"LocationId": 1,
	"StaffId": 22,
	"ClientId": "100000934",
	"SessionTypeId": 2,
	"ClientServiceId": 86602,
	"ApplyPayment": true,
	"IgnoreDefaultSessionLength": false,
	"SendEmail": false,
	"Test": false
}
');

try {
  $response = $request->send();

  echo $response->getBody();
} catch (HttpException $ex) {
  echo $ex;
}
```
:::

:::visible {language=python}
```
import http.client

conn = http.client.HTTPSConnection("api.mindbodyonline.com")

payload = "{\r\n\t\"StartDateTime\": \"2018-10-16T15:00:00\",\r\n\t\"LocationId\": 1,\r\n\t\"StaffId\": 22,\r\n\t\"ClientId\": \"100000934\",\r\n\t\"SessionTypeId\": 2,\r\n\t\"ClientServiceId\": 86602,\r\n\t\"ApplyPayment\": true,\r\n\t\"IgnoreDefaultSessionLength\": false,\r\n\t\"SendEmail\": false,\r\n\t\"Test\": false\r\n}\r\n"

headers = {
    'Content-Type': "application/json",
	'Api-Key': "{yourApiKey}",
    'SiteId': "{yourSiteId}",
    'Authorization': "{staffAuthToken}"
    }

conn.request("POST", "public/v6/appointment/addappointment", payload, headers)

res = conn.getresponse()
data = res.read()

print(data.decode("utf-8"))
```
:::

:::visible {language=ruby}
```
require 'uri'
require 'net/http'

url = URI("https://api.mindbodyonline.com/public/v6/appointment/addappointment")

http = Net::HTTP.new(url.host, url.port)

request = Net::HTTP::Post.new(url)
request["Content-Type"] = 'application/json'
request["Api-Key"] = '{yourApiKey}'
request["SiteId"] = '{yourSiteId}'
request["Authorization"] = '{staffAuthToken}'
request.body = "{\r\n\t\"StartDateTime\": \"2018-10-16T15:00:00\",\r\n\t\"LocationId\": 1,\r\n\t\"StaffId\": 22,\r\n\t\"ClientId\": \"100000934\",\r\n\t\"SessionTypeId\": 2,\r\n\t\"ClientServiceId\": 86602,\r\n\t\"ApplyPayment\": true,\r\n\t\"IgnoreDefaultSessionLength\": false,\r\n\t\"SendEmail\": false,\r\n\t\"Test\": false\r\n}\r\n"

response = http.request(request)
puts response.read_body
```
:::
<h3 class="toc-ignore">Summary</h3>
This tutorial demonstrates how a staff member can book an appointment for a client.<br><br>To book an appointment, follow these steps:
<ul><li>Get a user authentication token for the staff member.</li><li>Get a location ID.</li><li>Get a session type ID.</li><li>Retrieve bookable items that contain the information needed to book the appointment.</li><li>Optionally, you can get the client service ID.</li><li>
Book the appointment.</li></ul>

<h3 class="toc-ignore">Workflow</h3>
Note that you need to determine the client ID from your own application, as the Mindbody Public API does not validate client logins.
<ol class="step-list">
	<li id="fpb1">Get a user authentication token for the staff member by passing their login credentials to the authentication endpoint. For a description of the user authentication process, see <a href="#/http/mindbody-public-api-v6-0/authentication/user-tokens">User Tokens</a>. For all following steps, put the token you receive into the <code>Authorization</code> header formatted as <code>Bearer {authToken}</code>.</li>
	<li id="fpb2">The <a href="#get-locations">GetLocations</a> endpoint allows you to retrieve business locations. Each location object that returns has a location ID. At this point, the staff member may choose a location for the appointment. See the <a href="#get-locations">GetLocations</a> endpoint for an example response.</li>
	<li id="fpb3">Use the <a href="#get-session-types">GetSessionTypes</a> endpoint to retrieve session types. Each <code>SessionType</code> object that returns has an ID. You need the session type ID for the appointment that the client wants to book. For additional information and to customize your results, see the <a href="#get-session-types">GetSessionTypes</a> endpoint.</li>
	<li id="fpb4">Before you can book an appointment, you need to get the bookable items. In this case, the bookable items are the staff and appointment availability information. Use the <a href="#get-bookable-items">GetBookableItems</a> endpoint to retrieve this information.<br><br>Use the session type IDs from <strong>Step 3</strong> and a location ID from <strong>Step 2</strong> as the parameters for the request. Each <code>Availability</code> object that returns contains a <code>Staff</code> object, a <code>SessionType</code> object, a start date and time, and a <code>Location</code> object. See the <a href="#get-bookable-items">GetBookableItems</a> endpoint for an example response.</li>
	<li id="fpb5">Optionally, you can use<a href="#get-client-services"> GetClientServices</a> endpoint to obtain services that can pay for the class by specifying the session type ID from <strong>Step 4</strong> and the client ID from your application.</li>
	<li id="fpb6">Use the information gathered in the previous steps to book the appointment with the <code>AddAppointment</code> endpoint. See the <a href="#add-appointment">AddAppointment</a> endpoint for an example response. Setting <code>Test</code> to <code>true</code> allows you to test the request without affecting the database.</li>
</ol>
<p>**Note:** Virtual billings are tracked via the "ContentFormats" property, found in the <a href="#program" id="virtual_program">program shared resource</a>. Any class that is booked that contains values "Livestream:Mindbody" or "Livestream:Other", will count as a virtual booking. Any bookings class that is booked under "InPerson" will count as an in-person booking. Please note that booking fees are incurred based on these settings. To help businesses correctly mark their classes as virtual or in-person, please reference the support article titled <a href="https://support.mindbodyonline.com/s/article/Live-stream?language=en_US" id="virtual_live_stream">"Live stream: Setup, scheduling, and <br>pricing, "</a> under the second section-"Setting up live stream classes."</p>

