﻿## Purchase a Product Online
<script type="text/javascript">
monitor('purchase-a-product-online');
</script>

> Step 2: Get the products

:::visible {language=http}
```
curl -X GET \
  https://api.mindbodyonline.com/public/v6/sale/products \
  -H 'Api-Key: {yourApiKey}' \
  -H 'SiteId: {yourSiteId}' \
  -A '{yourAppName}' \
```
:::

:::visible {language=csharp}
```
var client = new RestClient("https://api.mindbodyonline.com/public/v6/sale/products");
var request = new RestRequest(Method.GET);
request.AddHeader("SiteId", "{yourSiteId}");
request.AddHeader("Api-Key", "{yourApiKey}");
IRestResponse response = client.Execute(request);
```
:::

:::visible {language=php}
```
<?php

$request = new HttpRequest();
$request->setUrl('https://api.mindbodyonline.com/public/v6/sale/products');
$request->setMethod(HTTP_METH_GET);

$request->setHeaders(array(
  'SiteId' => '{yourSiteId}',
  'Api-Key' => '{yourApiKey}'
));

try {
  $response = $request->send();

  echo $response->getBody();
} catch (HttpException $ex) {
  echo $ex;
}
```
:::

:::visible {language=python}
```
import http.client

conn = http.client.HTTPSConnection("api.mindbodyonline.com")

headers = {
	'Api-Key': "{yourApiKey}",
    'SiteId': "{yourSiteId}"
    }

conn.request("GET", "public/v6/sale/products", headers=headers)

res = conn.getresponse()
data = res.read()

print(data.decode("utf-8"))
```
:::

:::visible {language=ruby}
```
require 'uri'
require 'net/http'

url = URI("https://api.mindbodyonline.com/public/v6/sale/products")

http = Net::HTTP.new(url.host, url.port)

request = Net::HTTP::Get.new(url)
request["Api-Key"] = '{yourApiKey}'
request["SiteId"] = '{yourSiteId}'

response = http.request(request)
puts response.read_body
```
:::

> Step 3: Purchase the product using CheckoutShoppingCart

:::visible {language=http}
```
curl -X POST \
  https://api.mindbodyonline.com/public/v6/sale/checkoutshoppingcart \
  -H 'Content-Type: application/json' \
  -H 'Api-Key: {yourApiKey}' \
  -H 'Authorization: {staffAuthToken}' \
  -H 'SiteId: {yourSiteId}' \
  -A '{yourAppName}' \
  -d '{
  "ClientId": "100000701",
  "Test": false,
  "Items": [
    {
      "Item": {
        "Type": "Product",
        "Metadata": {
          "Id" : "3"
        }
      },
      "Quantity": 1
    }
  ],
  "InStore": true,
  "CalculateTax": true,
  "Payments": [
    {
      "Type": "CreditCard",
      "Metadata": {
      	"Amount":10,
      	"CreditCardNumber":"4111111111111111",
      	"ExpMonth": 12,
      	"ExpYear" : 2021,
      	"Cvv": "323",
      	"BillingName":"John Doe",
      	"BillingAddress": "1234 Brad Street",
      	"BillingCity" : "San Luis Obispo",
      	"BillingState" : "CA",
      	"BillingPostalCode": "93405",
      	"SaveInfo": true
      }
    }
  ],
  "SendEmail": true,
  "LocationId": 1
}'
```
:::

:::visible {language=csharp}
```
var client = new RestClient("https://api.mindbodyonline.com/public/v6/sale/checkoutshoppingcart");
var request = new RestRequest(Method.POST);
request.AddHeader("Authorization", "{staffAuthToken}");
request.AddHeader("SiteId", "{yourSiteId}");
request.AddHeader("Api-Key", "{yourApiKey}");
request.AddParameter("application/json", "{\r\n  \"ClientId\": \"100000701\",\r\n  \"Test\": false,\r\n  \"Items\": [\r\n    {\r\n      \"Item\": {\r\n        \"Type\": \"Product\",\r\n        \"Metadata\": {\r\n          \"Id\" : \"3\"\r\n        }\r\n      },\r\n      \"Quantity\": 1\r\n    }\r\n  ],\r\n  \"InStore\": true,\r\n  \"Payments\": [\r\n    {\r\n      \"Type\": \"CreditCard\",\r\n      \"Metadata\": {\r\n      \t\"Amount\":10,\r\n      \t\"CreditCardNumber\":\"4111111111111111\",\r\n      \t\"ExpMonth\": 12,\r\n      \t\"ExpYear\" : 2021,\r\n      \t\"Cvv\": \"323\",\r\n      \t\"BillingName\":\"John Doe\",\r\n      \t\"BillingAddress\": \"1234 Brad Street\",\r\n      \t\"BillingCity\" : \"San Luis Obispo\",\r\n      \t\"BillingState\" : \"CA\",\r\n      \t\"BillingPostalCode\": \"93405\",\r\n      \t\"SaveInfo\": true\r\n      }\r\n    }\r\n  ],\r\n  \"SendEmail\": true,\r\n  \"LocationId\": 1\r\n}", ParameterType.RequestBody);
IRestResponse response = client.Execute(request);
```
:::

:::visible {language=php}
```
<?php

$request = new HttpRequest();
$request->setUrl('https://api.mindbodyonline.com/public/v6/sale/checkoutshoppingcart');
$request->setMethod(HTTP_METH_POST);

$request->setHeaders(array(
  'Authorization' => '{staffAuthToken}',
  'Content-Type' => 'application/json',
  'SiteId' => '{yourSiteId}',
  'Api-Key' => '{yourApiKey}'
));

$request->setBody('{
  "ClientId": "100000701",
  "Test": false,
  "Items": [
    {
      "Item": {
        "Type": "Product",
        "Metadata": {
          "Id" : "3"
        }
      },
      "Quantity": 1
    }
  ],
  "InStore": true,
  "Payments": [
    {
      "Type": "CreditCard",
      "Metadata": {
      	"Amount":10,
      	"CreditCardNumber":"4111111111111111",
      	"ExpMonth": 12,
      	"ExpYear" : 2021,
      	"Cvv": "323",
      	"BillingName":"John Doe",
      	"BillingAddress": "1234 Brad Street",
      	"BillingCity" : "San Luis Obispo",
      	"BillingState" : "CA",
      	"BillingPostalCode": "93405",
      	"SaveInfo": true
      }
    }
  ],
  "SendEmail": true,
  "LocationId": 1
}');

try {
  $response = $request->send();

  echo $response->getBody();
} catch (HttpException $ex) {
  echo $ex;
}
```
:::

:::visible {language=python}
```
import http.client

conn = http.client.HTTPSConnection("api.mindbodyonline.com")

payload = "{\r\n  \"ClientId\": \"100000701\",\r\n  \"Test\": false,\r\n  \"Items\": [\r\n    {\r\n      \"Item\": {\r\n        \"Type\": \"Product\",\r\n        \"Metadata\": {\r\n          \"Id\" : \"3\"\r\n        }\r\n      },\r\n      \"Quantity\": 1\r\n    }\r\n  ],\r\n  \"InStore\": true,\r\n  \"Payments\": [\r\n    {\r\n      \"Type\": \"CreditCard\",\r\n      \"Metadata\": {\r\n      \t\"Amount\":10,\r\n      \t\"CreditCardNumber\":\"4111111111111111\",\r\n      \t\"ExpMonth\": 12,\r\n      \t\"ExpYear\" : 2021,\r\n      \t\"Cvv\": \"323\",\r\n      \t\"BillingName\":\"John Doe\",\r\n      \t\"BillingAddress\": \"1234 Brad Street\",\r\n      \t\"BillingCity\" : \"San Luis Obispo\",\r\n      \t\"BillingState\" : \"CA\",\r\n      \t\"BillingPostalCode\": \"93405\",\r\n      \t\"SaveInfo\": true\r\n      }\r\n    }\r\n  ],\r\n  \"SendEmail\": true,\r\n  \"LocationId\": 1\r\n}"

headers = {
    'Content-Type': "application/json",
	'Api-Key': "{yourApiKey}",
    'SiteId': "{yourSiteId}",
    'Authorization': "{staffAuthToken}"
    }

conn.request("POST", "public/v6/sale/checkoutshoppingcart", payload, headers)

res = conn.getresponse()
data = res.read()

print(data.decode("utf-8"))
```
:::

:::visible {language=ruby}
```
require 'uri'
require 'net/http'

url = URI("https://api.mindbodyonline.com/public/v6/sale/checkoutshoppingcart")

http = Net::HTTP.new(url.host, url.port)

request = Net::HTTP::Post.new(url)
request["Content-Type"] = 'application/json'
request["Api-Key"] = '{yourApiKey}'
request["SiteId"] = '{yourSiteId}'
request["Authorization"] = '{staffAuthToken}'
request.body = "{\r\n  \"ClientId\": \"100000701\",\r\n  \"Test\": false,\r\n  \"Items\": [\r\n    {\r\n      \"Item\": {\r\n        \"Type\": \"Product\",\r\n        \"Metadata\": {\r\n          \"Id\" : \"3\"\r\n        }\r\n      },\r\n      \"Quantity\": 1\r\n    }\r\n  ],\r\n  \"InStore\": true,\r\n  \"Payments\": [\r\n    {\r\n      \"Type\": \"CreditCard\",\r\n      \"Metadata\": {\r\n      \t\"Amount\":10,\r\n      \t\"CreditCardNumber\":\"4111111111111111\",\r\n      \t\"ExpMonth\": 12,\r\n      \t\"ExpYear\" : 2021,\r\n      \t\"Cvv\": \"323\",\r\n      \t\"BillingName\":\"John Doe\",\r\n      \t\"BillingAddress\": \"1234 Brad Street\",\r\n      \t\"BillingCity\" : \"San Luis Obispo\",\r\n      \t\"BillingState\" : \"CA\",\r\n      \t\"BillingPostalCode\": \"93405\",\r\n      \t\"SaveInfo\": true\r\n      }\r\n    }\r\n  ],\r\n  \"SendEmail\": true,\r\n  \"LocationId\": 1\r\n}"

response = http.request(request)
puts response.read_body
```
:::

<h3 class="toc-ignore">Summary</h3>
This tutorial demonstrates how a staff member can purchase a product for a client.

<h3 class="toc-ignore">Workflow</h3>
Note that you need to determine the client ID from your own application, as the Mindbody Public API does not validate client logins.
<ol class="step-list">
	<li id="fpb1">Get a user authentication token for the staff member by passing the login credentials to the authentication endpoint. For examples and a description of the user authentication process, see <a href="#user-tokens">User Tokens</a>. For all following steps, put the token you receive into the <code>Authorization</code> header formatted as <code>Bearer {authToken}</code>.</li>
	<li id="fpb2">Use the <a href="#get-products">GetProducts</a> endpoint to retrieve the list of products. Each product object that returns contains an ID.</li>
	<li id="fpb3">Use <a href="#checkout-shopping-cart">CheckoutShoppingCart</a> to check out. Use the client ID from your own application and the product IDs from <strong>Step 2</strong>. The <code>Amount</code> under <code>PaymentInfo</code> must match the shopping cart total for the payment to go through. We do not recommend calculating the total amount yourself. Instead, obtain the total for the entire cart first, and then use that as the total amount. Setting <code>Test</code> to <code>true</code> allows you to test the request without affecting the database.<br><br>For more information, see the <a href="#get-shopping-cart-total">Get Shopping Cart Total</a> tutorial.
</ol>

<h4>Note</h4>
Protect yourself from processor fees and credit card fraud.  Remember to always protect your web forms that leverage <a href="#checkout-shopping-cart">POST CheckoutShoppingCart</a>, <a href="#purchase-contract">POST PurchaseContract</a> or <a href="#purchase-gift-card">POST PurchaseGiftCard</a> with a CAPTCHA!

