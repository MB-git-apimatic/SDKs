
# Mindbody Public Api Dto Models V6 Sale Controller Get Gift Cards Request

## Structure

`MindbodyPublicApiDtoModelsV6SaleControllerGetGiftCardsRequest`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `locationId` | `?int` | Optional | When included, returns gift cards that are sold at the provided location ID. | getLocationId(): ?int | setLocationId(?int locationId): void |
| `soldOnline` | `?bool` | Optional | When `true`, only returns gift cards that are sold online.<br /><br>Default: **false** | getSoldOnline(): ?bool | setSoldOnline(?bool soldOnline): void |
| `includeCustomLayouts` | `?bool` | Optional | When `true`, includes custom gift card layouts.<br /><br>When `false`, includes only system layouts.<br>Default: **false** | getIncludeCustomLayouts(): ?bool | setIncludeCustomLayouts(?bool includeCustomLayouts): void |
| `ids` | `?(int[])` | Optional | Filters the results to the requested gift card IDs.<br /><br>Default: **all** gift cards. | getIds(): ?array | setIds(?array ids): void |
| `limit` | `?int` | Optional | Number of results to include, defaults to 100 | getLimit(): ?int | setLimit(?int limit): void |
| `offset` | `?int` | Optional | Page offset, defaults to 0. | getOffset(): ?int | setOffset(?int offset): void |

## Example (as JSON)

```json
{
  "LocationId": null,
  "SoldOnline": null,
  "IncludeCustomLayouts": null,
  "Ids": null,
  "Limit": null,
  "Offset": null
}
```

