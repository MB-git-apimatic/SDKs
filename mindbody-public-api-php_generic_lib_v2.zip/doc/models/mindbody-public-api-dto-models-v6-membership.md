
# Mindbody Public Api Dto Models V6 Membership

## Structure

`MindbodyPublicApiDtoModelsV6Membership`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `membershipId` | `?int` | Optional | The membership id. | getMembershipId(): ?int | setMembershipId(?int membershipId): void |
| `membershipName` | `?string` | Optional | The membership name. | getMembershipName(): ?string | setMembershipName(?string membershipName): void |
| `priority` | `?int` | Optional | The priority/sort order. | getPriority(): ?int | setPriority(?int priority): void |
| `memberRetailDiscount` | `?float` | Optional | The membership discount for retail as a percentage. | getMemberRetailDiscount(): ?float | setMemberRetailDiscount(?float memberRetailDiscount): void |
| `memberServiceDiscount` | `?float` | Optional | The membership discount for services as a percentage. | getMemberServiceDiscount(): ?float | setMemberServiceDiscount(?float memberServiceDiscount): void |
| `allowClientsToScheduleUnpaid` | `?bool` | Optional | Allow clients in this membership to schedule unpaid. | getAllowClientsToScheduleUnpaid(): ?bool | setAllowClientsToScheduleUnpaid(?bool allowClientsToScheduleUnpaid): void |
| `onlineBookingRestrictedToMembersOnly` | [`?(MindbodyPublicApiDtoModelsV6ProgramMembership[])`](../../doc/models/mindbody-public-api-dto-models-v6-program-membership.md) | Optional | List of programs that are restricted to clients in this membership only. | getOnlineBookingRestrictedToMembersOnly(): ?array | setOnlineBookingRestrictedToMembersOnly(?array onlineBookingRestrictedToMembersOnly): void |
| `dayOfMonthSchedulingOpensForNextMonth` | `?int` | Optional | Day of month scheduling opens for next month.  Unrestricted is a null value. | getDayOfMonthSchedulingOpensForNextMonth(): ?int | setDayOfMonthSchedulingOpensForNextMonth(?int dayOfMonthSchedulingOpensForNextMonth): void |
| `restrictSelfSignInToMembersOnly` | `?bool` | Optional | Restrict self sign in to members only. | getRestrictSelfSignInToMembersOnly(): ?bool | setRestrictSelfSignInToMembersOnly(?bool restrictSelfSignInToMembersOnly): void |
| `allowMembersToBookAppointmentsWithoutPaying` | `?bool` | Optional | Allow members to book appointments without paying. | getAllowMembersToBookAppointmentsWithoutPaying(): ?bool | setAllowMembersToBookAppointmentsWithoutPaying(?bool allowMembersToBookAppointmentsWithoutPaying): void |
| `allowMembersToPurchaseNonMembersServices` | `?bool` | Optional | Allow members to purchase non-members services. | getAllowMembersToPurchaseNonMembersServices(): ?bool | setAllowMembersToPurchaseNonMembersServices(?bool allowMembersToPurchaseNonMembersServices): void |
| `allowMembersToPurchaseNonMembersProducts` | `?bool` | Optional | Allow members to purchase non-members products. | getAllowMembersToPurchaseNonMembersProducts(): ?bool | setAllowMembersToPurchaseNonMembersProducts(?bool allowMembersToPurchaseNonMembersProducts): void |
| `isActive` | `?bool` | Optional | Indicates if the membership is active. | getIsActive(): ?bool | setIsActive(?bool isActive): void |

## Example (as JSON)

```json
{
  "MembershipId": null,
  "MembershipName": null,
  "Priority": null,
  "MemberRetailDiscount": null,
  "MemberServiceDiscount": null,
  "AllowClientsToScheduleUnpaid": null,
  "OnlineBookingRestrictedToMembersOnly": null,
  "DayOfMonthSchedulingOpensForNextMonth": null,
  "RestrictSelfSignInToMembersOnly": null,
  "AllowMembersToBookAppointmentsWithoutPaying": null,
  "AllowMembersToPurchaseNonMembersServices": null,
  "AllowMembersToPurchaseNonMembersProducts": null,
  "IsActive": null
}
```

