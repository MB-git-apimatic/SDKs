
# Days Valid Enum

## Enumeration

`DaysValidEnum`

## Fields

| Name |
|  --- |
| `SUNDAY` |
| `MONDAY` |
| `TUESDAY` |
| `WEDNESDAY` |
| `THURSDAY` |
| `FRIDAY` |
| `SATURDAY` |

