
# Mindbody Public Api Dto Models V6 Client Controller Get Client Rewards Response

## Structure

`MindbodyPublicApiDtoModelsV6ClientControllerGetClientRewardsResponse`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `paginationResponse` | [`?MindbodyPublicApiDtoModelsV6PaginationResponse`](../../doc/models/mindbody-public-api-dto-models-v6-pagination-response.md) | Optional | - | getPaginationResponse(): ?MindbodyPublicApiDtoModelsV6PaginationResponse | setPaginationResponse(?MindbodyPublicApiDtoModelsV6PaginationResponse paginationResponse): void |
| `balance` | `?int` | Optional | Current balance of client rewards | getBalance(): ?int | setBalance(?int balance): void |
| `transactions` | [`?(MindbodyPublicApiDtoModelsV6ClientRewardTransaction[])`](../../doc/models/mindbody-public-api-dto-models-v6-client-reward-transaction.md) | Optional | List of client reward transactions | getTransactions(): ?array | setTransactions(?array transactions): void |

## Example (as JSON)

```json
{
  "PaginationResponse": null,
  "Balance": null,
  "Transactions": null
}
```

