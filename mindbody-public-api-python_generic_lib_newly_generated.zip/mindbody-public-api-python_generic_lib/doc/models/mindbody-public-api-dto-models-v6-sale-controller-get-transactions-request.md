
# Mindbody Public Api Dto Models V6 Sale Controller Get Transactions Request

Transactions Request

## Structure

`MindbodyPublicApiDtoModelsV6SaleControllerGetTransactionsRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `sale_id` | `long\|int` | Optional | Filters the transaction results with the ID number associated with the sale. |
| `transaction_id` | `int` | Optional | Filters the transaction results with the ID number generated when the sale is processed. |
| `client_id` | `long\|int` | Optional | Filters results to the requested client ID. |
| `location_id` | `int` | Optional | Filters the transaction results with the ID number associated with the location of the sale. |
| `status` | `string` | Optional | Filters the transaction results by the estimated transaction status. |
| `transaction_start_date_time` | `datetime` | Optional | Filters the transaction results that happpened after this date and time.<br>Default: **today’s date** |
| `transaction_end_date_time` | `datetime` | Optional | Filters the transaction results that happpened before this date and time.<br>Default: **today’s date** |
| `limit` | `int` | Optional | Number of results to include, defaults to 100 |
| `offset` | `int` | Optional | Page offset, defaults to 0. |

## Example (as JSON)

```json
{
  "SaleId": null,
  "TransactionId": null,
  "ClientId": null,
  "LocationId": null,
  "Status": null,
  "TransactionStartDateTime": null,
  "TransactionEndDateTime": null,
  "Limit": null,
  "Offset": null
}
```

