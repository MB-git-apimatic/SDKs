
# Request Schedule Type Enum

## Enumeration

`RequestScheduleTypeEnum`

## Fields

| Name |
|  --- |
| `ALL` |
| `CLASS_` |
| `ENROLLMENT` |
| `APPOINTMENT` |
| `RESOURCE` |
| `MEDIA` |
| `ARRIVAL` |

