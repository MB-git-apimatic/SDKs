
# Mindbody Public Api Dto Models V6 Staff Controller Get Sales Reps Request

This is the request class for the get sales reps API

## Structure

`MindbodyPublicApiDtoModelsV6StaffControllerGetSalesRepsRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `sales_rep_numbers` | `List of int` | Optional | This is the list of rep numbers to be fetched |
| `active_only` | `bool` | Optional | This is to filter out the active sales rep from the list |
| `limit` | `int` | Optional | Number of results to include, defaults to 100 |
| `offset` | `int` | Optional | Page offset, defaults to 0. |

## Example (as JSON)

```json
{
  "SalesRepNumbers": null,
  "ActiveOnly": null,
  "Limit": null,
  "Offset": null
}
```

