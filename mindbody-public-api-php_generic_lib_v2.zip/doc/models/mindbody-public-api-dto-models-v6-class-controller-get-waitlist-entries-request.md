
# Mindbody Public Api Dto Models V6 Class Controller Get Waitlist Entries Request

## Structure

`MindbodyPublicApiDtoModelsV6ClassControllerGetWaitlistEntriesRequest`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `classIds` | `?(int[])` | Optional | The requested class IDs. If a class ID is present, the request automatically disregards any class schedule IDs in the request. <br /><br>Either `ClassScheduleIds`, `ClientIds`, `WaitlistEntryIds`, or `ClassIds` is required; the others become optional.<br /><br>Default: **all ClassIds** | getClassIds(): ?array | setClassIds(?array classIds): void |
| `classScheduleIds` | `?(int[])` | Optional | The requested class schedule IDs. If a class ID is present, the request automatically disregards any class schedule IDs in the request.<br /><br>Either `ClassScheduleIds`, `ClientIds`, `WaitlistEntryIds`, or `ClassIds` is required; the others become optional.<br /><br>Default: **all ClassScheduleIds** | getClassScheduleIds(): ?array | setClassScheduleIds(?array classScheduleIds): void |
| `clientIds` | `?(string[])` | Optional | The requested client IDs.<br /><br>Either `ClassScheduleIds`, `ClientIds`, `WaitlistEntryIds`, or `ClassIds` is required; the others become optional.<br /><br>Default: **all ClientIds** | getClientIds(): ?array | setClientIds(?array clientIds): void |
| `hidePastEntries` | `?bool` | Optional | When `true`, indicates that past waiting list entries are hidden from clients.<br /><br>When `false`, indicates that past entries are not hidden from clients.<br /><br>Default: **false** | getHidePastEntries(): ?bool | setHidePastEntries(?bool hidePastEntries): void |
| `waitlistEntryIds` | `?(int[])` | Optional | The requested waiting list entry IDs.<br /><br>Either `ClassScheduleIds`, `ClientIds`, `WaitlistEntryIds`, or `ClassIds` is required; the others become optional.<br /><br>Default: **all WaitlistEntryIds** | getWaitlistEntryIds(): ?array | setWaitlistEntryIds(?array waitlistEntryIds): void |
| `limit` | `?int` | Optional | Number of results to include, defaults to 100 | getLimit(): ?int | setLimit(?int limit): void |
| `offset` | `?int` | Optional | Page offset, defaults to 0. | getOffset(): ?int | setOffset(?int offset): void |

## Example (as JSON)

```json
{
  "ClassIds": null,
  "ClassScheduleIds": null,
  "ClientIds": null,
  "HidePastEntries": null,
  "WaitlistEntryIds": null,
  "Limit": null,
  "Offset": null
}
```

