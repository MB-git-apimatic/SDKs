
# Mindbody Public Api Dto Models V6 Semester

Semesters help you quickly classify enrollments.

## Structure

`MindbodyPublicApiDtoModelsV6Semester`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `int` | Optional | - |
| `name` | `string` | Optional | - |
| `description` | `string` | Optional | - |
| `start_date` | `datetime` | Optional | - |
| `end_date` | `datetime` | Optional | - |
| `multi_registration_discount` | `float` | Optional | - |
| `multi_registration_deadline` | `datetime` | Optional | - |
| `active` | `bool` | Optional | - |

## Example (as JSON)

```json
{
  "Id": null,
  "Name": null,
  "Description": null,
  "StartDate": null,
  "EndDate": null,
  "MultiRegistrationDiscount": null,
  "MultiRegistrationDeadline": null,
  "Active": null
}
```

