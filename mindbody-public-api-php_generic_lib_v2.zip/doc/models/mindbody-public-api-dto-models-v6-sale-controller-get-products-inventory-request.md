
# Mindbody Public Api Dto Models V6 Sale Controller Get Products Inventory Request

## Structure

`MindbodyPublicApiDtoModelsV6SaleControllerGetProductsInventoryRequest`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `productIds` | `?(string[])` | Optional | When included, the response only contains details about the specified product Ids. | getProductIds(): ?array | setProductIds(?array productIds): void |
| `locationIds` | `?(int[])` | Optional | When included, the response only contains details about the specified location Ids. | getLocationIds(): ?array | setLocationIds(?array locationIds): void |
| `barcodeIds` | `?(string[])` | Optional | When included, the response only contains details about the specified Barcode Ids. | getBarcodeIds(): ?array | setBarcodeIds(?array barcodeIds): void |
| `limit` | `?int` | Optional | Number of results to include, defaults to 100 | getLimit(): ?int | setLimit(?int limit): void |
| `offset` | `?int` | Optional | Page offset, defaults to 0. | getOffset(): ?int | setOffset(?int offset): void |

## Example (as JSON)

```json
{
  "ProductIds": null,
  "LocationIds": null,
  "BarcodeIds": null,
  "Limit": null,
  "Offset": null
}
```

