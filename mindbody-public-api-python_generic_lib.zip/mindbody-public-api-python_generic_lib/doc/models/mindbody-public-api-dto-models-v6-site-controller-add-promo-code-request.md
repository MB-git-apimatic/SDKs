
# Mindbody Public Api Dto Models V6 Site Controller Add Promo Code Request

## Structure

`MindbodyPublicApiDtoModelsV6SiteControllerAddPromoCodeRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `code` | `string` | Required | Promotion Code. |
| `name` | `string` | Required | Promotion Name. |
| `active` | `bool` | Optional | Active status |
| `discount` | [`MindbodyPublicApiDtoModelsV6Discount`](../../doc/models/mindbody-public-api-dto-models-v6-discount.md) | Optional | Discount for a promo code |
| `activation_date` | `datetime` | Optional | Date activated |
| `expiration_date` | `datetime` | Optional | Date expired |
| `max_uses` | `int` | Optional | How many times it can be used |
| `days_after_close_date` | `int` | Optional | Days after close date |
| `allow_online` | `bool` | Optional | Whether it can be used online |
| `days_valid` | `List of string` | Optional | What days the promo code can be used |
| `applicable_items` | [`List of MindbodyPublicApiDtoModelsV6ApplicableItem`](../../doc/models/mindbody-public-api-dto-models-v6-applicable-item.md) | Optional | Items that the promo code will have the discount for.<br>If Null, promo code applies to all items. |

## Example (as JSON)

```json
{
  "Code": "Code0",
  "Name": "Name0",
  "Active": null,
  "Discount": null,
  "ActivationDate": null,
  "ExpirationDate": null,
  "MaxUses": null,
  "DaysAfterCloseDate": null,
  "AllowOnline": null,
  "DaysValid": null,
  "ApplicableItems": null
}
```

