
# Mindbody Public Api Common Models Sub Category

## Structure

`MindbodyPublicApiCommonModelsSubCategory`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `id` | `?int` | Optional | - | getId(): ?int | setId(?int id): void |
| `subCategoryName` | `?string` | Optional | - | getSubCategoryName(): ?string | setSubCategoryName(?string subCategoryName): void |
| `active` | `?bool` | Optional | - | getActive(): ?bool | setActive(?bool active): void |

## Example (as JSON)

```json
{
  "Id": null,
  "SubCategoryName": null,
  "Active": null
}
```

