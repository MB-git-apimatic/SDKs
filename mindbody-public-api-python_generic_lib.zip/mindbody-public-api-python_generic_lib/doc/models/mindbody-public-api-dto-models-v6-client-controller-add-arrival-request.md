
# Mindbody Public Api Dto Models V6 Client Controller Add Arrival Request

## Structure

`MindbodyPublicApiDtoModelsV6ClientControllerAddArrivalRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `client_id` | `string` | Required | The ID of the requested client. |
| `location_id` | `int` | Required | The ID of the location for the requested arrival. |
| `arrival_type_id` | `int` | Optional | The ID of the arrival type to take.<br>OPTIONAL: will take first payment found if not provided |
| `test` | `bool` | Optional | OPTIONAL: If test is true only validation is ran |

## Example (as JSON)

```json
{
  "ClientId": "ClientId6",
  "LocationId": 50,
  "ArrivalTypeId": null,
  "Test": null
}
```

