
# Mindbody Public Api Common Models Staff

## Structure

`MindbodyPublicApiCommonModelsStaff`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `long\|int` | Optional | - |
| `first_name` | `string` | Optional | - |
| `last_name` | `string` | Optional | - |
| `display_name` | `string` | Optional | - |
| `email` | `string` | Optional | - |
| `bio` | `string` | Optional | - |
| `address` | `string` | Optional | - |
| `address_2` | `string` | Optional | - |
| `city` | `string` | Optional | - |
| `state` | `string` | Optional | - |
| `postal_code` | `string` | Optional | - |
| `foreign_zip` | `string` | Optional | - |
| `country` | `string` | Optional | - |
| `work_phone` | `string` | Optional | - |
| `home_phone` | `string` | Optional | - |
| `cell_phone` | `string` | Optional | - |
| `active` | `bool` | Optional | - |
| `is_system` | `bool` | Optional | - |
| `smode_id` | `int` | Optional | - |
| `appointment_trn` | `bool` | Optional | - |
| `always_allow_double_booking` | `bool` | Optional | - |
| `independent_contractor` | `bool` | Optional | - |
| `image_url` | `string` | Optional | - |
| `is_male` | `bool` | Optional | - |
| `reservation_trn` | `bool` | Optional | - |
| `sort_order` | `int` | Optional | - |
| `multi_location_permission` | `bool` | Optional | - |
| `name` | `string` | Optional | - |
| `provider_i_ds` | `List of string` | Optional | - |
| `rep` | `bool` | Optional | - |
| `rep_2` | `bool` | Optional | - |
| `rep_3` | `bool` | Optional | - |
| `rep_4` | `bool` | Optional | - |
| `rep_5` | `bool` | Optional | - |
| `rep_6` | `bool` | Optional | - |
| `assistant` | `bool` | Optional | - |
| `assistant_2` | `bool` | Optional | - |
| `employment_start` | `datetime` | Optional | - |
| `employment_end` | `datetime` | Optional | - |
| `emp_id` | `string` | Optional | - |
| `appointments` | [`List of MindbodyPublicApiCommonModelsAppointment`](../../doc/models/mindbody-public-api-common-models-appointment.md) | Optional | - |
| `unavailabilities` | [`List of MindbodyPublicApiCommonModelsUnavailability`](../../doc/models/mindbody-public-api-common-models-unavailability.md) | Optional | - |
| `availabilities` | [`List of MindbodyPublicApiCommonModelsAvailability`](../../doc/models/mindbody-public-api-common-models-availability.md) | Optional | - |
| `login_locations` | [`List of MindbodyPublicApiCommonModelsLocation`](../../doc/models/mindbody-public-api-common-models-location.md) | Optional | - |

## Example (as JSON)

```json
{
  "Id": null,
  "FirstName": null,
  "LastName": null,
  "DisplayName": null,
  "Email": null,
  "Bio": null,
  "Address": null,
  "Address2": null,
  "City": null,
  "State": null,
  "PostalCode": null,
  "ForeignZip": null,
  "Country": null,
  "WorkPhone": null,
  "HomePhone": null,
  "CellPhone": null,
  "Active": null,
  "IsSystem": null,
  "SmodeId": null,
  "AppointmentTrn": null,
  "AlwaysAllowDoubleBooking": null,
  "IndependentContractor": null,
  "ImageUrl": null,
  "IsMale": null,
  "ReservationTrn": null,
  "SortOrder": null,
  "MultiLocationPermission": null,
  "Name": null,
  "ProviderIDs": null,
  "Rep": null,
  "Rep2": null,
  "Rep3": null,
  "Rep4": null,
  "Rep5": null,
  "Rep6": null,
  "Assistant": null,
  "Assistant2": null,
  "EmploymentStart": null,
  "EmploymentEnd": null,
  "EmpID": null,
  "Appointments": null,
  "Unavailabilities": null,
  "Availabilities": null,
  "LoginLocations": null
}
```

