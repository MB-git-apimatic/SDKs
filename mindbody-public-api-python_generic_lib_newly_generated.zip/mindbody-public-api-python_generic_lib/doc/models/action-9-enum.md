
# Action 9 Enum

Action that was performed

## Enumeration

`Action9Enum`

## Fields

| Name |
|  --- |
| `EARNED` |
| `REDEEMED` |
| `RETURNED` |
| `REMOVED` |
| `LATECANCELED` |

