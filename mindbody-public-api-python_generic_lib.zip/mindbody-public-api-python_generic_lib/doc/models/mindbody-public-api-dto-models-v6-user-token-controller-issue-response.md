
# Mindbody Public Api Dto Models V6 User Token Controller Issue Response

POST UserToken/Issue successful response

## Structure

`MindbodyPublicApiDtoModelsV6UserTokenControllerIssueResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `token_type` | `string` | Optional | - |
| `access_token` | `string` | Optional | The authentication token value. |
| `user` | [`MindbodyPublicApiDtoModelsV6User`](../../doc/models/mindbody-public-api-dto-models-v6-user.md) | Optional | - |

## Example (as JSON)

```json
{
  "TokenType": null,
  "AccessToken": null,
  "User": null
}
```

