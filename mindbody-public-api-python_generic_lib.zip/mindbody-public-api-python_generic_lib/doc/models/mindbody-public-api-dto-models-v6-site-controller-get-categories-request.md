
# Mindbody Public Api Dto Models V6 Site Controller Get Categories Request

Get Categories Request Model

## Structure

`MindbodyPublicApiDtoModelsV6SiteControllerGetCategoriesRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `category_ids` | `List of int` | Optional | The requested category IDs. |
| `sub_category_ids` | `List of int` | Optional | The requested sub category IDs. |
| `service` | `bool` | Optional | The requested Service type. true indicates for Revenue Categories and false indicates for Product Revenue Categories. |
| `active` | `bool` | Optional | The requested Active type categories. true indicates for Active Categories and false indicates for Deactivated Categories. |
| `limit` | `int` | Optional | Number of results to include, defaults to 100 |
| `offset` | `int` | Optional | Page offset, defaults to 0. |

## Example (as JSON)

```json
{
  "CategoryIds": null,
  "SubCategoryIds": null,
  "Service": null,
  "Active": null,
  "Limit": null,
  "Offset": null
}
```

