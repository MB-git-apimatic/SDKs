
# Mindbody Public Api Common Models Staff Setting

## Structure

`MindbodyPublicApiCommonModelsStaffSetting`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `use_staff_nicknames` | `bool` | Optional | - |
| `show_staff_last_names_on_schedules` | `bool` | Optional | - |

## Example (as JSON)

```json
{
  "UseStaffNicknames": null,
  "ShowStaffLastNamesOnSchedules": null
}
```

