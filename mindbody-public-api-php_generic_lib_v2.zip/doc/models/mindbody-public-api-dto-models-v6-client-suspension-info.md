
# Mindbody Public Api Dto Models V6 Client Suspension Info

A Client DTO with Suspension Informatoin

## Structure

`MindbodyPublicApiDtoModelsV6ClientSuspensionInfo`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `bookingSuspended` | `?bool` | Optional | When 'true', indicates that the client is suspended from booking | getBookingSuspended(): ?bool | setBookingSuspended(?bool bookingSuspended): void |
| `suspensionStartDate` | `?string` | Optional | Indicates the Date that BookingSuspension starts 'YYYY-MM-DD' | getSuspensionStartDate(): ?string | setSuspensionStartDate(?string suspensionStartDate): void |
| `suspensionEndDate` | `?string` | Optional | Indicates the Date that BookingSuspension ends 'YYYY-MM-DD' | getSuspensionEndDate(): ?string | setSuspensionEndDate(?string suspensionEndDate): void |

## Example (as JSON)

```json
{
  "BookingSuspended": null,
  "SuspensionStartDate": null,
  "SuspensionEndDate": null
}
```

