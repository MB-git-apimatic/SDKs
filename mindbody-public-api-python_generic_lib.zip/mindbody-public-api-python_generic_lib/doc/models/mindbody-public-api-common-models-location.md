
# Mindbody Public Api Common Models Location

## Structure

`MindbodyPublicApiCommonModelsLocation`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `business_id` | `int` | Optional | - |
| `site_id` | `int` | Optional | - |
| `business_description` | `string` | Optional | - |
| `additional_image_ur_ls` | `List of string` | Optional | - |
| `facility_square_feet` | `int` | Optional | - |
| `pro_spa_finder_site` | `bool` | Optional | - |
| `has_classes` | `bool` | Optional | - |
| `phone_extension` | `string` | Optional | - |
| `action` | [`ActionEnum`](../../doc/models/action-enum.md) | Optional | - |
| `id` | `int` | Optional | - |
| `name` | `string` | Optional | - |
| `address` | `string` | Optional | - |
| `address_2` | `string` | Optional | - |
| `tax_1` | `float` | Optional | - |
| `tax_2` | `float` | Optional | - |
| `tax_3` | `float` | Optional | - |
| `tax_4` | `float` | Optional | - |
| `tax_5` | `float` | Optional | - |
| `phone` | `string` | Optional | - |
| `city` | `string` | Optional | - |
| `state_prov_code` | `string` | Optional | - |
| `postal_code` | `string` | Optional | - |
| `latitude` | `float` | Optional | - |
| `longitude` | `float` | Optional | - |
| `distance_in_miles` | `float` | Optional | - |
| `image_url` | `string` | Optional | - |
| `description` | `string` | Optional | - |
| `has_site` | `bool` | Optional | - |
| `can_book` | `bool` | Optional | - |
| `number_treatment_rooms` | `int` | Optional | - |
| `active` | `bool` | Optional | - |
| `inv_active` | `bool` | Optional | - |
| `ws_show` | `bool` | Optional | - |
| `email` | `string` | Optional | - |
| `contact_name` | `string` | Optional | - |
| `ship_address` | `string` | Optional | - |
| `ship_state` | `string` | Optional | - |
| `ship_postal` | `string` | Optional | - |
| `ship_phone` | `string` | Optional | - |
| `ship_poc` | `string` | Optional | - |
| `tax_grouping` | `bool` | Optional | - |
| `label_tax_1` | `string` | Optional | - |
| `label_tax_2` | `string` | Optional | - |
| `label_tax_3` | `string` | Optional | - |
| `label_tax_4` | `string` | Optional | - |
| `label_tax_5` | `string` | Optional | - |
| `wac` | `bool` | Optional | - |
| `ship_address_2` | `string` | Optional | - |
| `master_loc_id` | `int` | Optional | - |
| `street_address` | `string` | Optional | - |
| `country` | `string` | Optional | - |
| `ext` | `string` | Optional | - |
| `amenities` | [`List of MindbodyPublicApiCommonModelsAmenity`](../../doc/models/mindbody-public-api-common-models-amenity.md) | Optional | - |
| `total_number_of_deals` | `long\|int` | Optional | - |
| `total_number_of_ratings` | `int` | Optional | - |
| `average_rating` | `float` | Optional | - |

## Example (as JSON)

```json
{
  "BusinessId": null,
  "SiteId": null,
  "BusinessDescription": null,
  "AdditionalImageURLs": null,
  "FacilitySquareFeet": null,
  "ProSpaFinderSite": null,
  "HasClasses": null,
  "PhoneExtension": null,
  "Action": null,
  "Id": null,
  "Name": null,
  "Address": null,
  "Address2": null,
  "Tax1": null,
  "Tax2": null,
  "Tax3": null,
  "Tax4": null,
  "Tax5": null,
  "Phone": null,
  "City": null,
  "StateProvCode": null,
  "PostalCode": null,
  "Latitude": null,
  "Longitude": null,
  "DistanceInMiles": null,
  "ImageURL": null,
  "Description": null,
  "HasSite": null,
  "CanBook": null,
  "NumberTreatmentRooms": null,
  "Active": null,
  "InvActive": null,
  "WsShow": null,
  "Email": null,
  "ContactName": null,
  "ShipAddress": null,
  "ShipState": null,
  "ShipPostal": null,
  "ShipPhone": null,
  "ShipPOC": null,
  "TaxGrouping": null,
  "LabelTax1": null,
  "LabelTax2": null,
  "LabelTax3": null,
  "LabelTax4": null,
  "LabelTax5": null,
  "WAC": null,
  "ShipAddress2": null,
  "MasterLocId": null,
  "StreetAddress": null,
  "Country": null,
  "Ext": null,
  "Amenities": null,
  "TotalNumberOfDeals": null,
  "TotalNumberOfRatings": null,
  "AverageRating": null
}
```

