
# Mindbody Public Api Dto Models V6 Class Controller Get Class Schedules Response

## Structure

`MindbodyPublicApiDtoModelsV6ClassControllerGetClassSchedulesResponse`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `paginationResponse` | [`?MindbodyPublicApiDtoModelsV6PaginationResponse`](../../doc/models/mindbody-public-api-dto-models-v6-pagination-response.md) | Optional | - | getPaginationResponse(): ?MindbodyPublicApiDtoModelsV6PaginationResponse | setPaginationResponse(?MindbodyPublicApiDtoModelsV6PaginationResponse paginationResponse): void |
| `classSchedules` | [`?(MindbodyPublicApiDtoModelsV6ClassSchedule[])`](../../doc/models/mindbody-public-api-dto-models-v6-class-schedule.md) | Optional | Contains information about the class schedules. | getClassSchedules(): ?array | setClassSchedules(?array classSchedules): void |

## Example (as JSON)

```json
{
  "PaginationResponse": null,
  "ClassSchedules": null
}
```

