
# Mindbody Public Api Dto Models V6 Discount

Discount for a promo code

## Structure

`MindbodyPublicApiDtoModelsV6Discount`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `type` | `?string` | Optional | Type of discount percentage/amount | getType(): ?string | setType(?string type): void |
| `amount` | `?float` | Optional | Amount of discount | getAmount(): ?float | setAmount(?float amount): void |

## Example (as JSON)

```json
{
  "Type": null,
  "Amount": null
}
```

