
# Mindbody Public Api Common Models Availability

## Structure

`MindbodyPublicApiCommonModelsAvailability`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `int` | Optional | - |
| `staff` | [`MindbodyPublicApiCommonModelsStaff`](../../doc/models/mindbody-public-api-common-models-staff.md) | Optional | - |
| `session_type` | [`MindbodyPublicApiCommonModelsSessionType`](../../doc/models/mindbody-public-api-common-models-session-type.md) | Optional | - |
| `programs` | [`List of MindbodyPublicApiCommonModelsProgram`](../../doc/models/mindbody-public-api-common-models-program.md) | Optional | - |
| `start_date_time` | `datetime` | Optional | - |
| `end_date_time` | `datetime` | Optional | - |
| `bookable_end_date_time` | `datetime` | Optional | - |
| `location` | [`MindbodyPublicApiCommonModelsLocation`](../../doc/models/mindbody-public-api-common-models-location.md) | Optional | - |
| `prep_time` | `int` | Optional | - |
| `finish_time` | `int` | Optional | - |

## Example (as JSON)

```json
{
  "Id": null,
  "Staff": null,
  "SessionType": null,
  "Programs": null,
  "StartDateTime": null,
  "EndDateTime": null,
  "BookableEndDateTime": null,
  "Location": null,
  "PrepTime": null,
  "FinishTime": null
}
```

