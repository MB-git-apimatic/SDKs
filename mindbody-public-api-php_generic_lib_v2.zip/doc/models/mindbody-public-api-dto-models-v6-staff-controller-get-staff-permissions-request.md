
# Mindbody Public Api Dto Models V6 Staff Controller Get Staff Permissions Request

## Structure

`MindbodyPublicApiDtoModelsV6StaffControllerGetStaffPermissionsRequest`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `staffId` | `int` | Required | The ID of the staff member whose permissions you want to return. | getStaffId(): int | setStaffId(int staffId): void |

## Example (as JSON)

```json
{
  "StaffId": 156
}
```

