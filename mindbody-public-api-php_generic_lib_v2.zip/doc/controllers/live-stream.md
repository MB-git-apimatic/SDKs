# Live Stream

```php
$liveStreamController = $client->getLiveStreamController();
```

## Class Name

`LiveStreamController`


# Live Stream Generate Signed Live Stream Url

Create an encrypted link to VWP live stream for third party integration customer.

```php
function liveStreamGenerateSignedLiveStreamUrl(
    MindbodyPublicApiDtoModelsV6LiveStreamControllerGenerateSignedLiveStreamUrlRequest $request,
    string $siteId,
    string $version,
    ?string $authorization = null
): MindbodyPublicApiDtoModelsV6LiveStreamControllerGenerateSignedLiveStreamUrlResponse
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `request` | [`MindbodyPublicApiDtoModelsV6LiveStreamControllerGenerateSignedLiveStreamUrlRequest`](../../doc/models/mindbody-public-api-dto-models-v6-live-stream-controller-generate-signed-live-stream-url-request.md) | Body, Required | - |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `version` | `string` | Template, Required | - |
| `authorization` | `?string` | Header, Optional | A staff user authorization token. |

## Response Type

[`MindbodyPublicApiDtoModelsV6LiveStreamControllerGenerateSignedLiveStreamUrlResponse`](../../doc/models/mindbody-public-api-dto-models-v6-live-stream-controller-generate-signed-live-stream-url-response.md)

## Example Usage

```php
$request = new Models\MindbodyPublicApiDtoModelsV6LiveStreamControllerGenerateSignedLiveStreamUrlRequest();
$siteId = '-99';
$version = 'version4';

$result = $liveStreamController->liveStreamGenerateSignedLiveStreamUrl($request, $siteId, $version);
```

