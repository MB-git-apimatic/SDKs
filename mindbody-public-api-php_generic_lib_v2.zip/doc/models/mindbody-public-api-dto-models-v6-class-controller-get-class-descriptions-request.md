
# Mindbody Public Api Dto Models V6 Class Controller Get Class Descriptions Request

## Structure

`MindbodyPublicApiDtoModelsV6ClassControllerGetClassDescriptionsRequest`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `classDescriptionId` | `?int` | Optional | The ID of the requested client. | getClassDescriptionId(): ?int | setClassDescriptionId(?int classDescriptionId): void |
| `programIds` | `?(int[])` | Optional | A list of requested program IDs. | getProgramIds(): ?array | setProgramIds(?array programIds): void |
| `startClassDateTime` | `?\DateTime` | Optional | Filters the results to class descriptions for scheduled classes that happen on or after the given date and time. | getStartClassDateTime(): ?\DateTime | setStartClassDateTime(?\DateTime startClassDateTime): void |
| `endClassDateTime` | `?\DateTime` | Optional | Filters the results to class descriptions for scheduled classes that happen before the given date and time. | getEndClassDateTime(): ?\DateTime | setEndClassDateTime(?\DateTime endClassDateTime): void |
| `staffId` | `?int` | Optional | Filters results to class descriptions for scheduled classes taught by the given staff member. | getStaffId(): ?int | setStaffId(?int staffId): void |
| `locationId` | `?int` | Optional | Filters results to classes descriptions for schedule classes as the given location. | getLocationId(): ?int | setLocationId(?int locationId): void |
| `limit` | `?int` | Optional | Number of results to include, defaults to 100 | getLimit(): ?int | setLimit(?int limit): void |
| `offset` | `?int` | Optional | Page offset, defaults to 0. | getOffset(): ?int | setOffset(?int offset): void |

## Example (as JSON)

```json
{
  "ClassDescriptionId": null,
  "ProgramIds": null,
  "StartClassDateTime": null,
  "EndClassDateTime": null,
  "StaffId": null,
  "LocationId": null,
  "Limit": null,
  "Offset": null
}
```

