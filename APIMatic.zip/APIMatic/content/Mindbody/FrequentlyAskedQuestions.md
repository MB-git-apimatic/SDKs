﻿<h2 id="faq">Frequently Asked Questions</h2>
<script type="text/javascript">
    monitor('faq');
</script>

This section provides answers to questions that we hear frequently from  developers and the business owners whose businesses they integrate with.


#### What is the Mindbody Public Application Programming Interface?

The Mindbody Public Application Programming Interface (Public API) is comprised of resources that third-party developers can use to pull data from a business using the Mindbody software. The Public API can be used to output the data from a business to the main website of the business. Security and access are ensured through access-control measures, and accountability is tracked using an auditing system.

The Mindbody Public API works with any language that has an HTTP library. Requests use standard HTTP verbs such as GET, POST, and DELETE. JSON is returned and accepted by all endpoints. The Public API uses the JSON data types defined by W3Schools. REST-like endpoints provide access to Mindbody business databases. You can use our Public API to retrieve JSON data. For example, if you want to get class visits, you can call an endpoint in the Public API called `GetClassVisits` that returns the requested visits in JSON. Since the data is returned in a standardized format, you can then integrate it directly into a business website or a third-party application. The Mindbody Public APIs gives you the ability to customize business data exactly as a business owner desires.

The Public API's main goal is to allow easy bi-directional integration with third-party developer applications. Our Public API strives to allow the broadest possible compatibility with the least amount of development time. 

The Public API resource documentation describes requests and responses in detail for each endpoint.

####How does Mindbody charge developer accounts for using the Public API?

Testing in our sandbox test site is always free. However, when you integrate with a live site or sites, there is a fee of $11 per integration, per location that entitles you to make @FeatureFlagHelper.FreeCallCount Public API calls per day, per location. Every call over @FeatureFlagHelper.FreeCallCount costs an additional 1/3 cent each. 

For integrations that aggregate and/or sell services sourced from multiple Mindbody subscribers, there is an additional charge of $1.20 per booking fee for class bookings, and $2.40 per appointment booking. These fees are not associated with most accounts.

When a business owner activates the integration of an active developer account with clients, the completion of the activation process results in a charge to the developer of $11 per integration, per location for the month in which the owner activates the integration.  This occurs because clicking the activation link in the process triggers a `GetActivationCode` API call, which counts as a call to the `SiteId` and causes the charge.  For more information about the activation process, see the process detailed in [Getting Started](#getting-started) or refer to the customer support article <a href='https://support.mindbodyonline.com/s/article/Setting-up-an-API-integration?language=en_US'>Setting up an API integration</a>.

To be charged, a developer account must be connected to a business as well as make at least one API call within the billing period. If a business makes no API calls to an integration during a month, then there is no charge to the developer account for that business for that month. 

For example, if a business owner with two locations activates an integration in May, but no other API calls are made, then the developer account is charged $22 ($11 per integration, per location) for the month of May.  If neither of the locations make any API calls to the integration during June, the developer account is not charged any fee for that client for the month of June.

#### Who can use the Public APIs?

As of January 1, 2018, the Mindbody Public API is available to developers who are partnering with Mindbody business owners (subscribers) on all subscription levels.

#### How can subscribers customize Mindbody sites to look like their business websites?

Subscribers (business owners) need to have each application developer sign up for a developer account in our developer's portal. Once the developer has joined the program and the subscriber has authorized the developer to access the site data using an activation link or code, the developer can use the Public API to write a custom application that can output live data from your Mindbody site to the main business website.

Some third-party developers may try different ways to get Mindbody data onto business websites, such as hacking the style sheet in our pages, which we don't officially support, or using iFrames, which are not related to Apple and are no longer supported by Mindbody. The only correct way to integrate with our data is to sign up for a developer account and use our Public API.

See [Getting Started](#getting-started) for the details of the process.

#### What can a developer do with the Mindbody Public API?

A developer can use the Public API to write custom software that integrates with a business website using data from a Mindbody account. A third-party application can perform a variety of activities using site data, including the following:<ul><li>Display a class or appointment schedule</li><li>Add clients into any of the services</li><li>Access client information</li><li>Manage client data</li><li>Complete sales for services and retail products</li><li>Add and retrieve staff profile information and permissions</li><li>Allow clients to purchase contracts and autopays with credit cards</li></ul>

For example, if you want an application to get a class schedule, a developer can call the Mindbody `GetClasses` endpoint to return all the class schedule information for the business. The developer can then customize the business data as desired and output the live data from the subscriber's Mindbody software to the subscriber's main website.

#### How can a developer start to use the Mindbody Public API?

See [Getting Started](#getting-started) for step-by-step information about what a developer needs to do.

#### How can I test against the Public API without affecting live data?

Our [Public API Sandbox](https://clients.mindbodyonline.com/ASP/su1.asp?studioid=-99&tg=&vt=&lvl=&stype=&view=&trn=0&page=&catid=&prodid=&date=8%2f16%2f2018&classid=0&prodGroupId=&sSU=&optForwardingLink=&qParam=&justloggedin=&nLgIn=&pMode=0&loc=1) can be used to test Public API requests against test data. The login credentials for the test subscriber owner acccount that is already set up in the sandbox are as follows:<ul><li>Studio ID: **-99**</li><li>Username: **Siteowner**</li><li>Password: **apitest1234**</li></ul>

Note that the sandbox site is refreshed nightly to clear any changes that developers have made while testing.<br>All Public API users also have access to the Test parameter within all calls. This parameter can be set to `true` or `false`.<ul><li>When set to `true`, the request ensures that its parameters are valid without affecting the business database.</li><li>When set to `false`, the request performs as intended and may affect live client data.</li></ul>

For example, when you use the `AddOrUpdateClients` parameter, if you include the `Test` parameter and set it to `true`, client information is not updated when the request is executed, even though the response returns the updated information. If you set the `Test` parameter to `false`, then the request updates the business database with the intended changes.

#### Can I process credit cards through the Public API?

The Mindbody Public API can process credit cards, but this requires that the site ID specified in the request have an active merchant account with Mindbody. TSYS, Bluefin, Elavon, Paysafe, Adyen, and Ezidebit are the only merchant processors that the Public API supports currently, meaning that access is currently limited to clients in the United States, Canada (except Moneris clients), United Kingdom, European Union, Australia, New Zealand, and Hong Kong.<br>You can use the `CheckoutShoppingCart` request to handle credit card processing.

#### Which version of the Public API should I use?

We recommend that you use the latest stable version of the Public API, V6.0.

#### Where can I submit feedback and feature requests for the Public API?

All suggestions and feature requests regarding the Public API should be requested to [Contact API Support](https://support.mindbodyonline.com/s/contactapisupport).

#### How do I contact Public API support?

You may contact the Public API support team by submitting a ticket on <a href="https://support.mindbodyonline.com/s/contactapisupport" target="_new">Contact API Support</a>
        
If you are currently logged in to your developer account, at the top right, click **Support** to bring up the form to submit a ticket. If you are not currently logged into your developer account, log in and then click the **Support** link.

Phone support is not currently available.

If you need help correcting, accessing, and/or transferring your personal data, or if you would like to execute your right to be forgotten, send a request to [Contact API Support](https://support.mindbodyonline.com/s/contactapisupport).

