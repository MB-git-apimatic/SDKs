
# Mindbody Public Api Dto Models V6 Unavailability Plain

## Structure

`MindbodyPublicApiDtoModelsV6UnavailabilityPlain`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `id` | `?int` | Optional | The ID of the unavailability. | getId(): ?int | setId(?int id): void |
| `staffId` | `?int` | Optional | Id of the staff | getStaffId(): ?int | setStaffId(?int staffId): void |
| `startDateTime` | `?\DateTime` | Optional | The date and time the unavailability starts. | getStartDateTime(): ?\DateTime | setStartDateTime(?\DateTime startDateTime): void |
| `endDateTime` | `?\DateTime` | Optional | The date and time the unavailability ends. | getEndDateTime(): ?\DateTime | setEndDateTime(?\DateTime endDateTime): void |
| `description` | `?string` | Optional | A description of the unavailability. | getDescription(): ?string | setDescription(?string description): void |

## Example (as JSON)

```json
{
  "Id": null,
  "StaffId": null,
  "StartDateTime": null,
  "EndDateTime": null,
  "Description": null
}
```

