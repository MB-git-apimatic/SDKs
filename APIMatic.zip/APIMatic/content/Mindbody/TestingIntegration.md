﻿## Testing Your Integration
<script type="text/javascript">
monitor('testing-your-integration');
</script> 

> Example AddClientToClass request using the Test parameter:

:::visible {language=http}
```
curl -X POST \
  https://api.mindbodyonline.com/public/v6/class/addclienttoclass \
  -H 'Content-Type: application/json' \
  -H 'Api-Key: {yourApiKey}' \
  -H 'authorization: {staffUserToken}' \
  -H 'SiteId: {yourSiteId}' \
  -A '{yourAppName}' \
  -d '{
	"ClientId": "{someClientId}",
	"ClassId": {someClassId},
	"Test": true
}'
```
:::

:::visible {language=csharp}
```
var client = new RestClient("https://api.mindbodyonline.com/public/v6/class/addclienttoclass");
var request = new RestRequest(Method.POST);
request.AddHeader("authorization", "{staffUserToken}");
request.AddHeader("SiteId", "{yourSiteId}");
request.AddHeader("Api-Key", "{yourApiKey}");
request.AddParameter("application/json", "{\n\t\"ClientId\": \"{someClientId}\",\n\t\"ClassId\": {someClassId},\n\t\"Test\": true\n}", ParameterType.RequestBody);
IRestResponse response = client.Execute(request);
```
:::

:::visible {language=php}
```
<?php

$request = new HttpRequest();
$request->setUrl('https://api.mindbodyonline.com/public/v6/class/addclienttoclass');
$request->setMethod(HTTP_METH_POST);

$request->setHeaders(array(
  'authorization' => '{staffUserToken}',
  'Content-Type' => 'application/json',
  'SiteId' => '{yourSiteId}',
  'Api-Key' => '{yourApiKey}'
));

$request->setBody('{
	"ClientId": "{someClientId}",
	"ClassId": {someClassId},
	"Test": true
}');

try {
  $response = $request->send();

  echo $response->getBody();
} catch (HttpException $ex) {
  echo $ex;
}
```
:::

:::visible {language=python}
```
import http.client

conn = http.client.HTTPSConnection("api.mindbodyonline.com")

payload = "{\n\t\"ClientId\": \"{someClientId}\",\n\t\"ClassId\": {someClassId},\n\t\"Test\": true\n}"

headers = {
    'Content-Type': "application/json",
	'Api-Key': "{yourApiKey}",
    'SiteId': "{yourSiteId}",
    'authorization': "{staffUserToken}"
    }

conn.request("POST", "/public/v6/class/addclienttoclass", payload, headers)

res = conn.getresponse()
data = res.read()

print(data.decode("utf-8"))
```
:::

:::visible {language=ruby}
```
require 'uri'
require 'net/http'

url = URI("https://api.mindbodyonline.com/public/v6/class/addclienttoclass")

http = Net::HTTP.new(url.host, url.port)
http.use_ssl = true
http.verify_mode = OpenSSL::SSL::VERIFY_NONE

request = Net::HTTP::Post.new(url)
request["Content-Type"] = 'application/json'
request["Api-Key"] = '{yourApiKey}'
request["SiteId"] = '{yourSiteId}'
request["authorization"] = '{staffUserToken}'
request.body = "{\n\t\"ClientId\": \"{someClientId}\",\n\t\"ClassId\": {someClassId},\n\t\"Test\": true\n}"

response = http.request(request)
puts response.read_body
```
:::

Before you implement your integration with your client's live data, it is a good idea to test it in our sandbox. The data in the sandbox is fictitious, but structured in exactly the same way as it would be in an actual business. Your source name can access this account as soon as it is created; you do not need to complete the activation process to access this site. 
 
To log in to the <a href='https://clients.mindbodyonline.com/ASP/su1.asp?studioid=-99&tg=&vt=&lvl=&stype=&view=&trn=0&page=&catid=&prodid=&date=9%2f11%2f2018&classid=0&prodGroupId=&sSU=&optForwardingLink=&qParam=&justloggedin=&nLgIn=&pMode=0&loc=1'>Public API Sandbox</a>, use the following credentials:

**Name** | **Value**
--- | ---
**Studio ID** | -99
**Username** | Siteowner
**Password** | apitest1234

Note the following:

<ul><li>This site is refreshed nightly to clear any changes that were made during the day.</li><li>You cannot use it to test a live credit card sale.</li></ul>

**Test Parameter**

You can also use the <code>test</code> parameter to test any calls that update site data. This parameter can be set to <code>true</code> or <code>false</code>. <ul><li>If set to <code>true</code>, you can ensure that the request is valid without affecting the business database.</li><li>If set to <code>false</code>, the request performs as intended and does affect live business data.</li></ul>

For example, if you use the <code>AddClientToClass</code> endpoint and include the <code>test</code> parameter set to <code>true</code>, then the client information is not added when the request is executed, even though the response returns the information as if it was added. If you use the <code>AddClientToClass</code> endpoint and include the <code>test</code> parameter set to <code>false</code>, then the request does add the client to the business database.

