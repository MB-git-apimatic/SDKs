﻿## Purchase a Contract
<script type="text/javascript">
monitor('purchase-a-contract');
</script>

> Step 2: Get the client's existing contract

:::visible {language=http}
```
curl -X GET \
  'https://api.mindbodyonline.com/public/v6/client/clientcontracts?clientId=100000527' \
  -H 'Api-Key: {yourApiKey}' \
  -H 'SiteId: {yourSiteId}' \
  -A '{yourAppName}' 
```
:::

:::visible {language=csharp}
```csharp
var client = new RestClient("https://api.mindbodyonline.com/public/v6/client/clientcontracts?clientId=100000527");
var request = new RestRequest(Method.GET);
request.AddHeader("SiteId", "{yourSiteId}");
request.AddHeader("Api-Key", "{yourApiKey}");
IRestResponse response = client.Execute(request);
```
:::

:::visible {language=php}
```
<?php

$request = new HttpRequest();
$request->setUrl('https://api.mindbodyonline.com/public/v6/client/clientcontracts');
$request->setMethod(HTTP_METH_GET);

$request->setQueryData(array(
  'clientId' => '100000527'
));

$request->setHeaders(array(
  'SiteId' => '{yourSiteId}',
  'Api-Key' => '{yourApiKey}'
));

try {
  $response = $request->send();

  echo $response->getBody();
} catch (HttpException $ex) {
  echo $ex;
}
```
:::

:::visible {language=python}
```
import http.client

conn = http.client.HTTPSConnection("api.mindbodyonline.com")

headers = {
	'Api-Key': "{yourApiKey}",
    'SiteId': "{yourSiteId}"
    }

conn.request("GET", "public/v6/client/clientcontracts", headers=headers)

res = conn.getresponse()
data = res.read()

print(data.decode("utf-8"))
```
:::

:::visible {language=ruby}
```
require 'uri'
require 'net/http'

url = URI("https://api.mindbodyonline.com/public/v6/client/clientcontracts?clientId=100000527")

http = Net::HTTP.new(url.host, url.port)

request = Net::HTTP::Get.new(url)
request["Api-Key"] = '{yourApiKey}'
request["SiteId"] = '{yourSiteId}'

response = http.request(request)
puts response.read_body
```
:::
> Step 3: Get the locations

:::visible {language=http}
```
curl -X GET \
  https://api.mindbodyonline.com/public/v6/site/locations \
  -H 'Api-Key: {yourApiKey}' \
  -H 'SiteId: {yourSiteId}' \
  -A '{yourAppName}'
```
:::

:::visible {language=csharp}
```
var client = new RestClient("https://api.mindbodyonline.com/public/v6/site/locations");
var request = new RestRequest(Method.GET);
request.AddHeader("SiteId", "{yourSiteId}");
request.AddHeader("Api-Key", "{yourApiKey}");
IRestResponse response = client.Execute(request);
```
:::

:::visible {language=php}
```
<?php

$request = new HttpRequest();
$request->setUrl('https://api.mindbodyonline.com/public/v6/site/locations');
$request->setMethod(HTTP_METH_GET);

$request->setHeaders(array(
  'SiteId' => '{yourSiteId}',
  'Api-Key' => '{yourApiKey}'
));

try {
  $response = $request->send();

  echo $response->getBody();
} catch (HttpException $ex) {
  echo $ex;
}
```
:::

:::visible {language=python}
```
import http.client

conn = http.client.HTTPSConnection("api.mindbodyonline.com")

headers = {
	'Api-Key': "{yourApiKey}",
    'SiteId': "{yourSiteId}"
    }

conn.request("GET", "public/v6/site/locations", headers=headers)

res = conn.getresponse()
data = res.read()

print(data.decode("utf-8"))
```
:::

:::visible {language=ruby}
```
require 'uri'
require 'net/http'

url = URI("https://api.mindbodyonline.com/public/v6/site/locations")

http = Net::HTTP.new(url.host, url.port)

request = Net::HTTP::Get.new(url)
request["Api-Key"] = '{yourApiKey}'
request["SiteId"] = '{yourSiteId}'

response = http.request(request)
puts response.read_body
```
:::

> Step 4: Get the contracts

:::visible {language=http}
```
curl -X GET \
  'https://api.mindbodyonline.com/public/v6/sale/contracts?contractIds=3' \
  -H 'Api-Key: {yourApiKey}' \
  -H 'Authorization: {staffAuthToken}' \
  -H 'SiteId: {yourSiteId}' \
  -A '{yourAppName}' 
```
:::

:::visible {language=csharp}
```csharp
var client = new RestClient("https://api.mindbodyonline.com/public/v6/sale/contracts?contractIds=3");
var request = new RestRequest(Method.GET);
request.AddHeader("Authorization", "{staffAuthToken}");
request.AddHeader("SiteId", "{yourSiteId}");
request.AddHeader("Api-Key", "{yourApiKey}");
IRestResponse response = client.Execute(request);
```
:::

:::visible {language=php}
```
<?php

$request = new HttpRequest();
$request->setUrl('https://api.mindbodyonline.com/public/v6/sale/contracts');
$request->setMethod(HTTP_METH_GET);

$request->setQueryData(array(
  'contractIds' => '3'
));

$request->setHeaders(array(
  'Authorization' => '{staffAuthToken}',
  'SiteId' => '{yourSiteId}',
  'Api-Key' => '{yourApiKey}'
));

try {
  $response = $request->send();

  echo $response->getBody();
} catch (HttpException $ex) {
  echo $ex;
}
```
:::

:::visible {language=python}
```
import http.client

conn = http.client.HTTPSConnection("api.mindbodyonline.com")

headers = {
	'Api-Key': "{yourApiKey}",
    'SiteId': "{yourSiteId}",
    'Authorization': "{staffAuthToken}"
    }

conn.request("GET", "public/v6/sale/contracts", headers=headers)

res = conn.getresponse()
data = res.read()

print(data.decode("utf-8"))
```
:::

:::visible {language=ruby}
```
require 'uri'
require 'net/http'

url = URI("https://api.mindbodyonline.com/public/v6/sale/contracts?contractIds=3")

http = Net::HTTP.new(url.host, url.port)

request = Net::HTTP::Get.new(url)
request["Api-Key"] = '{yourApiKey}'
request["SiteId"] = '{yourSiteId}'
request["Authorization"] = '{staffAuthToken}'

response = http.request(request)
puts response.read_body
```
:::
> Step 5: Purchase the contract

:::visible {language=http}
```
curl -X POST \
  https://api.mindbodyonline.com/public/v6/sale/purchasecontract \
  -H 'Content-Type: application/json' \
  -H 'Api-Key: {yourApiKey}' \
  -H 'Authorization: {staffAuthToken}' \
  -H 'SiteId: {yourSiteId}' \
  -A '{yourAppName}' \
  -d '{
	"Test": false,
	"LocationId": 1,
	"ClientId": "100000527",
	"ContractID": "3",
	"FirstPaymentOccurs": "Instant",
	"CreditCardInfo":{
		"CreditCardNumber": "4111111111111111",
		"ExpMonth": "12",
		"ExpYear": "2019",
		"BillingName": "John Doe",
		"BillingAddress": "123 Lake Dr",
		"BillingCity": "San Luis Obispo",
		"BillingState": "CA",
		"BillingPostalCode": "93405"
	}
}'
```
:::

:::visible {language=csharp}
```csharp
var client = new RestClient("https://api.mindbodyonline.com/public/v6/sale/purchasecontract");
var request = new RestRequest(Method.POST);
request.AddHeader("Authorization", "{staffAuthToken}");
request.AddHeader("SiteId", "{yourSiteId}");
request.AddHeader("Api-Key", "{yourApiKey}");
request.AddParameter("application/json", "{\n\t\"Test\": false,\n\t\"LocationId\": 1,\n\t\"ClientId\": \"100000527\",\n\t\"ContractID\": \"3\",\n\t\"FirstPaymentOccurs\": \"Instant\",\n\t\"CreditCardInfo\":{\n\t\t\"CreditCardNumber\": \"4111111111111111\",\n\t\t\"ExpMonth\": \"12\",\n\t\t\"ExpYear\": \"2019\",\n\t\t\"BillingName\": \"John Doe\",\n\t\t\"BillingAddress\": \"123 Lake Dr\",\n\t\t\"BillingCity\": \"San Luis Obispo\",\n\t\t\"BillingState\": \"CA\",\n\t\t\"BillingPostalCode\": \"93405\"\n\t}\n}", ParameterType.RequestBody);
IRestResponse response = client.Execute(request);
```
:::

:::visible {language=php}
```
<?php

$request = new HttpRequest();
$request->setUrl('https://api.mindbodyonline.com/public/v6/sale/purchasecontract');
$request->setMethod(HTTP_METH_POST);

$request->setHeaders(array(
  'Authorization' => '{staffAuthToken}',
  'Content-Type' => 'application/json',
  'SiteId' => '{yourSiteId}',
  'Api-Key' => '{yourApiKey}'
));

$request->setBody('{
	"Test": false,
	"LocationId": 1,
	"ClientId": "100000527",
	"ContractID": "3",
	"FirstPaymentOccurs": "Instant",
	"CreditCardInfo":{
		"CreditCardNumber": "4111111111111111",
		"ExpMonth": "12",
		"ExpYear": "2019",
		"BillingName": "John Doe",
		"BillingAddress": "123 Lake Dr",
		"BillingCity": "San Luis Obispo",
		"BillingState": "CA",
		"BillingPostalCode": "93405"
	}
}');

try {
  $response = $request->send();

  echo $response->getBody();
} catch (HttpException $ex) {
  echo $ex;
}
```
:::

:::visible {language=python}
```
import http.client

conn = http.client.HTTPSConnection("api.mindbodyonline.com")

payload = "{\n\t\"Test\": false,\n\t\"LocationId\": 1,\n\t\"ClientId\": \"100000527\",\n\t\"ContractID\": \"3\",\n\t\"FirstPaymentOccurs\": \"Instant\",\n\t\"CreditCardInfo\":{\n\t\t\"CreditCardNumber\": \"4111111111111111\",\n\t\t\"ExpMonth\": \"12\",\n\t\t\"ExpYear\": \"2019\",\n\t\t\"BillingName\": \"John Doe\",\n\t\t\"BillingAddress\": \"123 Lake Dr\",\n\t\t\"BillingCity\": \"San Luis Obispo\",\n\t\t\"BillingState\": \"CA\",\n\t\t\"BillingPostalCode\": \"93405\"\n\t}\n}"

headers = {
    'Content-Type': "application/json",
	'Api-Key': "{yourApiKey}",
    'SiteId': "{yourSiteId}",
    'Authorization': "{staffAuthToken}"
    }

conn.request("POST", "public/v6/sale/purchasecontract", payload, headers)

res = conn.getresponse()
data = res.read()

print(data.decode("utf-8"))
```
:::

:::visible {language=ruby}
```
require 'uri'
require 'net/http'

url = URI("https://api.mindbodyonline.com/public/v6/sale/purchasecontract")

http = Net::HTTP.new(url.host, url.port)

request = Net::HTTP::Post.new(url)
request["Content-Type"] = 'application/json'
request["Api-Key"] = '{yourApiKey}'
request["SiteId"] = '{yourSiteId}'
request["Authorization"] = '{staffAuthToken}'
request.body = "{\n\t\"Test\": false,\n\t\"LocationId\": 1,\n\t\"ClientId\": \"100000527\",\n\t\"ContractID\": \"3\",\n\t\"FirstPaymentOccurs\": \"Instant\",\n\t\"CreditCardInfo\":{\n\t\t\"CreditCardNumber\": \"4111111111111111\",\n\t\t\"ExpMonth\": \"12\",\n\t\t\"ExpYear\": \"2019\",\n\t\t\"BillingName\": \"John Doe\",\n\t\t\"BillingAddress\": \"123 Lake Dr\",\n\t\t\"BillingCity\": \"San Luis Obispo\",\n\t\t\"BillingState\": \"CA\",\n\t\t\"BillingPostalCode\": \"93405\"\n\t}\n}"

response = http.request(request)
puts response.read_body
```
:::

<h3 class="toc-ignore">Summary</h3>
This tutorial demonstrates how a staff member can purchase a contract for a client.
<h3 class="toc-ignore">Workflow</h3>
<p>To perform this workflow:</p> 
<ul><li>The business must have created the contract.</li><li>You must know the location ID, client ID, and contract ID that you want to use.</li><li>The client must be able to pay with either a new credit card or stored credit card.</li></ul><p>Note that you need to determine the client ID from your own application, as the Mindbody Public API does not validate client logins.</p>
<ol class="step-list">
		<li id="fpb1"><p>Get a user authentication token for the staff member by passing the login credentials to the authentication endpoint. For all following steps, put the token you receive into the <code>Authorization</code> header formatted as <code>Bearer {authToken}</code>.<br><br>For a description of the user authentication process, see <a href="#user-tokens">User Tokens</a>.</li>
		<li id="fpb2">Use the <a href="#get-client-contracts">GetClientContracts</a> endpoint to get the client's existing contract information.</li>
	<li id="fpb3">Use the <a href="#get-locations">GetLocations</a> endpoint to get the location ID.</li>
	<li id="fpb4">Use the <a href="#get-contracts">GetContracts</a> endpoint to get the contract ID the client would like to purchase.</li>
	<li id="fpb5">Use the <a href="#purchase-contract">PurchaseContract</a> endpoint to purchase the contract using the information above.</li>
</ol>

<h4>Note</h4>
Protect yourself from processor fees and credit card fraud.  Remember to always protect your web forms that leverage <a href="#checkout-shopping-cart">POST CheckoutShoppingCart</a>, <a href="#purchase-contract">POST PurchaseContract</a> or <a href="#purchase-gift-card">POST PurchaseGiftCard</a> with a CAPTCHA!

