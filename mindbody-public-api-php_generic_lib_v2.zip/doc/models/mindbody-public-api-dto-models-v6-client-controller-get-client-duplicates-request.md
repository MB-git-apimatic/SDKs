
# Mindbody Public Api Dto Models V6 Client Controller Get Client Duplicates Request

## Structure

`MindbodyPublicApiDtoModelsV6ClientControllerGetClientDuplicatesRequest`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `firstName` | `?string` | Optional | The client first name to match on when searching for duplicates. | getFirstName(): ?string | setFirstName(?string firstName): void |
| `lastName` | `?string` | Optional | The client last name to match on when searching for duplicates. | getLastName(): ?string | setLastName(?string lastName): void |
| `email` | `?string` | Optional | The client email to match on when searching for duplicates. | getEmail(): ?string | setEmail(?string email): void |
| `limit` | `?int` | Optional | Number of results to include, defaults to 100 | getLimit(): ?int | setLimit(?int limit): void |
| `offset` | `?int` | Optional | Page offset, defaults to 0. | getOffset(): ?int | setOffset(?int offset): void |

## Example (as JSON)

```json
{
  "FirstName": null,
  "LastName": null,
  "Email": null,
  "Limit": null,
  "Offset": null
}
```

