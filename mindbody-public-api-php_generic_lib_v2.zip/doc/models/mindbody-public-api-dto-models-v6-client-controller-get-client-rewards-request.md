
# Mindbody Public Api Dto Models V6 Client Controller Get Client Rewards Request

## Structure

`MindbodyPublicApiDtoModelsV6ClientControllerGetClientRewardsRequest`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `clientId` | `string` | Required | The ID of the client whose reward information is being requested. | getClientId(): string | setClientId(string clientId): void |
| `startDate` | `?\DateTime` | Optional | Filters the results to rewards transactions created on or after this date.<br /><br>Default: **the current date** | getStartDate(): ?\DateTime | setStartDate(?\DateTime startDate): void |
| `endDate` | `?\DateTime` | Optional | Filters the results to rewards transactions created before this date.<br /><br>Default: **the start date** | getEndDate(): ?\DateTime | setEndDate(?\DateTime endDate): void |
| `limit` | `?int` | Optional | Number of results to include, defaults to 100 | getLimit(): ?int | setLimit(?int limit): void |
| `offset` | `?int` | Optional | Page offset, defaults to 0. | getOffset(): ?int | setOffset(?int offset): void |

## Example (as JSON)

```json
{
  "ClientId": "ClientId6",
  "StartDate": null,
  "EndDate": null,
  "Limit": null,
  "Offset": null
}
```

