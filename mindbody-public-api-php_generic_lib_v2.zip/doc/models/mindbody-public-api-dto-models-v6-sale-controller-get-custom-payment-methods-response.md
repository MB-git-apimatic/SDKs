
# Mindbody Public Api Dto Models V6 Sale Controller Get Custom Payment Methods Response

## Structure

`MindbodyPublicApiDtoModelsV6SaleControllerGetCustomPaymentMethodsResponse`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `paginationResponse` | [`?MindbodyPublicApiDtoModelsV6PaginationResponse`](../../doc/models/mindbody-public-api-dto-models-v6-pagination-response.md) | Optional | - | getPaginationResponse(): ?MindbodyPublicApiDtoModelsV6PaginationResponse | setPaginationResponse(?MindbodyPublicApiDtoModelsV6PaginationResponse paginationResponse): void |
| `paymentMethods` | [`?(MindbodyPublicApiDtoModelsV6CustomPaymentMethod[])`](../../doc/models/mindbody-public-api-dto-models-v6-custom-payment-method.md) | Optional | Contains information about the custom payment methods. | getPaymentMethods(): ?array | setPaymentMethods(?array paymentMethods): void |

## Example (as JSON)

```json
{
  "PaginationResponse": null,
  "PaymentMethods": null
}
```

