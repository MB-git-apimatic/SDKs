
# Mindbody Public Api Dto Models V6 Client Controller Get Client Account Balances Request

## Structure

`MindbodyPublicApiDtoModelsV6ClientControllerGetClientAccountBalancesRequest`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `balanceDate` | `?\DateTime` | Optional | The date you want a balance relative to.<br>Default: **the current date** | getBalanceDate(): ?\DateTime | setBalanceDate(?\DateTime balanceDate): void |
| `classId` | `?int` | Optional | The class ID of the event for which you want a balance. | getClassId(): ?int | setClassId(?int classId): void |
| `clientIds` | `string[]` | Required | The list of clients IDs for which you want account balances. | getClientIds(): array | setClientIds(array clientIds): void |
| `limit` | `?int` | Optional | Number of results to include, defaults to 100 | getLimit(): ?int | setLimit(?int limit): void |
| `offset` | `?int` | Optional | Page offset, defaults to 0. | getOffset(): ?int | setOffset(?int offset): void |

## Example (as JSON)

```json
{
  "BalanceDate": null,
  "ClassId": null,
  "ClientIds": [
    "ClientIds3",
    "ClientIds4"
  ],
  "Limit": null,
  "Offset": null
}
```

