
# Mindbody Public Api Dto Models V6 Class Controller Get Class Visits Request

## Structure

`MindbodyPublicApiDtoModelsV6ClassControllerGetClassVisitsRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `class_id` | `long\|int` | Optional | The class ID. |
| `last_modified_date` | `datetime` | Optional | When included in the request, only records modified on or after the `LastModifiedDate` specified are included in the response. |

## Example (as JSON)

```json
{
  "ClassID": null,
  "LastModifiedDate": null
}
```

