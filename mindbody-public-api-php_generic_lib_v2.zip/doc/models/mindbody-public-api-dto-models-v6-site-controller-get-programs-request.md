
# Mindbody Public Api Dto Models V6 Site Controller Get Programs Request

## Structure

`MindbodyPublicApiDtoModelsV6SiteControllerGetProgramsRequest`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `scheduleType` | [`?string (ScheduleType3Enum)`](../../doc/models/schedule-type-3-enum.md) | Optional | A schedule type used to filter the returned results. Possible values are:<br><br>* All<br>* Class<br>* Enrollment<br>* Appointment<br>* Resource<br>* Media<br>* Arrival | getScheduleType(): ?string | setScheduleType(?string scheduleType): void |
| `onlineOnly` | `?bool` | Optional | If `true`, filters results to show only those programs that are shown online.<br /><br>If `false`, all programs are returned.<br /><br>Default: **false** | getOnlineOnly(): ?bool | setOnlineOnly(?bool onlineOnly): void |
| `limit` | `?int` | Optional | Number of results to include, defaults to 100 | getLimit(): ?int | setLimit(?int limit): void |
| `offset` | `?int` | Optional | Page offset, defaults to 0. | getOffset(): ?int | setOffset(?int offset): void |

## Example (as JSON)

```json
{
  "ScheduleType": null,
  "OnlineOnly": null,
  "Limit": null,
  "Offset": null
}
```

