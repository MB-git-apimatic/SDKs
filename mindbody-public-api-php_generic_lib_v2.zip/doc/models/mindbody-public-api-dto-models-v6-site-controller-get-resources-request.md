
# Mindbody Public Api Dto Models V6 Site Controller Get Resources Request

## Structure

`MindbodyPublicApiDtoModelsV6SiteControllerGetResourcesRequest`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `sessionTypeIds` | `?(int[])` | Optional | List of session type IDs.<br /><br>Default: **all** | getSessionTypeIds(): ?array | setSessionTypeIds(?array sessionTypeIds): void |
| `locationId` | `?int` | Optional | The location of the resource. This parameter is ignored if `EndDateTime` or `LocationID` is not set.<br /><br>Default: **all** | getLocationId(): ?int | setLocationId(?int locationId): void |
| `startDateTime` | `?\DateTime` | Optional | The time the resource starts. This parameter is ignored if `EndDateTime` or `LocationID` is not set. | getStartDateTime(): ?\DateTime | setStartDateTime(?\DateTime startDateTime): void |
| `endDateTime` | `?\DateTime` | Optional | The time the resource ends. This parameter is ignored if `EndDateTime` or `LocationID` is not set. | getEndDateTime(): ?\DateTime | setEndDateTime(?\DateTime endDateTime): void |
| `limit` | `?int` | Optional | Number of results to include, defaults to 100 | getLimit(): ?int | setLimit(?int limit): void |
| `offset` | `?int` | Optional | Page offset, defaults to 0. | getOffset(): ?int | setOffset(?int offset): void |

## Example (as JSON)

```json
{
  "SessionTypeIds": null,
  "LocationId": null,
  "StartDateTime": null,
  "EndDateTime": null,
  "Limit": null,
  "Offset": null
}
```

