# User Token

```python
user_token_controller = client.user_token
```

## Class Name

`UserTokenController`

## Methods

* [User Token Issue](../../doc/controllers/user-token.md#user-token-issue)
* [User Token Revoke](../../doc/controllers/user-token.md#user-token-revoke)


# User Token Issue

Get a staff user token.

```python
def user_token_issue(self,
                    request,
                    site_id,
                    version)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `request` | [`MindbodyPublicApiDtoModelsV6UserTokenControllerIssueRequest`](../../doc/models/mindbody-public-api-dto-models-v6-user-token-controller-issue-request.md) | Body, Required | - |
| `site_id` | `string` | Header, Required | ID of the site from which to pull data. |
| `version` | `string` | Template, Required | - |

## Response Type

[`MindbodyPublicApiDtoModelsV6UserTokenControllerIssueResponse`](../../doc/models/mindbody-public-api-dto-models-v6-user-token-controller-issue-response.md)

## Example Usage

```python
request = MindbodyPublicApiDtoModelsV6UserTokenControllerIssueRequest()
site_id = 'siteId8'
version = 'version4'

result = user_token_controller.user_token_issue(request, site_id, version)
```


# User Token Revoke

Revokes the user token in the Authorization header.

```python
def user_token_revoke(self,
                     site_id,
                     version,
                     authorization=None)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `site_id` | `string` | Header, Required | ID of the site from which to pull data. |
| `version` | `string` | Template, Required | - |
| `authorization` | `string` | Header, Optional | A staff user authorization token. |

## Response Type

`object`

## Example Usage

```python
site_id = 'siteId8'
version = 'version4'

result = user_token_controller.user_token_revoke(site_id, version)
```

