# Client

```python
client_controller = client.client
```

## Class Name

`ClientController`

## Methods

* [Client Get Clients](../../doc/controllers/client.md#client-get-clients)
* [Client Get Client Duplicates](../../doc/controllers/client.md#client-get-client-duplicates)
* [Client Get Client Formula Notes](../../doc/controllers/client.md#client-get-client-formula-notes)
* [Client Delete Client Formula Note](../../doc/controllers/client.md#client-delete-client-formula-note)
* [Client Add Formula Note](../../doc/controllers/client.md#client-add-formula-note)
* [Client Upload Client Document](../../doc/controllers/client.md#client-upload-client-document)
* [Client Upload Client Photo](../../doc/controllers/client.md#client-upload-client-photo)
* [Client Get Client Contracts](../../doc/controllers/client.md#client-get-client-contracts)
* [Client Get Client Services](../../doc/controllers/client.md#client-get-client-services)
* [Client Get Client Visits](../../doc/controllers/client.md#client-get-client-visits)
* [Client Get Client Schedule](../../doc/controllers/client.md#client-get-client-schedule)
* [Client Get Active Client Memberships](../../doc/controllers/client.md#client-get-active-client-memberships)
* [Client Get Required Client Fields](../../doc/controllers/client.md#client-get-required-client-fields)
* [Client Get Client Referral Types](../../doc/controllers/client.md#client-get-client-referral-types)
* [Client Get Client Account Balances](../../doc/controllers/client.md#client-get-client-account-balances)
* [Client Get Client Purchases](../../doc/controllers/client.md#client-get-client-purchases)
* [Client Get Client Indexes](../../doc/controllers/client.md#client-get-client-indexes)
* [Client Get Custom Client Fields](../../doc/controllers/client.md#client-get-custom-client-fields)
* [Client Add Contact Log](../../doc/controllers/client.md#client-add-contact-log)
* [Client Update Contact Log](../../doc/controllers/client.md#client-update-contact-log)
* [Client Get Cross Regional Client Associations](../../doc/controllers/client.md#client-get-cross-regional-client-associations)
* [Client Add Client](../../doc/controllers/client.md#client-add-client)
* [Client Update Client](../../doc/controllers/client.md#client-update-client)
* [Client Update Client Visit](../../doc/controllers/client.md#client-update-client-visit)
* [Client Add Arrival](../../doc/controllers/client.md#client-add-arrival)
* [Client Send Password Reset Email](../../doc/controllers/client.md#client-send-password-reset-email)
* [Client Get Contact Logs](../../doc/controllers/client.md#client-get-contact-logs)
* [Client Update Client Service](../../doc/controllers/client.md#client-update-client-service)
* [Client Get Direct Debit Info](../../doc/controllers/client.md#client-get-direct-debit-info)
* [Client Delete Direct Debit Info](../../doc/controllers/client.md#client-delete-direct-debit-info)
* [Client Add Client Direct Debit Info](../../doc/controllers/client.md#client-add-client-direct-debit-info)
* [Client Get Client Rewards](../../doc/controllers/client.md#client-get-client-rewards)
* [Client Update Client Rewards](../../doc/controllers/client.md#client-update-client-rewards)
* [Client Get Client Complete Info](../../doc/controllers/client.md#client-get-client-complete-info)
* [Client Get Contact Log Types](../../doc/controllers/client.md#client-get-contact-log-types)
* [Client Delete Contact Log](../../doc/controllers/client.md#client-delete-contact-log)
* [Client Send Auto Email](../../doc/controllers/client.md#client-send-auto-email)
* [Client Get Active Clients Memberships](../../doc/controllers/client.md#client-get-active-clients-memberships)
* [Client Terminate Contract](../../doc/controllers/client.md#client-terminate-contract)


# Client Get Clients

Get clients.

```python
def client_get_clients(self,
                      site_id,
                      version,
                      authorization=None,
                      request_client_i_ds=None,
                      request_include_inactive=None,
                      request_is_prospect=None,
                      request_last_modified_date=None,
                      request_limit=None,
                      request_offset=None,
                      request_search_text=None,
                      request_unique_ids=None)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `site_id` | `string` | Header, Required | ID of the site from which to pull data. |
| `version` | `string` | Template, Required | - |
| `authorization` | `string` | Header, Optional | A staff user authorization token. |
| `request_client_i_ds` | `List of string` | Query, Optional | The requested client IDs.<br>Default: **all IDs** that the authenticated user’s access level allows. |
| `request_include_inactive` | `bool` | Query, Optional | When `true`, indicates the results to include active and inactive clients.<br /><br>When `false`, indicates that only those clients who are marked as active should be returned. |
| `request_is_prospect` | `bool` | Query, Optional | When `true`, filters the results to include only those clients marked as prospects for the business.<br /><br>When `false`, indicates that only those clients who are not marked prospects should be returned. |
| `request_last_modified_date` | `datetime` | Query, Optional | Filters the results to include only the clients that have been modified on or after this date. |
| `request_limit` | `int` | Query, Optional | Number of results to include, defaults to 100 |
| `request_offset` | `int` | Query, Optional | Page offset, defaults to 0. |
| `request_search_text` | `string` | Query, Optional | Text to use in the search. Can include FirstName, LastName, and Email. Note that user credentials must be provided. |
| `request_unique_ids` | `List of long\|int` | Query, Optional | Filters results to clients with these `UniqueIDs`. This parameter cannot be used with `ClientIDs` or `SearchText`.<br>Default: **all UniqueIDs** that the authenticated user’s access level allows. |

## Response Type

[`MindbodyPublicApiDtoModelsV6ClientControllerGetClientsResponse`](../../doc/models/mindbody-public-api-dto-models-v6-client-controller-get-clients-response.md)

## Example Usage

```python
site_id = 'siteId8'
version = 'version4'

result = client_controller.client_get_clients(site_id, version)
```


# Client Get Client Duplicates

Get client records that would be considered duplicates of the client values passed in.

```python
def client_get_client_duplicates(self,
                                site_id,
                                version,
                                authorization=None,
                                request_email=None,
                                request_first_name=None,
                                request_last_name=None,
                                request_limit=None,
                                request_offset=None)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `site_id` | `string` | Header, Required | ID of the site from which to pull data. |
| `version` | `string` | Template, Required | - |
| `authorization` | `string` | Header, Optional | A staff user authorization token. |
| `request_email` | `string` | Query, Optional | The client email to match on when searching for duplicates. |
| `request_first_name` | `string` | Query, Optional | The client first name to match on when searching for duplicates. |
| `request_last_name` | `string` | Query, Optional | The client last name to match on when searching for duplicates. |
| `request_limit` | `int` | Query, Optional | Number of results to include, defaults to 100 |
| `request_offset` | `int` | Query, Optional | Page offset, defaults to 0. |

## Response Type

[`MindbodyPublicApiDtoModelsV6ClientControllerGetClientDuplicatesResponse`](../../doc/models/mindbody-public-api-dto-models-v6-client-controller-get-client-duplicates-response.md)

## Example Usage

```python
site_id = 'siteId8'
version = 'version4'

result = client_controller.client_get_client_duplicates(site_id, version)
```


# Client Get Client Formula Notes

Get a client's formula notes.

```python
def client_get_client_formula_notes(self,
                                   site_id,
                                   version,
                                   authorization=None,
                                   request_appointment_id=None,
                                   request_client_id=None,
                                   request_limit=None,
                                   request_offset=None)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `site_id` | `string` | Header, Required | ID of the site from which to pull data. |
| `version` | `string` | Template, Required | - |
| `authorization` | `string` | Header, Optional | A staff user authorization token. |
| `request_appointment_id` | `long\|int` | Query, Optional | The appointment ID of the appointment that the formula notes are related to. |
| `request_client_id` | `string` | Query, Optional | The client ID of the client whose formula notes are being requested. |
| `request_limit` | `int` | Query, Optional | Number of results to include, defaults to 100 |
| `request_offset` | `int` | Query, Optional | Page offset, defaults to 0. |

## Response Type

[`MindbodyPublicApiDtoModelsV6ClientControllerGetClientFormulaNotesResponse`](../../doc/models/mindbody-public-api-dto-models-v6-client-controller-get-client-formula-notes-response.md)

## Example Usage

```python
site_id = 'siteId8'
version = 'version4'

result = client_controller.client_get_client_formula_notes(site_id, version)
```


# Client Delete Client Formula Note

Deletes client's formula note.

```python
def client_delete_client_formula_note(self,
                                     request_client_id,
                                     request_formula_note_id,
                                     site_id,
                                     version,
                                     authorization=None,
                                     request_limit=None,
                                     request_offset=None)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `request_client_id` | `string` | Query, Required | The client ID of the client whose formula notes are being requested. |
| `request_formula_note_id` | `long\|int` | Query, Required | The Formula Note ID. |
| `site_id` | `string` | Header, Required | ID of the site from which to pull data. |
| `version` | `string` | Template, Required | - |
| `authorization` | `string` | Header, Optional | A staff user authorization token. |
| `request_limit` | `int` | Query, Optional | Number of results to include, defaults to 100 |
| `request_offset` | `int` | Query, Optional | Page offset, defaults to 0. |

## Response Type

`void`

## Example Usage

```python
request_client_id = 'request.clientId2'
request_formula_note_id = 72
site_id = 'siteId8'
version = 'version4'

result = client_controller.client_delete_client_formula_note(request_client_id, request_formula_note_id, site_id, version)
```


# Client Add Formula Note

```python
def client_add_formula_note(self,
                           request,
                           site_id,
                           version,
                           authorization=None)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `request` | [`MindbodyPublicApiDtoModelsV6ClientControllerAddFormulaNoteRequest`](../../doc/models/mindbody-public-api-dto-models-v6-client-controller-add-formula-note-request.md) | Body, Required | - |
| `site_id` | `string` | Header, Required | ID of the site from which to pull data. |
| `version` | `string` | Template, Required | - |
| `authorization` | `string` | Header, Optional | A staff user authorization token. |

## Response Type

[`MindbodyPublicApiDtoModelsV6ClientControllerFormulaNoteResponse`](../../doc/models/mindbody-public-api-dto-models-v6-client-controller-formula-note-response.md)

## Example Usage

```python
request = MindbodyPublicApiDtoModelsV6ClientControllerAddFormulaNoteRequest()
request.client_id = 'ClientId0'
request.note = 'Note6'
site_id = 'siteId8'
version = 'version4'

result = client_controller.client_add_formula_note(request, site_id, version)
```


# Client Upload Client Document

Returns a string representation of the image byte array. The maximum document size is 1MB.

The maximum size file that can be uploaded is 4 MB.

```python
def client_upload_client_document(self,
                                 request,
                                 site_id,
                                 version,
                                 authorization=None)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `request` | [`MindbodyPublicApiDtoModelsV6ClientControllerUploadClientDocumentRequest`](../../doc/models/mindbody-public-api-dto-models-v6-client-controller-upload-client-document-request.md) | Body, Required | - |
| `site_id` | `string` | Header, Required | ID of the site from which to pull data. |
| `version` | `string` | Template, Required | - |
| `authorization` | `string` | Header, Optional | A staff user authorization token. |

## Response Type

[`MindbodyPublicApiDtoModelsV6ClientControllerUploadClientDocumentResponse`](../../doc/models/mindbody-public-api-dto-models-v6-client-controller-upload-client-document-response.md)

## Example Usage

```python
request = MindbodyPublicApiDtoModelsV6ClientControllerUploadClientDocumentRequest()
request.client_id = 'ClientId0'
request.file = MindbodyPublicApiDtoModelsV6ClientDocument()
request.file.file_name = 'FileName2'
request.file.media_type = 'MediaType2'
request.file.buffer = 'Buffer4'
site_id = 'siteId8'
version = 'version4'

result = client_controller.client_upload_client_document(request, site_id, version)
```


# Client Upload Client Photo

The maximum file size is 4 MB and acceptable file types are:

* bmp
* jpeg
* gif
* tiff
* png

```python
def client_upload_client_photo(self,
                              request,
                              site_id,
                              version,
                              authorization=None)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `request` | [`MindbodyPublicApiDtoModelsV6ClientControllerUploadClientPhotoRequest`](../../doc/models/mindbody-public-api-dto-models-v6-client-controller-upload-client-photo-request.md) | Body, Required | - |
| `site_id` | `string` | Header, Required | ID of the site from which to pull data. |
| `version` | `string` | Template, Required | - |
| `authorization` | `string` | Header, Optional | A staff user authorization token. |

## Response Type

[`MindbodyPublicApiDtoModelsV6ClientControllerUploadClientPhotoResponse`](../../doc/models/mindbody-public-api-dto-models-v6-client-controller-upload-client-photo-response.md)

## Example Usage

```python
request = MindbodyPublicApiDtoModelsV6ClientControllerUploadClientPhotoRequest()
request.bytes = 'Bytes6'
request.client_id = 'ClientId0'
site_id = 'siteId8'
version = 'version4'

result = client_controller.client_upload_client_photo(request, site_id, version)
```


# Client Get Client Contracts

Get contracts that a client has purchased.

```python
def client_get_client_contracts(self,
                               request_client_id,
                               site_id,
                               version,
                               authorization=None,
                               request_client_associated_sites_offset=None,
                               request_cross_regional_lookup=None,
                               request_limit=None,
                               request_offset=None)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `request_client_id` | `string` | Query, Required | The ID of the client. |
| `site_id` | `string` | Header, Required | ID of the site from which to pull data. |
| `version` | `string` | Template, Required | - |
| `authorization` | `string` | Header, Optional | A staff user authorization token. |
| `request_client_associated_sites_offset` | `int` | Query, Optional | Determines how many sites are skipped over when retrieving a client’s cross regional contracts. Used when a client ID is linked to more than ten sites in an organization. Only a maximum of ten site databases are queried when this call is made and `CrossRegionalLookup` is set to `true`. To change which sites are queried, change this offset value.<br>Default: **0** |
| `request_cross_regional_lookup` | `bool` | Query, Optional | When `true`, indicates that the requesting client’s cross regional contracts are returned, if any.<br /><br>When `false`, indicates that cross regional contracts are not returned. |
| `request_limit` | `int` | Query, Optional | Number of results to include, defaults to 100 |
| `request_offset` | `int` | Query, Optional | Page offset, defaults to 0. |

## Response Type

[`MindbodyPublicApiDtoModelsV6ClientControllerGetClientContractsResponse`](../../doc/models/mindbody-public-api-dto-models-v6-client-controller-get-client-contracts-response.md)

## Example Usage

```python
request_client_id = 'request.clientId2'
site_id = 'siteId8'
version = 'version4'

result = client_controller.client_get_client_contracts(request_client_id, site_id, version)
```


# Client Get Client Services

Get pricing options that a client has purchased.

```python
def client_get_client_services(self,
                              request_client_id,
                              site_id,
                              version,
                              authorization=None,
                              request_class_id=None,
                              request_client_associated_sites_offset=None,
                              request_cross_regional_lookup=None,
                              request_end_date=None,
                              request_ignore_cross_regional_site_limit=None,
                              request_limit=None,
                              request_location_ids=None,
                              request_offset=None,
                              request_program_ids=None,
                              request_session_type_id=None,
                              request_show_active_only=None,
                              request_start_date=None,
                              request_visit_count=None)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `request_client_id` | `string` | Query, Required | The ID of the client to query. The results are a list of pricing options that the client has purchased. Note that “service” and “pricing option” are synonymous in this section of the documentation. |
| `site_id` | `string` | Header, Required | ID of the site from which to pull data. |
| `version` | `string` | Template, Required | - |
| `authorization` | `string` | Header, Optional | A staff user authorization token. |
| `request_class_id` | `int` | Query, Optional | Filters results to only those pricing options that can be used to pay for this class. |
| `request_client_associated_sites_offset` | `int` | Query, Optional | Used to retrieve a client’s pricing options from multiple sites within an organization when the client is associated with more than ten sites. To change which ten sites are searched, change this offset value. A value of 0 means that no sites are skipped and the first ten sites are returned. You can use the `CrossRegionalClientAssociations` value from `GET CrossRegionalClientAssociations` to determine how many sites the client is associated with. Note that you must always have `CrossRegionalLookup` set to `true` to use this parameter.<br /><br>Default: **0**<br><br>For example, if a client is associated with 25 sites, you need to call `GetClientServices` three times, as follows:<br><br>* Use `GET CrossRegionalClientAssociations` to determine how many sites a client is associated with, which tells you how many additional calls you need to make.<br>* Either omit `ClientAssociatedSitesOffset` or set it to 0 to return the client’s services (pricing options) from sites 1-10.<br>* Set `ClientAssociatedSitesOffset` to 10 to return the client pricing options from sites 11-20<br>* Set `ClientAssociatedSitesOffset` to 20 to return the client pricing options from sites 21-25 |
| `request_cross_regional_lookup` | `bool` | Query, Optional | Used to retrieve a client’s pricing options from multiple sites within an organization. When included and set to `true`, it searches a maximum of ten sites with which this client is associated. When a client is associated with more than ten sites, use `ClientAssociatedSitesOffset` as many times as needed to search the additional sites with which the client is associated. You can use the `CrossRegionalClientAssociations` value from `GET CrossRegionalClientAssociations` to determine how many sites the client is associated with. Note that a `SiteID` is returned and populated in the `ClientServices` response when `CrossRegionalLookup` is set to `true`.<br>Default: **false** |
| `request_end_date` | `datetime` | Query, Optional | Filters results to pricing options that are valid on or before this date. |
| `request_ignore_cross_regional_site_limit` | `bool` | Query, Optional | Used to specify if the number of cross regional sites used to search for client’s pricing options should be ignored.<br>Default: **false** |
| `request_limit` | `int` | Query, Optional | Number of results to include, defaults to 100 |
| `request_location_ids` | `List of int` | Query, Optional | Filters results to pricing options that can be used at the listed location IDs. |
| `request_offset` | `int` | Query, Optional | Page offset, defaults to 0. |
| `request_program_ids` | `List of int` | Query, Optional | Filters results to pricing options that belong to one of the given program IDs. |
| `request_session_type_id` | `int` | Query, Optional | Filters results to pricing options that will pay for the given session type ID. Use this to find pricing options that will pay for a specific appointment type. |
| `request_show_active_only` | `bool` | Query, Optional | When `true`, includes active services only.<br>Default: **false** |
| `request_start_date` | `datetime` | Query, Optional | Filters results to pricing options that are valid on or after this date. |
| `request_visit_count` | `int` | Query, Optional | A filter on the minimum number of visits a service can pay for. |

## Response Type

[`MindbodyPublicApiDtoModelsV6ClientControllerGetClientServicesResponse`](../../doc/models/mindbody-public-api-dto-models-v6-client-controller-get-client-services-response.md)

## Example Usage

```python
request_client_id = 'request.clientId2'
site_id = 'siteId8'
version = 'version4'

result = client_controller.client_get_client_services(request_client_id, site_id, version)
```


# Client Get Client Visits

Get a client's visit history.

```python
def client_get_client_visits(self,
                            request_client_id,
                            site_id,
                            version,
                            authorization=None,
                            request_client_associated_sites_offset=None,
                            request_cross_regional_lookup=None,
                            request_end_date=None,
                            request_limit=None,
                            request_offset=None,
                            request_start_date=None,
                            request_unpaids_only=None)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `request_client_id` | `string` | Query, Required | The ID of the requested client. |
| `site_id` | `string` | Header, Required | ID of the site from which to pull data. |
| `version` | `string` | Template, Required | - |
| `authorization` | `string` | Header, Optional | A staff user authorization token. |
| `request_client_associated_sites_offset` | `int` | Query, Optional | The number of sites to skip when returning the site associated with a client. |
| `request_cross_regional_lookup` | `bool` | Query, Optional | When `true`, indicates that past and scheduled client visits across all sites in the region are returned.<br /><br>When `false`, indicates that only visits at the current site are returned. |
| `request_end_date` | `datetime` | Query, Optional | The date past which class visits are not returned.<br>Default: **today’s date** |
| `request_limit` | `int` | Query, Optional | Number of results to include, defaults to 100 |
| `request_offset` | `int` | Query, Optional | Page offset, defaults to 0. |
| `request_start_date` | `datetime` | Query, Optional | The date before which class visits are not returned.<br>Default: **the end date** |
| `request_unpaids_only` | `bool` | Query, Optional | When `true`, indicates that only visits that have not been paid for are returned.<br /><br>When `false`, indicates that all visits are returned, regardless of whether they have been paid for.<br /><br>Default: **false** |

## Response Type

[`MindbodyPublicApiDtoModelsV6ClientControllerGetClientVisitsResponse`](../../doc/models/mindbody-public-api-dto-models-v6-client-controller-get-client-visits-response.md)

## Example Usage

```python
request_client_id = 'request.clientId2'
site_id = 'siteId8'
version = 'version4'

result = client_controller.client_get_client_visits(request_client_id, site_id, version)
```


# Client Get Client Schedule

Gets a client's schedule history.

```python
def client_get_client_schedule(self,
                              request_client_id,
                              site_id,
                              version,
                              authorization=None,
                              request_client_associated_sites_offset=None,
                              request_cross_regional_lookup=None,
                              request_end_date=None,
                              request_limit=None,
                              request_offset=None,
                              request_start_date=None)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `request_client_id` | `string` | Query, Required | The ID of the requested client. |
| `site_id` | `string` | Header, Required | ID of the site from which to pull data. |
| `version` | `string` | Template, Required | - |
| `authorization` | `string` | Header, Optional | A staff user authorization token. |
| `request_client_associated_sites_offset` | `int` | Query, Optional | The number of sites to skip when returning the site associated with a client. |
| `request_cross_regional_lookup` | `bool` | Query, Optional | When `true`, indicates that past and scheduled client visits across all sites in the region are returned.<br>When `false`, indicates that only visits at the current site are returned. |
| `request_end_date` | `datetime` | Query, Optional | The date past which class visits are not returned.<br>Default is today’s date |
| `request_limit` | `int` | Query, Optional | Number of results to include, defaults to 100 |
| `request_offset` | `int` | Query, Optional | Page offset, defaults to 0. |
| `request_start_date` | `datetime` | Query, Optional | The date before which class visits are not returned.<br>Default is the end date |

## Response Type

[`MindbodyPublicApiDtoModelsV6ClientControllerGetClientScheduleResponse`](../../doc/models/mindbody-public-api-dto-models-v6-client-controller-get-client-schedule-response.md)

## Example Usage

```python
request_client_id = 'request.clientId2'
site_id = 'siteId8'
version = 'version4'

result = client_controller.client_get_client_schedule(request_client_id, site_id, version)
```


# Client Get Active Client Memberships

Get a client's active memberships.

```python
def client_get_active_client_memberships(self,
                                        request_client_id,
                                        site_id,
                                        version,
                                        authorization=None,
                                        request_client_associated_sites_offset=None,
                                        request_cross_regional_lookup=None,
                                        request_limit=None,
                                        request_location_id=None,
                                        request_offset=None)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `request_client_id` | `string` | Query, Required | The ID of the client whose membership was requested. |
| `site_id` | `string` | Header, Required | ID of the site from which to pull data. |
| `version` | `string` | Template, Required | - |
| `authorization` | `string` | Header, Optional | A staff user authorization token. |
| `request_client_associated_sites_offset` | `int` | Query, Optional | Used to retrieve a client’s memberships from multiple sites within an organization when the client is associated with more than ten sites. To change which ten sites are searched, change this offset value. A value of 0 means that no sites are skipped and the first ten sites are returned. You can use the `CrossRegionalClientAssociations` value from `GET CrossRegionalClientAssociations` to determine how many sites the client is associated with. Note that you must always have `CrossRegionalLookup` set to `true` to use this parameter.<br /><br>Default: **0**<br><br>For example, if a client is associated with 25 sites, you need to call `GetClientServices` three times, as follows:<br><br>* Use `GET CrossRegionalClientAssociations` to determine how many sites a client is associated with, which tells you how many additional calls you need to make.<br>* Either omit `ClientAssociatedSitesOffset` or set it to 0 to return the client’s services (pricing options) from sites 1-10.<br>* Set `ClientAssociatedSitesOffset` to 10 to return the client pricing options from sites 11-20<br>* Set `ClientAssociatedSitesOffset` to 20 to return the client pricing options from sites 21-25 |
| `request_cross_regional_lookup` | `bool` | Query, Optional | Used to retrieve a client’s memberships from multiple sites within an organization. When included and set to `true`, it searches a maximum of ten sites with which this client is associated. When a client is associated with more than ten sites, use `ClientAssociatedSitesOffset` as many times as needed to search the additional sites with which the client is associated. You can use the `CrossRegionalClientAssociations` value from `GET CrossRegionalClientAssociations` to determine how many sites the client is associated with. Note that a `SiteID` is returned and populated in the `ClientServices` response when `CrossRegionalLookup` is set to `true`.<br>Default: **false** |
| `request_limit` | `int` | Query, Optional | Number of results to include, defaults to 100 |
| `request_location_id` | `int` | Query, Optional | The ID of the location where the requested membership was created. |
| `request_offset` | `int` | Query, Optional | Page offset, defaults to 0. |

## Response Type

[`MindbodyPublicApiDtoModelsV6ClientControllerGetActiveClientMembershipsResponse`](../../doc/models/mindbody-public-api-dto-models-v6-client-controller-get-active-client-memberships-response.md)

## Example Usage

```python
request_client_id = 'request.clientId2'
site_id = 'siteId8'
version = 'version4'

result = client_controller.client_get_active_client_memberships(request_client_id, site_id, version)
```


# Client Get Required Client Fields

Gets the list of fields that a new client has to fill out in business mode, specifically for the sign-up process. `AddClient` and `UpdateClient` validate against these fields.

This endpoint has no query parameters.

```python
def client_get_required_client_fields(self,
                                     site_id,
                                     version,
                                     authorization=None)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `site_id` | `string` | Header, Required | ID of the site from which to pull data. |
| `version` | `string` | Template, Required | - |
| `authorization` | `string` | Header, Optional | A staff user authorization token. |

## Response Type

[`MindbodyPublicApiDtoModelsV6ClientControllerGetRequiredClientFieldsResponse`](../../doc/models/mindbody-public-api-dto-models-v6-client-controller-get-required-client-fields-response.md)

## Example Usage

```python
site_id = 'siteId8'
version = 'version4'

result = client_controller.client_get_required_client_fields(site_id, version)
```


# Client Get Client Referral Types

Gets a list of referral types. Referral types are options that new clients can choose to identify how they learned about the business. Referral types are typically used for the sign-up process.

```python
def client_get_client_referral_types(self,
                                    site_id,
                                    version,
                                    authorization=None,
                                    request_include_inactive=None)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `site_id` | `string` | Header, Required | ID of the site from which to pull data. |
| `version` | `string` | Template, Required | - |
| `authorization` | `string` | Header, Optional | A staff user authorization token. |
| `request_include_inactive` | `bool` | Query, Optional | When `true`, filters the results to include subtypes and inactive referral types.<br /><br>When `false`, includes no subtypes and only active types. |

## Response Type

[`MindbodyPublicApiDtoModelsV6ClientControllerGetClientReferralTypesResponse`](../../doc/models/mindbody-public-api-dto-models-v6-client-controller-get-client-referral-types-response.md)

## Example Usage

```python
site_id = 'siteId8'
version = 'version4'

result = client_controller.client_get_client_referral_types(site_id, version)
```


# Client Get Client Account Balances

Get account balance information for one or more client(s).

```python
def client_get_client_account_balances(self,
                                      request_client_ids,
                                      site_id,
                                      version,
                                      authorization=None,
                                      request_balance_date=None,
                                      request_class_id=None,
                                      request_limit=None,
                                      request_offset=None)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `request_client_ids` | `List of string` | Query, Required | The list of clients IDs for which you want account balances. |
| `site_id` | `string` | Header, Required | ID of the site from which to pull data. |
| `version` | `string` | Template, Required | - |
| `authorization` | `string` | Header, Optional | A staff user authorization token. |
| `request_balance_date` | `datetime` | Query, Optional | The date you want a balance relative to.<br>Default: **the current date** |
| `request_class_id` | `int` | Query, Optional | The class ID of the event for which you want a balance. |
| `request_limit` | `int` | Query, Optional | Number of results to include, defaults to 100 |
| `request_offset` | `int` | Query, Optional | Page offset, defaults to 0. |

## Response Type

[`MindbodyPublicApiDtoModelsV6ClientControllerGetClientAccountBalancesResponse`](../../doc/models/mindbody-public-api-dto-models-v6-client-controller-get-client-account-balances-response.md)

## Example Usage

```python
request_client_ids = ['request.clientIds9', 'request.clientIds0', 'request.clientIds1']
site_id = 'siteId8'
version = 'version4'

result = client_controller.client_get_client_account_balances(request_client_ids, site_id, version)
```


# Client Get Client Purchases

Get a client's purchase history.

```python
def client_get_client_purchases(self,
                               request_client_id,
                               site_id,
                               version,
                               authorization=None,
                               request_end_date=None,
                               request_limit=None,
                               request_offset=None,
                               request_sale_id=None,
                               request_start_date=None)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `request_client_id` | `string` | Query, Required | The ID of the client you are querying for purchases. |
| `site_id` | `string` | Header, Required | ID of the site from which to pull data. |
| `version` | `string` | Template, Required | - |
| `authorization` | `string` | Header, Optional | A staff user authorization token. |
| `request_end_date` | `datetime` | Query, Optional | Filters results to purchases made before this timestamp.<br /><br>Default: **end of today** |
| `request_limit` | `int` | Query, Optional | Number of results to include, defaults to 100 |
| `request_offset` | `int` | Query, Optional | Page offset, defaults to 0. |
| `request_sale_id` | `int` | Query, Optional | Filters results to the single record associated with this ID. |
| `request_start_date` | `datetime` | Query, Optional | Filters results to purchases made on or after this timestamp.<br /><br>Default: **now** |

## Response Type

[`MindbodyPublicApiDtoModelsV6ClientControllerGetClientPurchasesResponse`](../../doc/models/mindbody-public-api-dto-models-v6-client-controller-get-client-purchases-response.md)

## Example Usage

```python
request_client_id = 'request.clientId2'
site_id = 'siteId8'
version = 'version4'

result = client_controller.client_get_client_purchases(request_client_id, site_id, version)
```


# Client Get Client Indexes

Client indexes are used to analyze client demographics. A business owner can set up different categories with sets of values which they can assign to each client. Client indexes are used in client searches, for tagging clients so that the owner can send mass emails to similar groups, and for many reports.

For more information, see Client Indexes and [Client Index Values (video tutorial)](https://support.mindbodyonline.com/s/article/203261653-Client-indexes-and-client-index-values-video-tutorial?language=en_USclient).

```python
def client_get_client_indexes(self,
                             site_id,
                             version,
                             authorization=None,
                             request_required_only=None)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `site_id` | `string` | Header, Required | ID of the site from which to pull data. |
| `version` | `string` | Template, Required | - |
| `authorization` | `string` | Header, Optional | A staff user authorization token. |
| `request_required_only` | `bool` | Query, Optional | When `true`, filters the results to only indexes that are required on creation.<br /><br>When `false` or omitted, returns all of the client indexes. |

## Response Type

[`MindbodyPublicApiDtoModelsV6ClientControllerGetClientIndexesResponse`](../../doc/models/mindbody-public-api-dto-models-v6-client-controller-get-client-indexes-response.md)

## Example Usage

```python
site_id = 'siteId8'
version = 'version4'

result = client_controller.client_get_client_indexes(site_id, version)
```


# Client Get Custom Client Fields

Get a site's configured custom client fields.

```python
def client_get_custom_client_fields(self,
                                   site_id,
                                   version,
                                   authorization=None,
                                   request_limit=None,
                                   request_offset=None)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `site_id` | `string` | Header, Required | ID of the site from which to pull data. |
| `version` | `string` | Template, Required | - |
| `authorization` | `string` | Header, Optional | A staff user authorization token. |
| `request_limit` | `int` | Query, Optional | Number of results to include, defaults to 100 |
| `request_offset` | `int` | Query, Optional | Page offset, defaults to 0. |

## Response Type

[`MindbodyPublicApiDtoModelsV6ClientControllerGetCustomClientFieldsResponse`](../../doc/models/mindbody-public-api-dto-models-v6-client-controller-get-custom-client-fields-response.md)

## Example Usage

```python
site_id = 'siteId8'
version = 'version4'

result = client_controller.client_get_custom_client_fields(site_id, version)
```


# Client Add Contact Log

Add a contact log to a client's account.

```python
def client_add_contact_log(self,
                          request,
                          site_id,
                          version,
                          authorization=None)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `request` | [`MindbodyPublicApiDtoModelsV6ClientControllerAddContactLogRequest`](../../doc/models/mindbody-public-api-dto-models-v6-client-controller-add-contact-log-request.md) | Body, Required | - |
| `site_id` | `string` | Header, Required | ID of the site from which to pull data. |
| `version` | `string` | Template, Required | - |
| `authorization` | `string` | Header, Optional | A staff user authorization token. |

## Response Type

[`MindbodyPublicApiDtoModelsV6ContactLog`](../../doc/models/mindbody-public-api-dto-models-v6-contact-log.md)

## Example Usage

```python
request = MindbodyPublicApiDtoModelsV6ClientControllerAddContactLogRequest()
request.client_id = 'ClientId0'
request.contact_method = 'ContactMethod0'
site_id = 'siteId8'
version = 'version4'

result = client_controller.client_add_contact_log(request, site_id, version)
```


# Client Update Contact Log

Update a contact log on a client's account.

```python
def client_update_contact_log(self,
                             request,
                             site_id,
                             version,
                             authorization=None)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `request` | [`MindbodyPublicApiDtoModelsV6ClientControllerUpdateContactLogRequest`](../../doc/models/mindbody-public-api-dto-models-v6-client-controller-update-contact-log-request.md) | Body, Required | - |
| `site_id` | `string` | Header, Required | ID of the site from which to pull data. |
| `version` | `string` | Template, Required | - |
| `authorization` | `string` | Header, Optional | A staff user authorization token. |

## Response Type

[`MindbodyPublicApiDtoModelsV6ContactLog`](../../doc/models/mindbody-public-api-dto-models-v6-contact-log.md)

## Example Usage

```python
request = MindbodyPublicApiDtoModelsV6ClientControllerUpdateContactLogRequest()
site_id = 'siteId8'
version = 'version4'

result = client_controller.client_update_contact_log(request, site_id, version)
```


# Client Get Cross Regional Client Associations

Returns a list of sites that a particular client ID (also referred to as an RSSID) or a client email address is associated with in a cross-regional organization. Either the `ClientID` or `Email` parameter is required. If both are provided, the `ClientID` is used.

Use this endpoint to retrieve information for other Public API endpoints, about the same client at multiple sites within an organization. To use this endpoint, your developer account must have been granted permission to the site’s entire organization.

Note that this endpoint does not work on the Developer Sandbox site, as it is not set up for cross-regional use cases.

```python
def client_get_cross_regional_client_associations(self,
                                                 site_id,
                                                 version,
                                                 authorization=None,
                                                 request_client_id=None,
                                                 request_email=None,
                                                 request_limit=None,
                                                 request_offset=None)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `site_id` | `string` | Header, Required | ID of the site from which to pull data. |
| `version` | `string` | Template, Required | - |
| `authorization` | `string` | Header, Optional | A staff user authorization token. |
| `request_client_id` | `string` | Query, Optional | Looks up the cross regional associations by the client’s ID. Either `ClientId` or `Email` must be provided. If both are provided, the `ClientId` is used by default. |
| `request_email` | `string` | Query, Optional | Looks up the cross regional associations by the client’s email address. Either `ClientId` or `Email` must be provided. If both are provided, the `ClientId` is used by default. |
| `request_limit` | `int` | Query, Optional | Number of results to include, defaults to 100 |
| `request_offset` | `int` | Query, Optional | Page offset, defaults to 0. |

## Response Type

[`MindbodyPublicApiDtoModelsV6ClientControllerGetCrossRegionalClientAssociationsResponse`](../../doc/models/mindbody-public-api-dto-models-v6-client-controller-get-cross-regional-client-associations-response.md)

## Example Usage

```python
site_id = 'siteId8'
version = 'version4'

result = client_controller.client_get_cross_regional_client_associations(site_id, version)
```


# Client Add Client

The `FirstName` and `LastName` parameters are always required in this request. All other parameters are optional, but note that any of the optional parameters could be required by a particular business, depending on how the business has configured the site settings.

Use after calling the `GetRequiredClientFields` endpoint to make sure you are collecting all required pieces of information.

```python
def client_add_client(self,
                     request,
                     site_id,
                     version,
                     authorization=None)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `request` | [`MindbodyPublicApiDtoModelsV6ClientControllerAddClientRequest`](../../doc/models/mindbody-public-api-dto-models-v6-client-controller-add-client-request.md) | Body, Required | - |
| `site_id` | `string` | Header, Required | ID of the site from which to pull data. |
| `version` | `string` | Template, Required | - |
| `authorization` | `string` | Header, Optional | A staff user authorization token. |

## Response Type

[`MindbodyPublicApiDtoModelsV6ClientControllerAddClientResponse`](../../doc/models/mindbody-public-api-dto-models-v6-client-controller-add-client-response.md)

## Example Usage

```python
request = MindbodyPublicApiDtoModelsV6ClientControllerAddClientRequest()
request.first_name = 'FirstName8'
request.last_name = 'LastName8'
site_id = 'siteId8'
version = 'version4'

result = client_controller.client_add_client(request, site_id, version)
```


# Client Update Client

Updates an existing client for a specific subscriber. Use this endpoint as follows:

* If you need to update the `ReferredBy` parameter, use this endpoint after calling `GET ClientReferralTypes`.
* When updating a client’s home location, use after calling `GET Locations`.
* If you are updating a client’s stored credit card, use after calling `GET AcceptedCardTypes` so that you can make sure the card is a type that is accepted at the subscriber.
  If this endpoint is used on a cross-regional site, passing in a client’s RSSID and email address creates a cross-regional link. This means that the client is created in cross-regional sites where the client does not exist and `GET CrossRegionalClientAssociations` returns all appropriate cross-regional sites. When `CrossRegionalUpdate` is omitted or set to `true`, the client’s updated information is propagated to all of the region’s sites. If `CrossRegionalUpdate` is set to `false`, only the local client is updated.

Note that the following items cannot be updated for a cross-regional client:

* `ClientIndexes`
* `ClientRelationships`
* `CustomClientFields`
* `SalesReps`
* `SendAccountEmails`
* `SendAccountTexts`
* `SendPromotionalEmails`
* `SendPromotionalTexts`
* `SendScheduleEmails`
* `SendScheduleTexts`

```python
def client_update_client(self,
                        request,
                        site_id,
                        version,
                        authorization=None)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `request` | [`MindbodyPublicApiDtoModelsV6ClientControllerUpdateClientRequest`](../../doc/models/mindbody-public-api-dto-models-v6-client-controller-update-client-request.md) | Body, Required | - |
| `site_id` | `string` | Header, Required | ID of the site from which to pull data. |
| `version` | `string` | Template, Required | - |
| `authorization` | `string` | Header, Optional | A staff user authorization token. |

## Response Type

[`MindbodyPublicApiDtoModelsV6ClientControllerUpdateClientResponse`](../../doc/models/mindbody-public-api-dto-models-v6-client-controller-update-client-response.md)

## Example Usage

```python
request = MindbodyPublicApiDtoModelsV6ClientControllerUpdateClientRequest()
request.client = MindbodyPublicApiDtoModelsV6ClientWithSuspensionInfo()
site_id = 'siteId8'
version = 'version4'

result = client_controller.client_update_client(request, site_id, version)
```


# Client Update Client Visit

Update a client's visit.

```python
def client_update_client_visit(self,
                              request,
                              site_id,
                              version,
                              authorization=None)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `request` | [`MindbodyPublicApiDtoModelsV6ClientControllerUpdateClientVisitRequest`](../../doc/models/mindbody-public-api-dto-models-v6-client-controller-update-client-visit-request.md) | Body, Required | - |
| `site_id` | `string` | Header, Required | ID of the site from which to pull data. |
| `version` | `string` | Template, Required | - |
| `authorization` | `string` | Header, Optional | A staff user authorization token. |

## Response Type

[`MindbodyPublicApiDtoModelsV6ClientControllerUpdateClientVisitResponse`](../../doc/models/mindbody-public-api-dto-models-v6-client-controller-update-client-visit-response.md)

## Example Usage

```python
request = MindbodyPublicApiDtoModelsV6ClientControllerUpdateClientVisitRequest()
request.visit_id = 92
site_id = 'siteId8'
version = 'version4'

result = client_controller.client_update_client_visit(request, site_id, version)
```


# Client Add Arrival

Add an arrival for a client.

```python
def client_add_arrival(self,
                      request,
                      site_id,
                      version,
                      authorization=None)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `request` | [`MindbodyPublicApiDtoModelsV6ClientControllerAddArrivalRequest`](../../doc/models/mindbody-public-api-dto-models-v6-client-controller-add-arrival-request.md) | Body, Required | - |
| `site_id` | `string` | Header, Required | ID of the site from which to pull data. |
| `version` | `string` | Template, Required | - |
| `authorization` | `string` | Header, Optional | A staff user authorization token. |

## Response Type

[`MindbodyPublicApiDtoModelsV6ClientControllerAddArrivalResponse`](../../doc/models/mindbody-public-api-dto-models-v6-client-controller-add-arrival-response.md)

## Example Usage

```python
request = MindbodyPublicApiDtoModelsV6ClientControllerAddArrivalRequest()
request.client_id = 'ClientId0'
request.location_id = 238
site_id = 'siteId8'
version = 'version4'

result = client_controller.client_add_arrival(request, site_id, version)
```


# Client Send Password Reset Email

Send a password reset email to a client.

```python
def client_send_password_reset_email(self,
                                    request,
                                    site_id,
                                    version,
                                    authorization=None)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `request` | [`MindbodyPublicApiDtoModelsV6ClientControllerSendPasswordResetEmailRequest`](../../doc/models/mindbody-public-api-dto-models-v6-client-controller-send-password-reset-email-request.md) | Body, Required | - |
| `site_id` | `string` | Header, Required | ID of the site from which to pull data. |
| `version` | `string` | Template, Required | - |
| `authorization` | `string` | Header, Optional | A staff user authorization token. |

## Response Type

`object`

## Example Usage

```python
request = MindbodyPublicApiDtoModelsV6ClientControllerSendPasswordResetEmailRequest()
request.user_email = 'UserEmail2'
request.user_first_name = 'UserFirstName2'
request.user_last_name = 'UserLastName8'
site_id = 'siteId8'
version = 'version4'

result = client_controller.client_send_password_reset_email(request, site_id, version)
```


# Client Get Contact Logs

This endpoint contains a variety of filters that can return not just all contact logs, but also system-generated contact logs, contact logs assigned to specific staff members, and contact logs of specific types or subtypes.

```python
def client_get_contact_logs(self,
                           request_client_id,
                           site_id,
                           version,
                           authorization=None,
                           request_end_date=None,
                           request_limit=None,
                           request_offset=None,
                           request_show_system_generated=None,
                           request_staff_ids=None,
                           request_start_date=None,
                           request_subtype_ids=None,
                           request_type_ids=None)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `request_client_id` | `string` | Query, Required | The ID of the client whose contact logs are being requested. |
| `site_id` | `string` | Header, Required | ID of the site from which to pull data. |
| `version` | `string` | Template, Required | - |
| `authorization` | `string` | Header, Optional | A staff user authorization token. |
| `request_end_date` | `datetime` | Query, Optional | Filters the results to contact logs created before this date.<br /><br>Default: **the start date** |
| `request_limit` | `int` | Query, Optional | Number of results to include, defaults to 100 |
| `request_offset` | `int` | Query, Optional | Page offset, defaults to 0. |
| `request_show_system_generated` | `bool` | Query, Optional | When `true`, system-generated contact logs are returned in the results.<br /><br>Default: **false** |
| `request_staff_ids` | `List of long\|int` | Query, Optional | Filters the results to return contact logs assigned to one or more staff IDs. |
| `request_start_date` | `datetime` | Query, Optional | Filters the results to contact logs created on or after this date.<br /><br>Default: **the current date** |
| `request_subtype_ids` | `List of int` | Query, Optional | Filters the results to contact logs assigned one or more of these subtype IDs. |
| `request_type_ids` | `List of int` | Query, Optional | Filters the results to contact logs assigned one or more of these type IDs. |

## Response Type

[`MindbodyPublicApiDtoModelsV6ClientControllerGetContactLogsResponse`](../../doc/models/mindbody-public-api-dto-models-v6-client-controller-get-contact-logs-response.md)

## Example Usage

```python
request_client_id = 'request.clientId2'
site_id = 'siteId8'
version = 'version4'

result = client_controller.client_get_contact_logs(request_client_id, site_id, version)
```


# Client Update Client Service

Updates the active date and/or expiration date of a client pricing option. This request requires staff user credentials. If the active date is modified, the expiration date is also modified accordingly. If the expiration date is modified, the active date is unchanged.

```python
def client_update_client_service(self,
                                request,
                                site_id,
                                version,
                                authorization=None)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `request` | [`MindbodyPublicApiDtoModelsV6ClientControllerUpdateClientServiceRequest`](../../doc/models/mindbody-public-api-dto-models-v6-client-controller-update-client-service-request.md) | Body, Required | - |
| `site_id` | `string` | Header, Required | ID of the site from which to pull data. |
| `version` | `string` | Template, Required | - |
| `authorization` | `string` | Header, Optional | A staff user authorization token. |

## Response Type

[`MindbodyPublicApiDtoModelsV6ClientControllerUpdateClientServiceResponse`](../../doc/models/mindbody-public-api-dto-models-v6-client-controller-update-client-service-response.md)

## Example Usage

```python
request = MindbodyPublicApiDtoModelsV6ClientControllerUpdateClientServiceRequest()
request.service_id = 130
site_id = 'siteId8'
version = 'version4'

result = client_controller.client_update_client_service(request, site_id, version)
```


# Client Get Direct Debit Info

Get direct debit info for a client.

```python
def client_get_direct_debit_info(self,
                                site_id,
                                version,
                                authorization=None,
                                client_id=None)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `site_id` | `string` | Header, Required | ID of the site from which to pull data. |
| `version` | `string` | Template, Required | - |
| `authorization` | `string` | Header, Optional | A staff user authorization token. |
| `client_id` | `string` | Query, Optional | - |

## Response Type

[`MindbodyPublicApiDtoModelsV6DirectDebitInfo`](../../doc/models/mindbody-public-api-dto-models-v6-direct-debit-info.md)

## Example Usage

```python
site_id = 'siteId8'
version = 'version4'

result = client_controller.client_get_direct_debit_info(site_id, version)
```


# Client Delete Direct Debit Info

Delete direct debit info for a client.

```python
def client_delete_direct_debit_info(self,
                                   site_id,
                                   version,
                                   authorization=None,
                                   client_id=None)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `site_id` | `string` | Header, Required | ID of the site from which to pull data. |
| `version` | `string` | Template, Required | - |
| `authorization` | `string` | Header, Optional | A staff user authorization token. |
| `client_id` | `string` | Query, Optional | - |

## Response Type

`object`

## Example Usage

```python
site_id = 'siteId8'
version = 'version4'

result = client_controller.client_delete_direct_debit_info(site_id, version)
```


# Client Add Client Direct Debit Info

```python
def client_add_client_direct_debit_info(self,
                                       request,
                                       site_id,
                                       version,
                                       authorization=None)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `request` | [`MindbodyPublicApiDtoModelsV6ClientControllerAddClientDirectDebitInfoRequest`](../../doc/models/mindbody-public-api-dto-models-v6-client-controller-add-client-direct-debit-info-request.md) | Body, Required | - |
| `site_id` | `string` | Header, Required | ID of the site from which to pull data. |
| `version` | `string` | Template, Required | - |
| `authorization` | `string` | Header, Optional | A staff user authorization token. |

## Response Type

[`MindbodyPublicApiDtoModelsV6ClientControllerAddClientDirectDebitInfoResponse`](../../doc/models/mindbody-public-api-dto-models-v6-client-controller-add-client-direct-debit-info-response.md)

## Example Usage

```python
request = MindbodyPublicApiDtoModelsV6ClientControllerAddClientDirectDebitInfoRequest()
site_id = 'siteId8'
version = 'version4'

result = client_controller.client_add_client_direct_debit_info(request, site_id, version)
```


# Client Get Client Rewards

```python
def client_get_client_rewards(self,
                             request_client_id,
                             site_id,
                             version,
                             authorization=None,
                             request_end_date=None,
                             request_limit=None,
                             request_offset=None,
                             request_start_date=None)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `request_client_id` | `string` | Query, Required | The ID of the client whose reward information is being requested. |
| `site_id` | `string` | Header, Required | ID of the site from which to pull data. |
| `version` | `string` | Template, Required | - |
| `authorization` | `string` | Header, Optional | A staff user authorization token. |
| `request_end_date` | `datetime` | Query, Optional | Filters the results to rewards transactions created before this date.<br /><br>Default: **the start date** |
| `request_limit` | `int` | Query, Optional | Number of results to include, defaults to 100 |
| `request_offset` | `int` | Query, Optional | Page offset, defaults to 0. |
| `request_start_date` | `datetime` | Query, Optional | Filters the results to rewards transactions created on or after this date.<br /><br>Default: **the current date** |

## Response Type

[`MindbodyPublicApiDtoModelsV6ClientControllerGetClientRewardsResponse`](../../doc/models/mindbody-public-api-dto-models-v6-client-controller-get-client-rewards-response.md)

## Example Usage

```python
request_client_id = 'request.clientId2'
site_id = 'siteId8'
version = 'version4'

result = client_controller.client_get_client_rewards(request_client_id, site_id, version)
```


# Client Update Client Rewards

```python
def client_update_client_rewards(self,
                                request,
                                site_id,
                                version,
                                authorization=None)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `request` | [`MindbodyPublicApiDtoModelsV6ClientControllerUpdateClientRewardsRequest`](../../doc/models/mindbody-public-api-dto-models-v6-client-controller-update-client-rewards-request.md) | Body, Required | - |
| `site_id` | `string` | Header, Required | ID of the site from which to pull data. |
| `version` | `string` | Template, Required | - |
| `authorization` | `string` | Header, Optional | A staff user authorization token. |

## Response Type

[`MindbodyPublicApiDtoModelsV6ClientControllerGetClientRewardsResponse`](../../doc/models/mindbody-public-api-dto-models-v6-client-controller-get-client-rewards-response.md)

## Example Usage

```python
request = MindbodyPublicApiDtoModelsV6ClientControllerUpdateClientRewardsRequest()
request.client_id = 'ClientId0'
request.points = 10
request.action = 'Action6'
site_id = 'siteId8'
version = 'version4'

result = client_controller.client_update_client_rewards(request, site_id, version)
```


# Client Get Client Complete Info

Get Services, Contracts, MemberShips and Arrivals for Client as per requirement

```python
def client_get_client_complete_info(self,
                                   request_client_id,
                                   site_id,
                                   version,
                                   authorization=None,
                                   request_client_associated_sites_offset=None,
                                   request_cross_regional_lookup=None,
                                   request_end_date=None,
                                   request_required_client_data=None,
                                   request_start_date=None)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `request_client_id` | `string` | Query, Required | The ID of the client to query. |
| `site_id` | `string` | Header, Required | ID of the site from which to pull data. |
| `version` | `string` | Template, Required | - |
| `authorization` | `string` | Header, Optional | A staff user authorization token. |
| `request_client_associated_sites_offset` | `int` | Query, Optional | Used to retrieve a client’s pricing options from multiple sites within an organization when the client is associated with more than ten sites. To change which ten sites are searched, change this offset value. A value of 0 means that no sites are skipped and the first ten sites are returned. You can use the `CrossRegionalClientAssociations` value from `GET CrossRegionalClientAssociations` to determine how many sites the client is associated with. Note that you must always have `CrossRegionalLookup` set to `true` to use this parameter.<br /><br>Default: **0**<br><br>For example, if a client is associated with 25 sites, you need to call `GetClientServices` three times, as follows:<br><br>* Use `GET CrossRegionalClientAssociations` to determine how many sites a client is associated with, which tells you how many additional calls you need to make.<br>* Either omit `ClientAssociatedSitesOffset` or set it to 0 to return the client’s services (pricing options) from sites 1-10.<br>* Set `ClientAssociatedSitesOffset` to 10 to return the client pricing options from sites 11-20<br>* Set `ClientAssociatedSitesOffset` to 20 to return the client pricing options from sites 21-25 |
| `request_cross_regional_lookup` | `bool` | Query, Optional | Used to retrieve a client’s data from multiple sites within an organization.<br>Default: **false** |
| `request_end_date` | `datetime` | Query, Optional | Filters results to pricing options that are valid on or before this date. |
| `request_required_client_data` | `List of string` | Query, Optional | Used to store the required type of data for particular client |
| `request_start_date` | `datetime` | Query, Optional | Filters results to pricing options that are valid on or after this date. |

## Response Type

[`MindbodyPublicApiDtoModelsV6ClientControllerGetClientCompleteInfoResponse`](../../doc/models/mindbody-public-api-dto-models-v6-client-controller-get-client-complete-info-response.md)

## Example Usage

```python
request_client_id = 'request.clientId2'
site_id = 'siteId8'
version = 'version4'

result = client_controller.client_get_client_complete_info(request_client_id, site_id, version)
```


# Client Get Contact Log Types

Get All Active Contact Log Types

```python
def client_get_contact_log_types(self,
                                site_id,
                                version,
                                authorization=None,
                                request_contact_log_type_id=None,
                                request_limit=None,
                                request_offset=None)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `site_id` | `string` | Header, Required | ID of the site from which to pull data. |
| `version` | `string` | Template, Required | - |
| `authorization` | `string` | Header, Optional | A staff user authorization token. |
| `request_contact_log_type_id` | `int` | Query, Optional | The ID of the Contact Log Type |
| `request_limit` | `int` | Query, Optional | Number of results to include, defaults to 100 |
| `request_offset` | `int` | Query, Optional | Page offset, defaults to 0. |

## Response Type

[`MindbodyPublicApiDtoModelsV6ClientControllerGetContactLogTypesResponse`](../../doc/models/mindbody-public-api-dto-models-v6-client-controller-get-contact-log-types-response.md)

## Example Usage

```python
site_id = 'siteId8'
version = 'version4'

result = client_controller.client_get_contact_log_types(site_id, version)
```


# Client Delete Contact Log

Delete client's contact log.

```python
def client_delete_contact_log(self,
                             request_client_id,
                             request_contact_log_id,
                             site_id,
                             version,
                             authorization=None,
                             request_test=None)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `request_client_id` | `string` | Query, Required | The client ID of the client whose Contact Log is being deleted. |
| `request_contact_log_id` | `long\|int` | Query, Required | The Contact Log ID. |
| `site_id` | `string` | Header, Required | ID of the site from which to pull data. |
| `version` | `string` | Template, Required | - |
| `authorization` | `string` | Header, Optional | A staff user authorization token. |
| `request_test` | `bool` | Query, Optional | When `true`, indicates that this is a test request and no data is inserted into the subscriber’s database.<br>When `false`, the database is updated. |

## Response Type

`object`

## Example Usage

```python
request_client_id = 'request.clientId2'
request_contact_log_id = 90
site_id = 'siteId8'
version = 'version4'

result = client_controller.client_delete_contact_log(request_client_id, request_contact_log_id, site_id, version)
```


# Client Send Auto Email

Send a client a supported auto email

```python
def client_send_auto_email(self,
                          request,
                          site_id,
                          version,
                          authorization=None)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `request` | [`MindbodyPublicApiDtoModelsV6ClientControllerSendAutoEmailRequest`](../../doc/models/mindbody-public-api-dto-models-v6-client-controller-send-auto-email-request.md) | Body, Required | - |
| `site_id` | `string` | Header, Required | ID of the site from which to pull data. |
| `version` | `string` | Template, Required | - |
| `authorization` | `string` | Header, Optional | A staff user authorization token. |

## Response Type

`object`

## Example Usage

```python
request = MindbodyPublicApiDtoModelsV6ClientControllerSendAutoEmailRequest()
request.client_id = 'ClientId0'
request.email_type = 'EmailType4'
site_id = 'siteId8'
version = 'version4'

result = client_controller.client_send_auto_email(request, site_id, version)
```


# Client Get Active Clients Memberships

Get a client's active memberships.

```python
def client_get_active_clients_memberships(self,
                                         request_client_ids,
                                         site_id,
                                         version,
                                         authorization=None,
                                         request_client_associated_sites_offset=None,
                                         request_cross_regional_lookup=None,
                                         request_limit=None,
                                         request_location_id=None,
                                         request_offset=None)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `request_client_ids` | `List of string` | Query, Required | The ID's of the clients whose membership was requested. |
| `site_id` | `string` | Header, Required | ID of the site from which to pull data. |
| `version` | `string` | Template, Required | - |
| `authorization` | `string` | Header, Optional | A staff user authorization token. |
| `request_client_associated_sites_offset` | `int` | Query, Optional | Used to retrieve a client’s memberships from multiple sites within an organization when the client is associated with more than ten sites. To change which ten sites are searched, change this offset value. A value of 0 means that no sites are skipped and the first ten sites are returned. You can use the `CrossRegionalClientAssociations` value from `GET CrossRegionalClientAssociations` to determine how many sites the client is associated with. Note that you must always have `CrossRegionalLookup` set to `true` to use this parameter.<br /><br>Default: **0**<br><br>For example, if a client is associated with 25 sites, you need to call `GetClientServices` three times, as follows:<br><br>* Use `GET CrossRegionalClientAssociations` to determine how many sites a client is associated with, which tells you how many additional calls you need to make.<br>* Either omit `ClientAssociatedSitesOffset` or set it to 0 to return the client’s services (pricing options) from sites 1-10.<br>* Set `ClientAssociatedSitesOffset` to 10 to return the client pricing options from sites 11-20<br>* Set `ClientAssociatedSitesOffset` to 20 to return the client pricing options from sites 21-25 |
| `request_cross_regional_lookup` | `bool` | Query, Optional | Used to retrieve a client’s memberships from multiple sites within an organization. When included and set to `true`, it searches a maximum of ten sites with which this client is associated. When a client is associated with more than ten sites, use `ClientAssociatedSitesOffset` as many times as needed to search the additional sites with which the client is associated. You can use the `CrossRegionalClientAssociations` value from `GET CrossRegionalClientAssociations` to determine how many sites the client is associated with. Note that a `SiteID` is returned and populated in the `ClientServices` response when `CrossRegionalLookup` is set to `true`.<br>Default: **false** |
| `request_limit` | `int` | Query, Optional | Number of results to include, defaults to 100 |
| `request_location_id` | `int` | Query, Optional | The ID of the location where the requested membership was created. |
| `request_offset` | `int` | Query, Optional | Page offset, defaults to 0. |

## Response Type

[`MindbodyPublicApiDtoModelsV6ClientControllerGetActiveClientsMembershipsResponse`](../../doc/models/mindbody-public-api-dto-models-v6-client-controller-get-active-clients-memberships-response.md)

## Example Usage

```python
request_client_ids = ['request.clientIds9', 'request.clientIds0', 'request.clientIds1']
site_id = 'siteId8'
version = 'version4'

result = client_controller.client_get_active_clients_memberships(request_client_ids, site_id, version)
```


# Client Terminate Contract

Terminate client contract

```python
def client_terminate_contract(self,
                             request,
                             site_id,
                             version,
                             authorization=None)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `request` | [`MindbodyPublicApiDtoModelsV6ClientControllerTerminateContractRequest`](../../doc/models/mindbody-public-api-dto-models-v6-client-controller-terminate-contract-request.md) | Body, Required | - |
| `site_id` | `string` | Header, Required | ID of the site from which to pull data. |
| `version` | `string` | Template, Required | - |
| `authorization` | `string` | Header, Optional | A staff user authorization token. |

## Response Type

[`MindbodyPublicApiDtoModelsV6ClientControllerTerminateContractResponse`](../../doc/models/mindbody-public-api-dto-models-v6-client-controller-terminate-contract-response.md)

## Example Usage

```python
request = MindbodyPublicApiDtoModelsV6ClientControllerTerminateContractRequest()
request.client_id = 'ClientId0'
request.client_contract_id = 118
request.termination_date = dateutil.parser.parse('2016-03-13T12:52:32.123Z')
site_id = 'siteId8'
version = 'version4'

result = client_controller.client_terminate_contract(request, site_id, version)
```

