
# Mindbody Public Api Dto Models V6 Site Controller Get Promo Codes Request

## Structure

`MindbodyPublicApiDtoModelsV6SiteControllerGetPromoCodesRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `active_only` | `bool` | Optional | Filter only active, defaults to true |
| `online_only` | `bool` | Optional | Filter only the ones that can be sold online |
| `start_date` | `datetime` | Optional | Filter by activation start date |
| `end_date` | `datetime` | Optional | Filter by activation end date |
| `limit` | `int` | Optional | Number of results to include, defaults to 100 |
| `offset` | `int` | Optional | Page offset, defaults to 0. |

## Example (as JSON)

```json
{
  "ActiveOnly": null,
  "OnlineOnly": null,
  "StartDate": null,
  "EndDate": null,
  "Limit": null,
  "Offset": null
}
```

