
# Mindbody Public Api Dto Models V6 Site Controller Get Genders Response

## Structure

`MindbodyPublicApiDtoModelsV6SiteControllerGetGendersResponse`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `genderOptions` | [`?(MindbodyPublicApiDtoModelsV6GenderOption[])`](../../doc/models/mindbody-public-api-dto-models-v6-gender-option.md) | Optional | A list of the gender options and their properties at the site | getGenderOptions(): ?array | setGenderOptions(?array genderOptions): void |

## Example (as JSON)

```json
{
  "GenderOptions": null
}
```

