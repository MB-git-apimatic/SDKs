
# Mindbody Public Api Dto Models V6 Class Controller Cancel Single Class Request

## Structure

`MindbodyPublicApiDtoModelsV6ClassControllerCancelSingleClassRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `class_id` | `long\|int` | Optional | Class ID to lookup. |
| `hide_cancel` | `bool` | Optional | Hide canceled class. |
| `send_client_email` | `bool` | Optional | Client auto email. |
| `send_staff_email` | `bool` | Optional | Staff auto email. |

## Example (as JSON)

```json
{
  "ClassID": null,
  "HideCancel": null,
  "SendClientEmail": null,
  "SendStaffEmail": null
}
```

