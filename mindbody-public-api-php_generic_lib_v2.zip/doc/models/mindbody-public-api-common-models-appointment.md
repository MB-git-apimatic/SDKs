
# Mindbody Public Api Common Models Appointment

## Structure

`MindbodyPublicApiCommonModelsAppointment`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `genderPreference` | `?string` | Optional | - | getGenderPreference(): ?string | setGenderPreference(?string genderPreference): void |
| `duration` | `?int` | Optional | - | getDuration(): ?int | setDuration(?int duration): void |
| `providerId` | `?string` | Optional | - | getProviderId(): ?string | setProviderId(?string providerId): void |
| `id` | `?int` | Optional | - | getId(): ?int | setId(?int id): void |
| `status` | [`?string (Status1Enum)`](../../doc/models/status-1-enum.md) | Optional | - | getStatus(): ?string | setStatus(?string status): void |
| `startDateTime` | `?\DateTime` | Optional | - | getStartDateTime(): ?\DateTime | setStartDateTime(?\DateTime startDateTime): void |
| `endDateTime` | `?\DateTime` | Optional | - | getEndDateTime(): ?\DateTime | setEndDateTime(?\DateTime endDateTime): void |
| `notes` | `?string` | Optional | - | getNotes(): ?string | setNotes(?string notes): void |
| `staffRequested` | `?bool` | Optional | - | getStaffRequested(): ?bool | setStaffRequested(?bool staffRequested): void |
| `programId` | `?int` | Optional | - | getProgramId(): ?int | setProgramId(?int programId): void |
| `waitlistEntryId` | `?int` | Optional | - | getWaitlistEntryId(): ?int | setWaitlistEntryId(?int waitlistEntryId): void |
| `sessionTypeId` | `?int` | Optional | - | getSessionTypeId(): ?int | setSessionTypeId(?int sessionTypeId): void |
| `locationId` | `?int` | Optional | - | getLocationId(): ?int | setLocationId(?int locationId): void |
| `staffId` | `?int` | Optional | - | getStaffId(): ?int | setStaffId(?int staffId): void |
| `clientId` | `?string` | Optional | - | getClientId(): ?string | setClientId(?string clientId): void |
| `firstAppointment` | `?bool` | Optional | - | getFirstAppointment(): ?bool | setFirstAppointment(?bool firstAppointment): void |
| `clientServiceId` | `?int` | Optional | - | getClientServiceId(): ?int | setClientServiceId(?int clientServiceId): void |
| `resources` | [`?(MindbodyPublicApiCommonModelsResource[])`](../../doc/models/mindbody-public-api-common-models-resource.md) | Optional | - | getResources(): ?array | setResources(?array resources): void |
| `addOns` | [`?(MindbodyPublicApiCommonModelsAddOnSmall[])`](../../doc/models/mindbody-public-api-common-models-add-on-small.md) | Optional | - | getAddOns(): ?array | setAddOns(?array addOns): void |
| `isWaitlist` | `?bool` | Optional | - | getIsWaitlist(): ?bool | setIsWaitlist(?bool isWaitlist): void |
| `onlineDescription` | `?string` | Optional | - | getOnlineDescription(): ?string | setOnlineDescription(?string onlineDescription): void |

## Example (as JSON)

```json
{
  "GenderPreference": null,
  "Duration": null,
  "ProviderId": null,
  "Id": null,
  "Status": null,
  "StartDateTime": null,
  "EndDateTime": null,
  "Notes": null,
  "StaffRequested": null,
  "ProgramId": null,
  "WaitlistEntryId": null,
  "SessionTypeId": null,
  "LocationId": null,
  "StaffId": null,
  "ClientId": null,
  "FirstAppointment": null,
  "ClientServiceId": null,
  "Resources": null,
  "AddOns": null,
  "IsWaitlist": null,
  "OnlineDescription": null
}
```

