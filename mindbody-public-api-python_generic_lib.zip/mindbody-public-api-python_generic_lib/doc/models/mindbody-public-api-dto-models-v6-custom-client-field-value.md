
# Mindbody Public Api Dto Models V6 Custom Client Field Value

The value of a custom client field

## Structure

`MindbodyPublicApiDtoModelsV6CustomClientFieldValue`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `value` | `string` | Optional | The value of a specific custom field for a client. |
| `id` | `int` | Optional | The ID of the custom client field. |
| `data_type` | `string` | Optional | The data type of the field. |
| `name` | `string` | Optional | The name of the field. |

## Example (as JSON)

```json
{
  "Value": null,
  "Id": null,
  "DataType": null,
  "Name": null
}
```

