
# Mindbody Public Api Common Models Unavailability

## Structure

`MindbodyPublicApiCommonModelsUnavailability`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `int` | Optional | - |
| `start_date_time` | `datetime` | Optional | - |
| `end_date_time` | `datetime` | Optional | - |
| `description` | `string` | Optional | - |

## Example (as JSON)

```json
{
  "Id": null,
  "StartDateTime": null,
  "EndDateTime": null,
  "Description": null
}
```

