
# Mindbody Public Api Dto Models V6 Sale Controller Get Products Request

## Structure

`MindbodyPublicApiDtoModelsV6SaleControllerGetProductsRequest`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `productIds` | `?(string[])` | Optional | The barcode number of the product to be filter by. | getProductIds(): ?array | setProductIds(?array productIds): void |
| `searchText` | `?string` | Optional | A search filter, used for searching by term. | getSearchText(): ?string | setSearchText(?string searchText): void |
| `categoryIds` | `?(int[])` | Optional | A list of revenue category IDs to filter by. Use this ID when calling the GET Categories endpoint.<br><br>** Note:** The values for these are not currently retrievable through the API. | getCategoryIds(): ?array | setCategoryIds(?array categoryIds): void |
| `subCategoryIds` | `?(int[])` | Optional | A list of subcategory IDs to filter by. Use this ID when calling the GET Categories endpoint.<br><br>**Note:** The values for these are not currently retrievable through the API. | getSubCategoryIds(): ?array | setSubCategoryIds(?array subCategoryIds): void |
| `sellOnline` | `?bool` | Optional | When `true`, only products that can be sold online are returned.<br /><br>When `false`, all products are returned.<br /><br>Default: **false** | getSellOnline(): ?bool | setSellOnline(?bool sellOnline): void |
| `locationId` | `?int` | Optional | The location ID to use to determine the tax for the products that this request returns.<br /><br>Default: **online store** | getLocationId(): ?int | setLocationId(?int locationId): void |
| `limit` | `?int` | Optional | Number of results to include, defaults to 100 | getLimit(): ?int | setLimit(?int limit): void |
| `offset` | `?int` | Optional | Page offset, defaults to 0. | getOffset(): ?int | setOffset(?int offset): void |

## Example (as JSON)

```json
{
  "ProductIds": null,
  "SearchText": null,
  "CategoryIds": null,
  "SubCategoryIds": null,
  "SellOnline": null,
  "LocationId": null,
  "Limit": null,
  "Offset": null
}
```

