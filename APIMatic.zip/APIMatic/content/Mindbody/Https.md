﻿
All calls to the Public API must use HTTPS connections, using TLS v1.2 or higher. Any connections made using an older version of TLS are not guaranteed to work correctly.
