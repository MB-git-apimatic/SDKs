
# Mindbody Public Api Dto Models V6 Appointment Controller Get Unavailabilities Request

## Structure

`MindbodyPublicApiDtoModelsV6AppointmentControllerGetUnavailabilitiesRequest`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `staffIds` | `?(int[])` | Optional | A list of requested staff IDs. | getStaffIds(): ?array | setStaffIds(?array staffIds): void |
| `startDate` | `?\DateTime` | Optional | The start date of the requested date range.<br><br />Default: **today’s date** | getStartDate(): ?\DateTime | setStartDate(?\DateTime startDate): void |
| `endDate` | `?\DateTime` | Optional | The end date of the requested date range.<br><br />Default: **today’s date** | getEndDate(): ?\DateTime | setEndDate(?\DateTime endDate): void |
| `limit` | `?int` | Optional | Number of results to include, defaults to 100 | getLimit(): ?int | setLimit(?int limit): void |
| `offset` | `?int` | Optional | Page offset, defaults to 0. | getOffset(): ?int | setOffset(?int offset): void |

## Example (as JSON)

```json
{
  "StaffIds": null,
  "StartDate": null,
  "EndDate": null,
  "Limit": null,
  "Offset": null
}
```

