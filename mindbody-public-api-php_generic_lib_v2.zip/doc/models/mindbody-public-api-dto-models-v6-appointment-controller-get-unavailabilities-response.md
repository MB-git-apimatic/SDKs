
# Mindbody Public Api Dto Models V6 Appointment Controller Get Unavailabilities Response

## Structure

`MindbodyPublicApiDtoModelsV6AppointmentControllerGetUnavailabilitiesResponse`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `paginationResponse` | [`?MindbodyPublicApiDtoModelsV6PaginationResponse`](../../doc/models/mindbody-public-api-dto-models-v6-pagination-response.md) | Optional | - | getPaginationResponse(): ?MindbodyPublicApiDtoModelsV6PaginationResponse | setPaginationResponse(?MindbodyPublicApiDtoModelsV6PaginationResponse paginationResponse): void |
| `unavailabilities` | [`?(MindbodyPublicApiDtoModelsV6UnavailabilityPlain[])`](../../doc/models/mindbody-public-api-dto-models-v6-unavailability-plain.md) | Optional | Contains information about unavailabilities | getUnavailabilities(): ?array | setUnavailabilities(?array unavailabilities): void |

## Example (as JSON)

```json
{
  "PaginationResponse": null,
  "Unavailabilities": null
}
```

