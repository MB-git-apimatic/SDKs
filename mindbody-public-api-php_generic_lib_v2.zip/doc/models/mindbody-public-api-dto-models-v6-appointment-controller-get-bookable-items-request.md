
# Mindbody Public Api Dto Models V6 Appointment Controller Get Bookable Items Request

## Structure

`MindbodyPublicApiDtoModelsV6AppointmentControllerGetBookableItemsRequest`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `sessionTypeIds` | `int[]` | Required | A list of the requested session type IDs. | getSessionTypeIds(): array | setSessionTypeIds(array sessionTypeIds): void |
| `locationIds` | `?(int[])` | Optional | A list of the requested location IDs. | getLocationIds(): ?array | setLocationIds(?array locationIds): void |
| `staffIds` | `?(int[])` | Optional | A list of the requested staff IDs. Omit parameter to return all staff availabilities. | getStaffIds(): ?array | setStaffIds(?array staffIds): void |
| `startDate` | `?\DateTime` | Optional | The start date of the requested date range.<br><br />Default: **today’s date** | getStartDate(): ?\DateTime | setStartDate(?\DateTime startDate): void |
| `endDate` | `?\DateTime` | Optional | The end date of the requested date range.<br><br />Default: **StartDate** | getEndDate(): ?\DateTime | setEndDate(?\DateTime endDate): void |
| `appointmentId` | `?int` | Optional | If provided, filters out the appointment with this ID. | getAppointmentId(): ?int | setAppointmentId(?int appointmentId): void |
| `ignoreDefaultSessionLength` | `?bool` | Optional | When `true`, availabilities that are non-default return, for example, a 30-minute availability with a 60-minute default session length.<br /><br>When `false`, only availabilities that have the default session length return. | getIgnoreDefaultSessionLength(): ?bool | setIgnoreDefaultSessionLength(?bool ignoreDefaultSessionLength): void |
| `limit` | `?int` | Optional | Number of results to include, defaults to 100 | getLimit(): ?int | setLimit(?int limit): void |
| `offset` | `?int` | Optional | Page offset, defaults to 0. | getOffset(): ?int | setOffset(?int offset): void |

## Example (as JSON)

```json
{
  "SessionTypeIds": [
    172,
    173,
    174
  ],
  "LocationIds": null,
  "StaffIds": null,
  "StartDate": null,
  "EndDate": null,
  "AppointmentId": null,
  "IgnoreDefaultSessionLength": null,
  "Limit": null,
  "Offset": null
}
```

