# User Token

```php
$userTokenController = $client->getUserTokenController();
```

## Class Name

`UserTokenController`

## Methods

* [User Token Issue](../../doc/controllers/user-token.md#user-token-issue)
* [User Token Revoke](../../doc/controllers/user-token.md#user-token-revoke)


# User Token Issue

Get a staff user token.

```php
function userTokenIssue(
    MindbodyPublicApiDtoModelsV6UserTokenControllerIssueRequest $request,
    string $siteId,
    string $version
): MindbodyPublicApiDtoModelsV6UserTokenControllerIssueResponse
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `request` | [`MindbodyPublicApiDtoModelsV6UserTokenControllerIssueRequest`](../../doc/models/mindbody-public-api-dto-models-v6-user-token-controller-issue-request.md) | Body, Required | - |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `version` | `string` | Template, Required | - |

## Response Type

[`MindbodyPublicApiDtoModelsV6UserTokenControllerIssueResponse`](../../doc/models/mindbody-public-api-dto-models-v6-user-token-controller-issue-response.md)

## Example Usage

```php
$request = new Models\MindbodyPublicApiDtoModelsV6UserTokenControllerIssueRequest();
$siteId = '-99';
$version = 'version4';

$result = $userTokenController->userTokenIssue($request, $siteId, $version);
```


# User Token Revoke

Revokes the user token in the Authorization header.

```php
function userTokenRevoke(string $siteId, string $version, ?string $authorization = null): array
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `version` | `string` | Template, Required | - |
| `authorization` | `?string` | Header, Optional | A staff user authorization token. |

## Response Type

`array`

## Example Usage

```php
$siteId = '-99';
$version = 'version4';

$result = $userTokenController->userTokenRevoke($siteId, $version);
```

