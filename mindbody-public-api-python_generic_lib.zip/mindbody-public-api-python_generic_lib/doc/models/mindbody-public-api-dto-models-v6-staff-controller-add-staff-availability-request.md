
# Mindbody Public Api Dto Models V6 Staff Controller Add Staff Availability Request

Add Staff Availability/Unavailability Schedule

## Structure

`MindbodyPublicApiDtoModelsV6StaffControllerAddStaffAvailabilityRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `staff_id` | `long\|int` | Required | The unique id of the staff |
| `is_availability` | `bool` | Required | IsAvailability = true means this is staff available schedule, false means unavailability |
| `description` | `string` | Optional | Description is required if IsAvailability=false |
| `program_ids` | `List of int` | Optional | List of ProgramIds - for session types the staff member performs, required if IsAvailability=true must be an Active ProgramId between 1 and 21 |
| `location_id` | `int` | Optional | The Location for the Availability, will default to 0 when isAvailability=false |
| `days_of_week` | `List of string` | Required | Day of week for the schedule "Monday", "Tuesday", etc... |
| `start_time` | `string` | Required | The starting time in site local time format "HH:MM:SS"<br>**Constraints**: *Pattern*: `^(?:(?:([01]?\d\|2[0-3]):)?([0-5]?\d):)?([0-5]?\d)$` |
| `end_time` | `string` | Required | The ending time in site local time format "HH:MM:SS"<br>**Constraints**: *Pattern*: `^(?:(?:([01]?\d\|2[0-3]):)?([0-5]?\d):)?([0-5]?\d)$` |
| `start_date` | `string` | Required | The ending time in site local time format "HH:MM:SS"<br>**Constraints**: *Pattern*: `^\d{4}-((0\d)\|(1[012]))-(([012]\d)\|3[01])$` |
| `end_date` | `string` | Required | The ending time in site local time format "HH:MM:SS"<br>**Constraints**: *Pattern*: `^\d{4}-((0\d)\|(1[012]))-(([012]\d)\|3[01])$` |
| `status` | `string` | Optional | one of "Public", "Masked", "Hidden", default "Public") - Schedule privacy. "Masked" only valid if IsAavailability=true |

## Example (as JSON)

```json
{
  "StaffId": 156,
  "IsAvailability": false,
  "Description": null,
  "ProgramIds": null,
  "LocationId": null,
  "DaysOfWeek": [
    "DaysOfWeek3",
    "DaysOfWeek4",
    "DaysOfWeek5"
  ],
  "StartTime": "StartTime8",
  "EndTime": "EndTime4",
  "StartDate": "StartDate4",
  "EndDate": "EndDate0",
  "Status": null
}
```

