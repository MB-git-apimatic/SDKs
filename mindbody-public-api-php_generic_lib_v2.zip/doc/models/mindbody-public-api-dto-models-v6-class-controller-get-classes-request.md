
# Mindbody Public Api Dto Models V6 Class Controller Get Classes Request

## Structure

`MindbodyPublicApiDtoModelsV6ClassControllerGetClassesRequest`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `classDescriptionIds` | `?(int[])` | Optional | The requested class description IDs. | getClassDescriptionIds(): ?array | setClassDescriptionIds(?array classDescriptionIds): void |
| `classIds` | `?(int[])` | Optional | The requested class IDs. | getClassIds(): ?array | setClassIds(?array classIds): void |
| `classScheduleIds` | `?(int[])` | Optional | The requested classSchedule Ids. | getClassScheduleIds(): ?array | setClassScheduleIds(?array classScheduleIds): void |
| `staffIds` | `?(int[])` | Optional | The requested IDs of the teaching staff members. | getStaffIds(): ?array | setStaffIds(?array staffIds): void |
| `startDateTime` | `?\DateTime` | Optional | The requested start date for filtering. This also determines what you will see for the ‘BookingWindow’ StartDateTime in the response. For example, if you pass a StartDateTime that is on OR before the BookingWindow ‘Open’ days of the class, you will retrieve the actual ‘StartDateTime’ for the Booking Window. If you pass a StartDateTime that is after the BookingWindow ‘date’, then you will receive results based on that start date. | getStartDateTime(): ?\DateTime | setStartDateTime(?\DateTime startDateTime): void |
| `endDateTime` | `?\DateTime` | Optional | The requested end date for filtering.<br><br />Default: **today’s date** | getEndDateTime(): ?\DateTime | setEndDateTime(?\DateTime endDateTime): void |
| `clientId` | `?string` | Optional | The client ID of the client who is viewing this class list. Based on identity, the client may be able to see additional information, such as membership specials. | getClientId(): ?string | setClientId(?string clientId): void |
| `programIds` | `?(int[])` | Optional | A list of program IDs on which to base the search. | getProgramIds(): ?array | setProgramIds(?array programIds): void |
| `sessionTypeIds` | `?(int[])` | Optional | A list of session type IDs on which to base the search. | getSessionTypeIds(): ?array | setSessionTypeIds(?array sessionTypeIds): void |
| `locationIds` | `?(int[])` | Optional | A list of location IDs on which to base the search. | getLocationIds(): ?array | setLocationIds(?array locationIds): void |
| `semesterIds` | `?(int[])` | Optional | A list of semester IDs on which to base the search. | getSemesterIds(): ?array | setSemesterIds(?array semesterIds): void |
| `hideCanceledClasses` | `?bool` | Optional | When `true`, canceled classes are removed from the response.<br /><br>When `false`, canceled classes are included in the response.<br /><br>Default: **false** | getHideCanceledClasses(): ?bool | setHideCanceledClasses(?bool hideCanceledClasses): void |
| `schedulingWindow` | `?bool` | Optional | When `true`, classes outside scheduling window are removed from the response.<br /><br>When `false`, classes are included in the response, regardless of the scheduling window.<br /><br>Default: **false** | getSchedulingWindow(): ?bool | setSchedulingWindow(?bool schedulingWindow): void |
| `lastModifiedDate` | `?\DateTime` | Optional | When included in the request, only records modified on or after the `LastModifiedDate` specified are included in the response. | getLastModifiedDate(): ?\DateTime | setLastModifiedDate(?\DateTime lastModifiedDate): void |
| `limit` | `?int` | Optional | Number of results to include, defaults to 100 | getLimit(): ?int | setLimit(?int limit): void |
| `offset` | `?int` | Optional | Page offset, defaults to 0. | getOffset(): ?int | setOffset(?int offset): void |

## Example (as JSON)

```json
{
  "ClassDescriptionIds": null,
  "ClassIds": null,
  "ClassScheduleIds": null,
  "StaffIds": null,
  "StartDateTime": null,
  "EndDateTime": null,
  "ClientId": null,
  "ProgramIds": null,
  "SessionTypeIds": null,
  "LocationIds": null,
  "SemesterIds": null,
  "HideCanceledClasses": null,
  "SchedulingWindow": null,
  "LastModifiedDate": null,
  "Limit": null,
  "Offset": null
}
```

