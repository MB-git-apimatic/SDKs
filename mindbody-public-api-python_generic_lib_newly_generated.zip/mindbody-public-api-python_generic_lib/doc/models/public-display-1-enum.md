
# Public Display 1 Enum

Sets the public display of the availability.<br /><ul><li>Show</li><li>Mask</li><li>Hide</li></ul>
(optional) Defaults to Show.

## Enumeration

`PublicDisplay1Enum`

## Fields

| Name |
|  --- |
| `HIDE` |
| `SHOW` |
| `MASK` |

