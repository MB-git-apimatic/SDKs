
# Mindbody Public Api Dto Models V6 Site Controller Get Session Types Response

## Structure

`MindbodyPublicApiDtoModelsV6SiteControllerGetSessionTypesResponse`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `paginationResponse` | [`?MindbodyPublicApiDtoModelsV6PaginationResponse`](../../doc/models/mindbody-public-api-dto-models-v6-pagination-response.md) | Optional | - | getPaginationResponse(): ?MindbodyPublicApiDtoModelsV6PaginationResponse | setPaginationResponse(?MindbodyPublicApiDtoModelsV6PaginationResponse paginationResponse): void |
| `sessionTypes` | [`?(MindbodyPublicApiDtoModelsV6SessionType[])`](../../doc/models/mindbody-public-api-dto-models-v6-session-type.md) | Optional | Contains information about sessions. | getSessionTypes(): ?array | setSessionTypes(?array sessionTypes): void |

## Example (as JSON)

```json
{
  "PaginationResponse": null,
  "SessionTypes": null
}
```

