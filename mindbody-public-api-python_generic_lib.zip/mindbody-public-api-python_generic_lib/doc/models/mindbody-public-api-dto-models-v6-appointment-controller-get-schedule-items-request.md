
# Mindbody Public Api Dto Models V6 Appointment Controller Get Schedule Items Request

## Structure

`MindbodyPublicApiDtoModelsV6AppointmentControllerGetScheduleItemsRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `location_ids` | `List of int` | Optional | A list of requested location IDs. |
| `staff_ids` | `List of long\|int` | Optional | A list of requested staff IDs. |
| `start_date` | `datetime` | Optional | The start date of the requested date range.<br><br />Default: **today’s date** |
| `end_date` | `datetime` | Optional | The end date of the requested date range.<br><br />Default: **today’s date** |
| `ignore_prep_finish_times` | `bool` | Optional | When `true`, appointment preparation and finish unavailabilities are not returned.<br><br />Default: **false** |
| `limit` | `int` | Optional | Number of results to include, defaults to 100 |
| `offset` | `int` | Optional | Page offset, defaults to 0. |

## Example (as JSON)

```json
{
  "LocationIds": null,
  "StaffIds": null,
  "StartDate": null,
  "EndDate": null,
  "IgnorePrepFinishTimes": null,
  "Limit": null,
  "Offset": null
}
```

