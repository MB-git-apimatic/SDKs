
# Mindbody Public Api Dto Models V6 Client Controller Get Custom Client Fields Request

## Structure

`MindbodyPublicApiDtoModelsV6ClientControllerGetCustomClientFieldsRequest`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `limit` | `?int` | Optional | Number of results to include, defaults to 100 | getLimit(): ?int | setLimit(?int limit): void |
| `offset` | `?int` | Optional | Page offset, defaults to 0. | getOffset(): ?int | setOffset(?int offset): void |

## Example (as JSON)

```json
{
  "Limit": null,
  "Offset": null
}
```

