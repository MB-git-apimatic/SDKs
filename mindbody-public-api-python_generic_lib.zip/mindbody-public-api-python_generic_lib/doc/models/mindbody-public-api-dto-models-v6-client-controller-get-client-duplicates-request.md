
# Mindbody Public Api Dto Models V6 Client Controller Get Client Duplicates Request

## Structure

`MindbodyPublicApiDtoModelsV6ClientControllerGetClientDuplicatesRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `first_name` | `string` | Optional | The client first name to match on when searching for duplicates. |
| `last_name` | `string` | Optional | The client last name to match on when searching for duplicates. |
| `email` | `string` | Optional | The client email to match on when searching for duplicates. |
| `limit` | `int` | Optional | Number of results to include, defaults to 100 |
| `offset` | `int` | Optional | Page offset, defaults to 0. |

## Example (as JSON)

```json
{
  "FirstName": null,
  "LastName": null,
  "Email": null,
  "Limit": null,
  "Offset": null
}
```

