
# Mindbody Public Api Dto Models V6 Site Controller Get Activation Code Response

## Structure

`MindbodyPublicApiDtoModelsV6SiteControllerGetActivationCodeResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `activation_code` | `string` | Optional | An activation code used to provide access to a site’s business data through MINDBODY. |
| `activation_link` | `string` | Optional | A link to the Manage Credentials screen. |

## Example (as JSON)

```json
{
  "ActivationCode": null,
  "ActivationLink": null
}
```

