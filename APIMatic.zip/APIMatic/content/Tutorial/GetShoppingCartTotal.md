﻿## Get Shopping Cart Total
<script type="text/javascript">
monitor('get-shopping-cart-total');
</script>

> Step 3: CheckoutShoppingCart example request with multiple items


:::visible {language=http}
```
curl -X POST \
  https://api.mindbodyonline.com/public/v6/sale/checkoutshoppingcart \
  -H 'Api-Key: {yourApiKey}' \
  -H 'Authorization: {staffAuthToken}' \
  -H 'Content-Type: application/json' \
  -H 'SiteId: {yourSiteId}' \
  -A '{yourAppName}' \
  -d '{
  "ClientId": "100000123",
  "Test": true,
  "LocationId": 1,
  "InStore": true,
  "CalculateTax": true,
  "Items": [
     {
      "Item": {
        "Type": "Product",
        "Metadata": {
          "Id": "5104"
        }
      },
      "DiscountAmount": 0,
      "Quantity": 1
    },
    {
      "Item": {
        "Type": "Service",
        "Metadata": {
          "Id": 5101
        }
      },
      "DiscountAmount": 0,
      "Quantity": 1
    }
  ],
  "Payments": [
    {
      "Type": "CreditCard",
      "Metadata": {
      	"Amount": 10,
      	"CreditCardNumber":"4111111111111111",
      	"ExpMonth": 12,
      	"ExpYear" : 2021,
      	"Cvv": "323",
      	"BillingName":"Bob Jones",
      	"BillingAddress": "4051 Broad Street",
      	"BillingCity" : "San Luis Obispo",
      	"BillingState" : "CA",
      	"BillingPostalCode": "93405",
      	"SaveInfo": true
      }
    }
  ]
}'
```
:::

:::visible {language=csharp}
```csharp
var client = new RestClient("https://api.mindbodyonline.com/public/v6/sale/checkoutshoppingcart");
var request = new RestRequest(Method.POST);
request.AddHeader("Authorization", "{staffAuthToken}");
request.AddHeader("SiteId", "{yourSiteId}");
request.AddHeader("Api-Key", "{yourApiKey}");
request.AddParameter("application/json", "{\n  \"ClientId\": \"100000123\",\n  \"Test\": true,\n  \"LocationId\": 1,\n  \"InStore\": true,\n  \"Items\": [\n     {\n      \"Item\": {\n        \"Type\": \"Product\",\n        \"Metadata\": {\n          \"Id\": \"5104\"\n        }\n      },\n      \"DiscountAmount\": 0,\n      \"Quantity\": 1\n    },\n    {\n      \"Item\": {\n        \"Type\": \"Service\",\n        \"Metadata\": {\n          \"Id\": 5101\n        }\n      },\n      \"DiscountAmount\": 0,\n      \"Quantity\": 1\n    }\n  ],\n  \"Payments\": [\n    {\n      \"Type\": \"CreditCard\",\n      \"Metadata\": {\n      \t\"Amount\": 10,\n      \t\"CreditCardNumber\":\"4111111111111111\",\n      \t\"ExpMonth\": 12,\n      \t\"ExpYear\" : 2021,\n      \t\"Cvv\": \"323\",\n      \t\"BillingName\":\"Bob Jones\",\n      \t\"BillingAddress\": \"4051 Broad Street\",\n      \t\"BillingCity\" : \"San Luis Obispo\",\n      \t\"BillingState\" : \"CA\",\n      \t\"BillingPostalCode\": \"93405\",\n      \t\"SaveInfo\": true\n      }\n    }\n  ]\n}", ParameterType.RequestBody);
IRestResponse response = client.Execute(request);
```
:::

:::visible {language=php}
```
<?php

$request = new HttpRequest();
$request->setUrl('https://api.mindbodyonline.com/public/v6/sale/checkoutshoppingcart');
$request->setMethod(HTTP_METH_POST);

$request->setHeaders(array(
  'Authorization' => '{staffAuthToken}',
  'SiteId' => '{yourSiteId}',
  'Api-Key' => '{yourApiKey}',
  'Content-Type' => 'application/json'
));

$request->setBody('{
  "ClientId": "100000123",
  "Test": true,
  "LocationId": 1,
  "InStore": true,
  "Items": [
     {
      "Item": {
        "Type": "Product",
        "Metadata": {
          "Id": "5104"
        }
      },
      "DiscountAmount": 0,
      "Quantity": 1
    },
    {
      "Item": {
        "Type": "Service",
        "Metadata": {
          "Id": 5101
        }
      },
      "DiscountAmount": 0,
      "Quantity": 1
    }
  ],
  "Payments": [
    {
      "Type": "CreditCard",
      "Metadata": {
      	"Amount": 10,
      	"CreditCardNumber":"4111111111111111",
      	"ExpMonth": 12,
      	"ExpYear" : 2021,
      	"Cvv": "323",
      	"BillingName":"Bob Jones",
      	"BillingAddress": "4051 Broad Street",
      	"BillingCity" : "San Luis Obispo",
      	"BillingState" : "CA",
      	"BillingPostalCode": "93405",
      	"SaveInfo": true
      }
    }
  ]
}');

try {
  $response = $request->send();

  echo $response->getBody();
} catch (HttpException $ex) {
  echo $ex;
}
```
:::

:::visible {language=python}
```
import http.client

conn = http.client.HTTPSConnection("api.mindbodyonline.com")

payload = "{\n  \"ClientId\": \"100000123\",\n  \"Test\": true,\n  \"LocationId\": 1,\n  \"InStore\": true,\n  \"Items\": [\n     {\n      \"Item\": {\n        \"Type\": \"Product\",\n        \"Metadata\": {\n          \"Id\": \"5104\"\n        }\n      },\n      \"DiscountAmount\": 0,\n      \"Quantity\": 1\n    },\n    {\n      \"Item\": {\n        \"Type\": \"Service\",\n        \"Metadata\": {\n          \"Id\": 5101\n        }\n      },\n      \"DiscountAmount\": 0,\n      \"Quantity\": 1\n    }\n  ],\n  \"Payments\": [\n    {\n      \"Type\": \"CreditCard\",\n      \"Metadata\": {\n      \t\"Amount\": 10,\n      \t\"CreditCardNumber\":\"4111111111111111\",\n      \t\"ExpMonth\": 12,\n      \t\"ExpYear\" : 2021,\n      \t\"Cvv\": \"323\",\n      \t\"BillingName\":\"Bob Jones\",\n      \t\"BillingAddress\": \"4051 Broad Street\",\n      \t\"BillingCity\" : \"San Luis Obispo\",\n      \t\"BillingState\" : \"CA\",\n      \t\"BillingPostalCode\": \"93405\",\n      \t\"SaveInfo\": true\n      }\n    }\n  ]\n}"

headers = {
	'Content-Type': "application/json",
    'Api-Key': "{yourApiKey}",
    'SiteId': "{yourSiteId}",
    'Authorization': "{staffAuthToken}"
    }

conn.request("POST", "public/v6/sale/checkoutshoppingcart", payload, headers)

res = conn.getresponse()
data = res.read()

print(data.decode("utf-8"))
```
:::

:::visible {language=ruby}
```
require 'uri'
require 'net/http'

url = URI("https://api.mindbodyonline.com/public/v6/sale/checkoutshoppingcart")

http = Net::HTTP.new(url.host, url.port)

request = Net::HTTP::Post.new(url)
request["Content-Type"] = 'application/json'
request["Api-Key"] = '{yourApiKey}'
request["SiteId"] = '{yourSiteId}'
request["Authorization"] = '{staffAuthToken}'
request.body = "{\n  \"ClientId\": \"100000123\",\n  \"Test\": true,\n  \"LocationId\": 1,\n  \"InStore\": true,\n  \"Items\": [\n     {\n      \"Item\": {\n        \"Type\": \"Product\",\n        \"Metadata\": {\n          \"Id\": \"5104\"\n        }\n      },\n      \"DiscountAmount\": 0,\n      \"Quantity\": 1\n    },\n    {\n      \"Item\": {\n        \"Type\": \"Service\",\n        \"Metadata\": {\n          \"Id\": 5101\n        }\n      },\n      \"DiscountAmount\": 0,\n      \"Quantity\": 1\n    }\n  ],\n  \"Payments\": [\n    {\n      \"Type\": \"CreditCard\",\n      \"Metadata\": {\n      \t\"Amount\": 10,\n      \t\"CreditCardNumber\":\"4111111111111111\",\n      \t\"ExpMonth\": 12,\n      \t\"ExpYear\" : 2021,\n      \t\"Cvv\": \"323\",\n      \t\"BillingName\":\"Bob Jones\",\n      \t\"BillingAddress\": \"4051 Broad Street\",\n      \t\"BillingCity\" : \"San Luis Obispo\",\n      \t\"BillingState\" : \"CA\",\n      \t\"BillingPostalCode\": \"93405\",\n      \t\"SaveInfo\": true\n      }\n    }\n  ]\n}"

response = http.request(request)
puts response.read_body
```
:::

> Step 4: CheckoutShoppingCart example response with the calculated cart total

```
{
    "ShoppingCart": {
        "Id": "1ba90250-5b7d-4af8-86d6-4d4fc30359c0",
        "CartItems": [
            {
                "Item": {
                    "Id": "3046",
                    "GroupId": 5104,
                    "Name": "Water Bottle",
                    "OnlinePrice": 5,
                    "ShortDesc": "Small water bottle",
                    "LongDesc": "",
                    "Size": {
                        "Id": 1,
                        "Name": "Small"
                    },
                    "Price": 5,
                    "TaxIncluded": 0,
                    "TaxRate": 0
                },
                "DiscountAmount": 0,
                "VisitIds": [],
                "AppointmentIds": [],
                "Appointments": [],
                "Id": 1,
                "Quantity": 1
            },
            {
                "Item": {
                    "Id": null,
                    "Name": "Yoga Pass",
                    "Count": 1,
                    "OnlinePrice": 5,
                    "Price": 5,
                    "TaxRate": 0,
                    "ProductId": "5101",
                    "ProgramId": 41,
                    "TaxIncluded": 0
                },
                "DiscountAmount": 0,
                "VisitIds": [],
                "AppointmentIds": [],
                "Appointments": [],
                "Id": 2,
                "Quantity": 1
            }
        ],
        "SubTotal": 10,
        "DiscountTotal": 0,
        "TaxTotal": 0,
        "GrandTotal": 10
    },
    "Classes": [],
    "Appointments": [],
    "Enrollments": []
}
```

<h3 class="toc-ignore">Summary</h3>
This tutorial demonstrates how a staff member can get the total for a shopping cart.

Note that you need to determine the client ID from your own application, as the Mindbody Public API does not validate client logins.
<ol class="step list">
	<li id="fpb1">Get a user authentication token for the staff member by passing the login credentials to the authentication endpoint. For examples and a description of the user authentication process, see [User Tokens](#user-tokens). For all following steps, put the token you receive into the <code>Authorization</code> header formatted as <code>Bearer {authToken}</code>.</li> 
	<li id="fpb2">Find the product IDs that you need by using a combination of calls to the following endpoints to obtain the items that the client wants to purchase:<ul><li>[GET Products](#get-products)</li><li>[GET Services](#get-services)</li></ul>
    <li id="fpb3">Pass the checkout request you have constructed to the `CheckoutShoppingCart` endpoint using that information. See the tutorial example request on the right to see how to construct a cart that contains each of the item types that you need.
	<li id="fpb4">Once you have constructed the cart, make a test call using the [POST CheckoutShoppingCart](#checkout-shopping-cart) endpoint by setting both `InStore` and `Test` to `true`. The response shows the cart total that Mindbody has calculated.
</ol>

