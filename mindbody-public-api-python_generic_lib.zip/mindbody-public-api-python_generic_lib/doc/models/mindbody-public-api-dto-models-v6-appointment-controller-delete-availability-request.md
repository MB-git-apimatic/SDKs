
# Mindbody Public Api Dto Models V6 Appointment Controller Delete Availability Request

This is the delete availability request coming DTO

## Structure

`MindbodyPublicApiDtoModelsV6AppointmentControllerDeleteAvailabilityRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `availability_id` | `int` | Optional | Availability Id to be deleted |
| `test` | `bool` | Optional | The test flag |

## Example (as JSON)

```json
{
  "AvailabilityId": null,
  "Test": null
}
```

