﻿## Cross-Regional Class Bookings
<script type="text/javascript">
monitor('cross-regional-class-bookings');
</script>

> Step 2: GET CrossRegionalClientAssociations

:::visible {language=http}
```
curl -X GET \
  'https://api.mindbodyonline.com/public/v6/client/crossregionalclientassociations?clientId=123' \
  -H 'Api-Key: {yourApiKey}' \
  -H 'Authorization: {staffAuthToken}' \
  -H 'Content-Type: application/json' \
  -H 'SiteId: {yourSiteId}' \
  -A '{yourAppName}' 
```
:::

:::visible {language=csharp}
```
var client = new RestClient("https://api.mindbodyonline.com/public/v6/client/crossregionalclientassociations?clientId=123");
var request = new RestRequest(Method.GET);
request.AddHeader("Authorization", "{staffAuthToken}");
request.AddHeader("SiteId", "{yourSiteId}");
request.AddHeader("Api-Key", "{yourApiKey}");
request.AddHeader("Content-Type", "application/json");
IRestResponse response = client.Execute(request);
```
:::

:::visible {language=php}
```
<?php

$request = new HttpRequest();
$request->setUrl('https://api.mindbodyonline.com/public/v6/client/crossregionalclientassociations');
$request->setMethod(HTTP_METH_GET);

$request->setQueryData(array(
	'clientId' => '123'
));

$request->setHeaders(array(
	'SiteId' => '{yourSiteId}',
	'Api-Key' => '{yourApiKey}',
	'Authorization' => '{staffAuthToken}',
	'Content-Type' => 'application/json'
));

try {
	$response = $request->send();

	echo $response->getBody();
} catch (HttpException $ex) {
	echo $ex;
}
```
:::

:::visible {language=python}
```
import http.client

conn = http.client.HTTPSConnection("api.mindbodyonline.com")

payload = ""

headers = {
    'Content-Type': "application/json",
    'Api-Key': "{yourApiKey}",
	'Authorization': "{stafAuthToken}",
    'SiteId': "{yourSiteId}"
    }

conn.request("GET", "public/v6/client/crossregionalclientAssociations", payload, headers)

res = conn.getresponse()
data = res.read()

print(data.decode("utf-8"))
```
:::

:::visible {language=ruby}
```
require 'uri'
require 'net/http'

url = URI("https://api.mindbodyonline.com/public/v6/client/crossregionalclientassociations?clientId=123")

http = Net::HTTP.new(url.host, url.port)

request = Net::HTTP::Get.new(url)
request["Content-Type"] = 'application/json'
request["Api-Key"] = '{yourApiKey}'
request["SiteId"] = '{yourSiteId}'
request["Authorization"] = '{staffAuthToken}'

response = http.request(request)
puts response.read_body
```
:::

> Step 4: GET ClientServices

:::visible {language=http}
```
curl -X GET \
  'https://api.mindbodyonline.com/public/v6/client/clientservices?clientId=123&crossRegionalLookup=true' \
  -H 'Api-Key: {yourApiKey}' \
  -H 'Authorization: {staffAuthToken}' \
  -H 'Content-Type: application/json' \
  -H 'SiteId: {yourSiteId}' \
  -A '{yourAppName}' 
```
:::

:::visible {language=csharp}
```
var client = new RestClient("https://api.mindbodyonline.com/public/v6/client/clientservices?clientId=123&crossRegionalLookup=true");
var request = new RestRequest(Method.GET);
request.AddHeader("Authorization", "{staffAuthToken}");
request.AddHeader("SiteId", "{yourSiteId}");
request.AddHeader("Api-Key", "{yourApiKey}");
request.AddHeader("Content-Type", "application/json");
IRestResponse response = client.Execute(request);
```
:::

:::visible {language=php}
```
<?php

$request = new HttpRequest();
$request->setUrl('https://api.mindbodyonline.com/public/v6/client/clientservices');
$request->setMethod(HTTP_METH_GET);

$request->setQueryData(array(
  'clientId' => '123',
  'crossRegionalLookup' => 'true'
));

$request->setHeaders(array(
  'SiteId' => '{yourSiteId}',
  'Api-Key' => '{yourApiKey}',
  'Authorization' => '{staffAuthToken}',
  'Content-Type' => 'application/json'
));

try {
  $response = $request->send();

  echo $response->getBody();
} catch (HttpException $ex) {
  echo $ex;
}
```
:::

:::visible {language=python}
```
import http.client

conn = http.client.HTTPSConnection("api.mindbodyonline.com")

payload = ""

headers = {
    'Content-Type': "application/json",
    'Api-Key': "{yourApiKey}",
	'Authorization': "{staffAuthToken}",
    'SiteId': "{yourSiteId}"
    }

conn.request("GET", "public/v6/client/clientservices", payload, headers)

res = conn.getresponse()
data = res.read()

print(data.decode("utf-8"))
```
:::

:::visible {language=ruby}
```
require 'uri'
require 'net/http'

url = URI("https://api.mindbodyonline.com/public/v6/client/clientservices?clientId=123&crossRegionalLookup=true")

http = Net::HTTP.new(url.host, url.port)

request = Net::HTTP::Get.new(url)
request["Content-Type"] = 'application/json'
request["Api-Key"] = '{yourApiKey}'
request["SiteId"] = '{yourSiteId}'
request["Authorization"] = '{staffAuthToken}'

response = http.request(request)
puts response.read_body
```
:::

> Step 5: AddClientToClass

:::visible {language=http}
```
curl -X POST \
  https://api.mindbodyonline.com/public/v6/class/addclienttoclass \
  -H 'Api-Key: {yourApiKey}' \
  -H 'Authorization: {staffAuthToken}' \
  -H 'SiteId: {yourSiteId}' \
  -A '{yourAppName}' \
  -d '{
	"ClientId": "123",
	"ClassId": 1206,
	"ClientServiceId": 4456,
	"CrossRegionalBooking": true,
	"CrossRegionalBookingClientServiceSiteId": 1234
}'
```
:::

:::visible {language=csharp}
```
var client = new RestClient("https://api.mindbodyonline.com/public/v6/class/addclienttoclass");
var request = new RestRequest(Method.POST);
request.AddHeader("Authorization", "{staffAuthToken}");
request.AddHeader("SiteId", "{yourSiteId}");
request.AddHeader("Api-Key", "{yourApiKey}");
request.AddParameter("application/json", "{\n\t\"ClientId\": \"123\",\n\t\"ClassId\": 1206,\n\t\"ClientServiceId\": 4456,\n\t\"CrossRegionalBooking\": true,\n\t\"CrossRegionalBookingClientServiceSiteId\": 1234\n}", ParameterType.RequestBody);
IRestResponse response = client.Execute(request);
```
:::

:::visible {language=php}
```
<?php

$request = new HttpRequest();
$request->setUrl('https://api.mindbodyonline.com/public/v6/class/addclienttoclass');
$request->setMethod(HTTP_METH_POST);

$request->setHeaders(array(
  'SiteId' => '{yourSiteId}',
  'Authorization' => '{staffAuthToken}',
  'Api-Key' => '{yourApiKey}'
));

$request->setBody('{
	"ClientId": "123",
	"ClassId": 1206,
	"ClientServiceId": 4456,
	"CrossRegionalBooking": true,
	"CrossRegionalBookingClientServiceSiteId": 1234
}');

try {
  $response = $request->send();

  echo $response->getBody();
} catch (HttpException $ex) {
  echo $ex;
}
```
:::

:::visible {language=python}
```
import http.client

conn = http.client.HTTPSConnection("api.mindbodyonline.com")

payload = "{\n\t\"ClientId\": \"123\",\n\t\"ClassId\": 1206,\n\t\"ClientServiceId\": 4456,\n\t\"CrossRegionalBooking\": true,\n\t\"CrossRegionalBookingClientServiceSiteId\": 1234\n}"

headers = {
    'Api-Key': "{yourApiKey}",
	'Authorization': "{staffAuthToken}",
    'SiteId': "{yourSiteId}"
    }

conn.request("POST", "public/v6/class/addclienttoclass", payload, headers)

res = conn.getresponse()
data = res.read()

print(data.decode("utf-8"))
```
:::

:::visible {language=ruby}
```
require 'uri'
require 'net/http'

url = URI("https://api.mindbodyonline.com/public/v6/class/addclienttoclass")

http = Net::HTTP.new(url.host, url.port)

request = Net::HTTP::Post.new(url)
request["Api-Key"] = '{yourApiKey}'
request["SiteId"] = '{yourSiteId}'
request["Authorization"] = '{staffAuthToken}'
request.body = "{\n\t\"ClientId\": \"123\",\n\t\"ClassId\": 1206,\n\t\"ClientServiceId\": 4456,\n\t\"CrossRegionalBooking\": true,\n\t\"CrossRegionalBookingClientServiceSiteId\": 1234\n}"

response = http.request(request)
puts response.read_body
```
:::

> Step 6: GET ClientVisits


:::visible {language=http}
```
curl -X GET \
  'https://api.mindbodyonline.com/public/v6/client/clientvisits?clientId=123&crossRegionalLookup=true' \
  -H 'Api-Key: {yourApiKey}' \
  -H 'Authorization: {staffAuthToken}' \
  -H 'Content-Type: application/json' \
  -H 'SiteId: {yourSiteId}' \
  -A '{yourAppName}' 
```
:::

:::visible {language=csharp}
```
var client = new RestClient("https://api.mindbodyonline.com/public/v6/client/clientvisits?clientId=123&crossRegionalLookup=true");
var request = new RestRequest(Method.GET);
request.AddHeader("Authorization", "{staffAuthToken}");
request.AddHeader("SiteId", "{yourSiteId}");
request.AddHeader("Api-Key", "{yourApiKey}");
request.AddHeader("Content-Type", "application/json");
IRestResponse response = client.Execute(request);
```
:::

:::visible {language=php}
```
<?php

$request = new HttpRequest();
$request->setUrl('https://api.mindbodyonline.com/public/v6/client/clientvisits');
$request->setMethod(HTTP_METH_GET);

$request->setQueryData(array(
  'clientId' => '123',
  'crossRegionalLookup' => 'true'
));

$request->setHeaders(array(
  'Authorization' => '{staffAuthToken}',
  'SiteId' => '{yourSiteId}',
  'Api-Key' => '{yourApiKey}',
  'Content-Type' => 'application/json'
));

try {
  $response = $request->send();

  echo $response->getBody();
} catch (HttpException $ex) {
  echo $ex;
}
```
:::

:::visible {language=python}
```
import http.client

conn = http.client.HTTPSConnection("api.mindbodyonline.com")

payload = ""

headers = {
    'Content-Type': "application/json",
    'Api-Key': "{yourApiKey}",
    'SiteId': "{yourSiteId}",
    'Authorization': "{staffAuthToken}"
    }

conn.request("GET", "public/v6/client/clientvisits", payload, headers)

res = conn.getresponse()
data = res.read()

print(data.decode("utf-8"))
```
:::

:::visible {language=ruby}
```
require 'uri'
require 'net/http'

url = URI("https://api.mindbodyonline.com/public/v6/client/clientvisits?clientId=123&crossRegionalLookup=true")

http = Net::HTTP.new(url.host, url.port)

request = Net::HTTP::Get.new(url)
request["Content-Type"] = 'application/json'
request["Api-Key"] = '{yourApiKey}'
request["SiteId"] = '{yourSiteId}'
request["Authorization"] = '{staffAuthToken}'

response = http.request(request)
puts response.read_body
```
:::

>Example GET ClientVisits response

```
{
    "PaginationResponse": {
        "RequestedLimit": 100,
        "RequestedOffset": 0,
        "PageSize": 22,
        "TotalResults": 22
    },
    "Visits": [
        {
            "AppointmentId": 0,
            "AppointmentGenderPreference": "None",
            "AppointmentStatus": "None",
            "ClassId": 1206,
            "ClientId": "123",
            "StartDateTime": "2019-04-26T07:00:00",
            "EndDateTime": "2019-04-26T08:00:00",
            "Id": 90982,
            "LastModifiedDateTime": "0001-01-01T00:00:00Z",
            "LateCancelled": false,
            "LocationId": 1,
            "MakeUp": false,
            "Name": "Cross Region Visit",
            "ServiceId": 4456,
            "SignedIn": true,
            "StaffId": 1467,
            "WebSignup": false,
            "Action": "None"
        }
	]
}
```

<h3 class="toc-ignore">Summary</h3>
This tutorial demonstrates how a client can book a class at one site using a client  pricing option from another site.  Both sites must belong to the same organization.

<h3 class="toc-ignore">Workflow</h3>
You need to determine the client ID from your own application, as the Mindbody Public API does not validate client logins.<br><br> Note that all Cross-Regional functionality in the Mindbody Public API returns only the first ten sites. If a user belongs to more than ten sites, you can use the <code>ClientAssociatedSitesOffset</code> parameter to scan through additional sites.
<ol class="step-list">
	<li id="fpb1"><p>Get a user authentication token for the staff member by passing the login credentials to the authentication endpoint. For examples and a description of the user authentication process, see <a href="#user-tokens">User Tokens</a>. For all following steps, put the token that you receive into the <code>Authorization</code> header formatted as <code>Bearer {authToken}</code>.</li>
	<li id="fpb2">Clients may belong to multiple sites where they may have pricing options that they could use for the booking. Use the [GET CrossRegionalClientAssociations](#get-cross-regional-client-associations) endpoint, specifying the `ClientId` (RSSID) of the client who wants to book the class, to obtain the site IDs of the client's cross regional associations. See [GET CrossRegionalClientAssociations](#get-cross-regional-client-associations) for an example response.</li>
	<li id="fpb3">If the client does not have an existing pricing option from a site in a region different from the class, then you can look at the [Purchase a Class Pass tutorial](#purchase-an-appointment-pass) to see how to purchase a new pricing option using `CheckoutShoppingCart`. Otherwise, proceed to the next step.</li>
	<li id="fpb4">Optionally, you can call the [GET ClientServices](#get-client-services) endpoint and set `CrossRegionalLookup` to `true` to obtain the `Id` of the pricing option to be used to pay for the class. If the user belongs to more than ten sites, you can make multiple calls to `ClientAssociatedSitesOffset`, using a different value for each call, to scan through all the sites. See [GET ClientServices](#get-client-services) for an example response.</li>
	<li id="fpb5">Call the [AddClientToClass](#add-client-to-class) endpoint, setting `CrossRegionalBooking` to `true`, and setting `CrossRegionalBookingClientServiceSiteId` to the site ID that you obtained in Step 2. Note that you must supply a `CrossRegionalBookingClientServiceSiteId` when `CrossRegionalBooking` is set to `true`. You can optionally supply the `ClientServiceId`, which is the `Id` that you obtained in Step 4, to specify the pricing option to use. If no `ClientServiceId` is provided, an applicable pricing option from the cross-regional site is used. See [AddClientToClass](#add-client-to-class) for an example response.</li>
	<li id="fpb6">You can retrieve a client's visits across multiple sites using [GET ClientVisits](#get-client-visits) with `CrossRegionalLookup` set to `true`.</li>
</ol>
