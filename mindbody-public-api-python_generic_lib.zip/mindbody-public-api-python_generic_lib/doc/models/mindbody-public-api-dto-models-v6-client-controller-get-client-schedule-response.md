
# Mindbody Public Api Dto Models V6 Client Controller Get Client Schedule Response

## Structure

`MindbodyPublicApiDtoModelsV6ClientControllerGetClientScheduleResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `pagination_response` | [`MindbodyPublicApiDtoModelsV6PaginationResponse`](../../doc/models/mindbody-public-api-dto-models-v6-pagination-response.md) | Optional | - |
| `visits` | [`List of MindbodyPublicApiDtoModelsV6Visit`](../../doc/models/mindbody-public-api-dto-models-v6-visit.md) | Optional | Contains information about client visits. |

## Example (as JSON)

```json
{
  "PaginationResponse": null,
  "Visits": null
}
```

