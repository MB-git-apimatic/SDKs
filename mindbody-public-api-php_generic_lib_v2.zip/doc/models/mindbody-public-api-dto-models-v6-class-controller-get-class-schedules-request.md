
# Mindbody Public Api Dto Models V6 Class Controller Get Class Schedules Request

## Structure

`MindbodyPublicApiDtoModelsV6ClassControllerGetClassSchedulesRequest`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `classScheduleIds` | `?(int[])` | Optional | The class schedule IDs.<br><br />Default: **all** | getClassScheduleIds(): ?array | setClassScheduleIds(?array classScheduleIds): void |
| `endDate` | `?\DateTime` | Optional | The end date of the range. Return any active enrollments that occur on or before this day.<br><br />Default: **StartDate** | getEndDate(): ?\DateTime | setEndDate(?\DateTime endDate): void |
| `locationIds` | `?(int[])` | Optional | The location IDs.<br><br />Default: **all** | getLocationIds(): ?array | setLocationIds(?array locationIds): void |
| `programIds` | `?(int[])` | Optional | The program IDs.<br><br />Default: **all** | getProgramIds(): ?array | setProgramIds(?array programIds): void |
| `sessionTypeIds` | `?(int[])` | Optional | The session type IDs.<br><br />Default: **all** | getSessionTypeIds(): ?array | setSessionTypeIds(?array sessionTypeIds): void |
| `staffIds` | `?(int[])` | Optional | The staff IDs.<br><br />Default: **all** | getStaffIds(): ?array | setStaffIds(?array staffIds): void |
| `startDate` | `?\DateTime` | Optional | The start date of the range. Return any active enrollments that occur on or after this day.<br><br />Default: **today’s date** | getStartDate(): ?\DateTime | setStartDate(?\DateTime startDate): void |
| `limit` | `?int` | Optional | Number of results to include, defaults to 100 | getLimit(): ?int | setLimit(?int limit): void |
| `offset` | `?int` | Optional | Page offset, defaults to 0. | getOffset(): ?int | setOffset(?int offset): void |

## Example (as JSON)

```json
{
  "ClassScheduleIds": null,
  "EndDate": null,
  "LocationIds": null,
  "ProgramIds": null,
  "SessionTypeIds": null,
  "StaffIds": null,
  "StartDate": null,
  "Limit": null,
  "Offset": null
}
```

