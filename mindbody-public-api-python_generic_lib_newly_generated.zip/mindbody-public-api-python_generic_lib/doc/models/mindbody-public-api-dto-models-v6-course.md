
# Mindbody Public Api Dto Models V6 Course

A course.

## Structure

`MindbodyPublicApiDtoModelsV6Course`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `long\|int` | Optional | The course ID. |
| `name` | `string` | Optional | The course name. |
| `description` | `string` | Optional | A description of the course. |
| `notes` | `string` | Optional | Any notes that have been written about the course. |
| `start_date` | `datetime` | Optional | Date and time that the course starts. |
| `end_date` | `datetime` | Optional | Date and time that the course ends. |
| `location` | [`MindbodyPublicApiDtoModelsV6Location`](../../doc/models/mindbody-public-api-dto-models-v6-location.md) | Optional | - |
| `organizer` | [`MindbodyPublicApiDtoModelsV6Staff`](../../doc/models/mindbody-public-api-dto-models-v6-staff.md) | Optional | - |
| `program` | [`MindbodyPublicApiDtoModelsV6Program`](../../doc/models/mindbody-public-api-dto-models-v6-program.md) | Optional | - |
| `image_url` | `string` | Optional | The URL of the image associated with this course, if one exists. |

## Example (as JSON)

```json
{
  "Id": null,
  "Name": null,
  "Description": null,
  "Notes": null,
  "StartDate": null,
  "EndDate": null,
  "Location": null,
  "Organizer": null,
  "Program": null,
  "ImageUrl": null
}
```

