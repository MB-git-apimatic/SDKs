
# Mindbody Public Api Dto Models V6 Staff Controller Get Staff Image URL Request

This is the request class for the get staff image URL API

## Structure

`MindbodyPublicApiDtoModelsV6StaffControllerGetStaffImageURLRequest`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `staffId` | `?int` | Optional | The ID of the staff member whose image URL details you want to retrieve. | getStaffId(): ?int | setStaffId(?int staffId): void |

## Example (as JSON)

```json
{
  "StaffId": null
}
```

