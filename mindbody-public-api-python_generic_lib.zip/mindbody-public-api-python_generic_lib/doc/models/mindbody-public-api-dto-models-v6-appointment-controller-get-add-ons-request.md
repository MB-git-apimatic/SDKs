
# Mindbody Public Api Dto Models V6 Appointment Controller Get Add Ons Request

## Structure

`MindbodyPublicApiDtoModelsV6AppointmentControllerGetAddOnsRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `staff_id` | `int` | Optional | Optionally filter add ons that can be performed by this staff |
| `limit` | `int` | Optional | Number of results to include, defaults to 100 |
| `offset` | `int` | Optional | Page offset, defaults to 0. |

## Example (as JSON)

```json
{
  "StaffId": null,
  "Limit": null,
  "Offset": null
}
```

