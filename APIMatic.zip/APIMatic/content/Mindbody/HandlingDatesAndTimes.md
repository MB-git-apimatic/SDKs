﻿## Handling Dates and Times
<script type="text/javascript">
monitor('handling-dates-and-times');
</script>  
To represent points in time, the Public API accepts time stamp strings.  Because JSON doesn't have a built-in format for expressing dates and times, the Public API returns dates and times as strings.  All date and time pairs are returned in the format YYYY-MM-DDTHH:mm:ss. When you send or receive dates and times using the Public API, the data is always passed in the business owner's local time. We consider it a best practice to pass in times without using a UTC designation.

To ensure that you don't have problems rendering dates and times, we recommend that you pass dates and times in the [ISO 8601 format](https://www.w3.org/TR/NOTE-datetime) as defined by the [RFC 339 specification](https://www.ietf.org/rfc/rfc3339.txt). If you enter dates and times in a nonstandard format, you may encounter errors.
