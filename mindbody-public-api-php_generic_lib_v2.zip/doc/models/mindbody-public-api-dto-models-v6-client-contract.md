
# Mindbody Public Api Dto Models V6 Client Contract

A client contract

## Structure

`MindbodyPublicApiDtoModelsV6ClientContract`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `agreementDate` | `?\DateTime` | Optional | The date on which the contract was signed. | getAgreementDate(): ?\DateTime | setAgreementDate(?\DateTime agreementDate): void |
| `autopayStatus` | [`?string (AutopayStatusEnum)`](../../doc/models/autopay-status-enum.md) | Optional | The status of the client’s autopay. | getAutopayStatus(): ?string | setAutopayStatus(?string autopayStatus): void |
| `contractName` | `?string` | Optional | The name of the contract. | getContractName(): ?string | setContractName(?string contractName): void |
| `endDate` | `?\DateTime` | Optional | The date that the contract expires. | getEndDate(): ?\DateTime | setEndDate(?\DateTime endDate): void |
| `id` | `?int` | Optional | The unique ID of the contract. | getId(): ?int | setId(?int id): void |
| `originationLocationId` | `?int` | Optional | The ID of the location where the contract was issued. | getOriginationLocationId(): ?int | setOriginationLocationId(?int originationLocationId): void |
| `startDate` | `?\DateTime` | Optional | The date that the contract became active. | getStartDate(): ?\DateTime | setStartDate(?\DateTime startDate): void |
| `siteId` | `?int` | Optional | The ID of the site where the contract was issued. | getSiteId(): ?int | setSiteId(?int siteId): void |
| `upcomingAutopayEvents` | [`?(MindbodyPublicApiDtoModelsV6UpcomingAutopayEvent[])`](../../doc/models/mindbody-public-api-dto-models-v6-upcoming-autopay-event.md) | Optional | Contains details of the autopay events. | getUpcomingAutopayEvents(): ?array | setUpcomingAutopayEvents(?array upcomingAutopayEvents): void |
| `contractID` | `?int` | Optional | The ID of the contract | getContractID(): ?int | setContractID(?int contractID): void |
| `terminationDate` | `?\DateTime` | Optional | The date that the contract was terminated. | getTerminationDate(): ?\DateTime | setTerminationDate(?\DateTime terminationDate): void |

## Example (as JSON)

```json
{
  "AgreementDate": null,
  "AutopayStatus": null,
  "ContractName": null,
  "EndDate": null,
  "Id": null,
  "OriginationLocationId": null,
  "StartDate": null,
  "SiteId": null,
  "UpcomingAutopayEvents": null,
  "ContractID": null,
  "TerminationDate": null
}
```

