
# Mindbody Public Api Dto Models V6 Appointment Controller Delete Availability Request

This is the delete availability request coming DTO

## Structure

`MindbodyPublicApiDtoModelsV6AppointmentControllerDeleteAvailabilityRequest`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `availabilityId` | `?int` | Optional | The ID of the availability or unavailability. | getAvailabilityId(): ?int | setAvailabilityId(?int availabilityId): void |
| `test` | `?bool` | Optional | When `true`, indicates that this is a test request and no data is deleted from the subscriber’s database.<br>When `false`, the record will be deleted.<br>Default: **false** | getTest(): ?bool | setTest(?bool test): void |

## Example (as JSON)

```json
{
  "AvailabilityId": null,
  "Test": null
}
```

