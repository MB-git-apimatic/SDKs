
# Mindbody Public Api Dto Models V6 Sale Controller Update Product Price Request

Update Product Price Request Model

## Structure

`MindbodyPublicApiDtoModelsV6SaleControllerUpdateProductPriceRequest`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `barcodeId` | `?string` | Optional | The barcode number of the product. This is the `Products[].Id` returned from GET Products. | getBarcodeId(): ?string | setBarcodeId(?string barcodeId): void |
| `price` | `?float` | Optional | The price you sell the product for. | getPrice(): ?float | setPrice(?float price): void |
| `onlinePrice` | `?float` | Optional | The online price of the product. | getOnlinePrice(): ?float | setOnlinePrice(?float onlinePrice): void |

## Example (as JSON)

```json
{
  "BarcodeId": null,
  "Price": null,
  "OnlinePrice": null
}
```

