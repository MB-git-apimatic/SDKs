# Pricing Option

```python
pricing_option_controller = client.pricing_option
```

## Class Name

`PricingOptionController`


# Pricing Option Update Pricing Option

Update Pricing Option data such as name, details, price, discontinued using PricingOptionId(product id)

```python
def pricing_option_update_pricing_option(self,
                                        request,
                                        site_id,
                                        version,
                                        authorization=None)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `request` | [`MindbodyPublicApiDtoModelsV6PricingOptionControllerUpdatePricingOptionRequest`](../../doc/models/mindbody-public-api-dto-models-v6-pricing-option-controller-update-pricing-option-request.md) | Body, Required | - |
| `site_id` | `string` | Header, Required | ID of the site from which to pull data. |
| `version` | `string` | Template, Required | - |
| `authorization` | `string` | Header, Optional | A staff user authorization token. |

## Response Type

`object`

## Example Usage

```python
request = MindbodyPublicApiDtoModelsV6PricingOptionControllerUpdatePricingOptionRequest()
request.product_id = 16.72
site_id = '-99'
version = 'version4'

result = pricing_option_controller.pricing_option_update_pricing_option(request, site_id, version)
```

