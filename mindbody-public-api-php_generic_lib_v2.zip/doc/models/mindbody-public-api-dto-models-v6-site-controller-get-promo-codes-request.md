
# Mindbody Public Api Dto Models V6 Site Controller Get Promo Codes Request

## Structure

`MindbodyPublicApiDtoModelsV6SiteControllerGetPromoCodesRequest`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `activeOnly` | `?bool` | Optional | If true, filters results to show only promocodes that are active. If **false**, all promocodes are returned.<br>Default: **true** | getActiveOnly(): ?bool | setActiveOnly(?bool activeOnly): void |
| `onlineOnly` | `?bool` | Optional | If `true`, filters results to show only promocodes that can be used for online sale.<br>If `false`, all promocodes are returned.<br>Default: **false** | getOnlineOnly(): ?bool | setOnlineOnly(?bool onlineOnly): void |
| `startDate` | `?\DateTime` | Optional | Filters results to promocodes that were activated after this date. | getStartDate(): ?\DateTime | setStartDate(?\DateTime startDate): void |
| `endDate` | `?\DateTime` | Optional | Filters results to promocodes that were activated before this date. | getEndDate(): ?\DateTime | setEndDate(?\DateTime endDate): void |
| `limit` | `?int` | Optional | Number of results to include, defaults to 100 | getLimit(): ?int | setLimit(?int limit): void |
| `offset` | `?int` | Optional | Page offset, defaults to 0. | getOffset(): ?int | setOffset(?int offset): void |

## Example (as JSON)

```json
{
  "ActiveOnly": null,
  "OnlineOnly": null,
  "StartDate": null,
  "EndDate": null,
  "Limit": null,
  "Offset": null
}
```

