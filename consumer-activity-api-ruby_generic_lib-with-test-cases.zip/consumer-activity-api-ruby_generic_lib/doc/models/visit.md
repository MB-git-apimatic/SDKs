
# Visit

## Structure

`Visit`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `consumer_id` | `String` | Optional | - |
| `service_name` | `String` | Optional | - |
| `service_category` | `String` | Optional | - |
| `payment_method` | `String` | Optional | - |
| `amount_paid` | `Float` | Optional | - |
| `visit_date` | `DateTime` | Optional | - |
| `booking_date` | `DateTime` | Optional | - |

## Example (as JSON)

```json
{
  "consumerId": null,
  "serviceName": null,
  "serviceCategory": null,
  "paymentMethod": null,
  "amountPaid": null,
  "visitDate": null,
  "bookingDate": null
}
```

